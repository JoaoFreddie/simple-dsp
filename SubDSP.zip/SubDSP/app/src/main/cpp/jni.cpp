#include <jni.h>
#include "engine.h"
static Engine* E = nullptr;
static Engine* eng() { if (!E) E = new Engine(); return E; }
#define J(name) Java_com_example_dsp_NativeDsp_##name

extern "C" {
JNIEXPORT jboolean JNICALL J(start)(JNIEnv*, jobject, jint sr, jint dev, jint targetMs) { return eng()->start(sr, dev, targetMs); }
JNIEXPORT void JNICALL J(stop)(JNIEnv*, jobject) { if (E) E->stop(); }

JNIEXPORT void JNICALL J(push)(JNIEnv* env, jobject, jfloatArray a, jint n) {
  if (!E) return;
  jfloat* p = (jfloat*)env->GetPrimitiveArrayCritical(a, nullptr);
  if (!p) return;
  E->ring.push(p, (size_t)n / 2);                // n floats = n/2 stereo frames
  env->ReleasePrimitiveArrayCritical(a, p, JNI_ABORT);
}
JNIEXPORT void JNICALL J(setBand)(JNIEnv*, jobject, jint i, jint t, jfloat f, jfloat g, jfloat q, jboolean byp) {
  Band b; b.type = t; b.f = f; b.g = g; b.q = q; b.byp = byp;
  eng()->peq.set(i, b);
}
JNIEXPORT void JNICALL J(setSub)(JNIEnv*, jobject, jfloat sweep, jfloat wide, jfloat smooth, jfloat sens,
                                 jint voice, jint gen, jboolean au, jfloat pfm, jfloat gdb, jfloat drive) {
  SubSynth& s = eng()->sub;
  s.sweep = sweep; s.wide = wide; s.smooth = smooth; s.sens = sens; s.voice = voice; s.gen = gen;
  s.autoSweep = au; s.pfm = pfm; s.gainDb = gdb; s.drive = drive;
}
JNIEXPORT void JNICALL J(setMaster)(JNIEnv*, jobject, jfloat in, jfloat out, jfloat ceil, jboolean en) {
  Engine* e = eng(); e->inG = dbl(in); e->outG = dbl(out); e->lim.ceilLin = dbl(ceil); e->on = en;
}
JNIEXPORT void JNICALL J(setEq)(JNIEnv*, jobject, jboolean eq, jboolean lim) {
  Engine* e = eng(); e->peq.enabled = eq; e->limOn = lim;
}
JNIEXPORT void JNICALL J(setSubOnly)(JNIEnv*, jobject, jboolean so) { eng()->subOnly = so; }
JNIEXPORT void JNICALL J(status)(JNIEnv* env, jobject, jfloatArray out) {
  if (!E) return;
  jfloat* o = env->GetFloatArrayElements(out, nullptr);
  E->status(o);
  env->ReleaseFloatArrayElements(out, o, 0);
}

JNIEXPORT void JNICALL J(spectrum)(JNIEnv* env, jobject, jfloatArray out, jfloat fLo, jfloat fHi) {
  constexpr int N = 8192;
  if (!E) return;
  static float re[N], im[N], P[N / 2 + 1], sm[512] = {};
  int w = E->tapW.load(std::memory_order_acquire);
  for (int i = 0; i < N; i++) {
    re[i] = E->tap[(w - N + i + Engine::TAP) % Engine::TAP] * (.5f - .5f * cosf(2 * PI * i / (N - 1)));
    im[i] = 0;
  }
  for (int i = 1, j = 0; i < N; i++) {
    int bit = N >> 1; for (; j & bit; bit >>= 1) j ^= bit; j ^= bit;
    if (i < j) { std::swap(re[i], re[j]); std::swap(im[i], im[j]); }
  }
  for (int len = 2; len <= N; len <<= 1) {
    float ang = -2 * PI / len, wr = cosf(ang), wi = sinf(ang);
    for (int i = 0; i < N; i += len) {
      float cr = 1, ci = 0;
      for (int k = 0; k < len / 2; k++) {
        int a = i + k, b = a + len / 2;
        float tr = re[b] * cr - im[b] * ci, ti = re[b] * ci + im[b] * cr;
        re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
        float nr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = nr;
      }
    }
  }
  for (int k = 0; k <= N / 2; k++) P[k] = re[k] * re[k] + im[k] * im[k];
  int nb = std::min((int)env->GetArrayLength(out), 512);
  jfloat* o = env->GetFloatArrayElements(out, nullptr);
  float fs = E->peq.fs, lr = logf(fHi / fLo);
  for (int b = 0; b < nb; b++) {
    float f0 = fLo * expf(lr * b / nb), f1 = fLo * expf(lr * (b + 1) / nb);
    float lo = f0 / fs * N, hi = f1 / fs * N, m = 0;
    if (hi - lo < 1.f) {
      float mid = .5f * (lo + hi); int k = std::clamp((int)mid, 1, N / 2 - 1); float fr = mid - k;
      m = P[k] * (1 - fr) + P[k + 1] * fr;
    } else {
      int k0 = std::max(1, (int)ceilf(lo)), k1 = std::min(N / 2, (int)floorf(hi));
      for (int k = k0; k <= k1; k++) m = std::max(m, P[k]);
    }
    float db = 10 * log10f(m / (N * N / 16.f) + 1e-12f);
    float v = std::clamp((db + 84.f) / 72.f, 0.f, 1.f);
    sm[b] += (v > sm[b] ? .55f : .15f) * (v - sm[b]);
    o[b] = sm[b];
  }
  env->ReleaseFloatArrayElements(out, o, 0);
}
}
