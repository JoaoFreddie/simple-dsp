#include <jni.h>
#include "engine.h"
static Engine* E = nullptr;
#define J(name) Java_com_example_dsp_NativeDsp_##name

extern "C" {
JNIEXPORT jboolean JNICALL J(start)(JNIEnv*, jobject, jint sr) { if (!E) E = new Engine(); E->stop(); return E->start(sr); }
JNIEXPORT void JNICALL J(stop)(JNIEnv*, jobject) { if (E) E->stop(); }

JNIEXPORT void JNICALL J(push)(JNIEnv* env, jobject, jfloatArray a, jint n) {
  if (!E) return;
  jfloat* p = (jfloat*)env->GetPrimitiveArrayCritical(a, nullptr);
  E->ring.push(p, (size_t)n);
  env->ReleasePrimitiveArrayCritical(a, p, JNI_ABORT);
}
JNIEXPORT void JNICALL J(setBand)(JNIEnv*, jobject, jint i, jint t, jfloat f, jfloat g, jfloat q, jboolean byp) {
  if (!E) E = new Engine();
  Band b; b.type = t; b.f = f; b.g = g; b.q = q; b.byp = byp;
  E->peq.set(i, b);
}
JNIEXPORT void JNICALL J(setEpicenter)(JNIEnv*, jobject, jfloat dr, jfloat f, jfloat w, jfloat l, jfloat m) {
  if (!E) E = new Engine();
  E->epi.drive = dr; E->epi.freq = f; E->epi.width = w; E->epi.lvlDb = l; E->epi.mix = m;
}
JNIEXPORT void JNICALL J(setMaster)(JNIEnv*, jobject, jfloat in, jfloat out, jfloat ceil, jboolean en) {
  if (!E) E = new Engine();
  E->inG = dbl(in); E->outG = dbl(out); E->lim.ceilLin = dbl(ceil); E->on = en;
}

JNIEXPORT void JNICALL J(spectrum)(JNIEnv* env, jobject, jfloatArray out) {
  constexpr int N = 2048;
  if (!E) return;
  static float re[N], im[N]; static float sm[256] = {};
  int w = E->tapW.load(std::memory_order_acquire);
  for (int i = 0; i < N; i++) {
    re[i] = E->tap[(w - N + i + Engine::TAP) % Engine::TAP] * (.5f - .5f * cosf(2 * PI * i / (N - 1)));
    im[i] = 0;
  }
  for (int i = 1, j = 0; i < N; i++) {
    int bit = N >> 1; for (; j & bit; bit >>= 1) j ^= bit; j ^= bit;
    if (i < j) { std::swap(re[i], re[j]); std::swap(im[i], im[j]); }
  }
  for (int len = 2; len <= N; len <<= 1) {
    float ang = -2 * PI / len, wr = cosf(ang), wi = sinf(ang);
    for (int i = 0; i < N; i += len) {
      float cr = 1, ci = 0;
      for (int k = 0; k < len / 2; k++) {
        int a = i + k, b = a + len / 2;
        float tr = re[b] * cr - im[b] * ci, ti = re[b] * ci + im[b] * cr;
        re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
        float nr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = nr;
      }
    }
  }
  int nb = std::min((int)env->GetArrayLength(out), 256);
  jfloat* o = env->GetFloatArrayElements(out, nullptr);
  float fs = E->peq.fs;
  for (int b = 0; b < nb; b++) {
    float f0 = 20 * powf(1000, (float)b / nb), f1 = 20 * powf(1000, (float)(b + 1) / nb);
    int k0 = std::max(1, (int)(f0 / fs * N)), k1 = std::max(k0 + 1, (int)(f1 / fs * N));
    float m = 0; for (int k = k0; k < std::min(k1, N / 2); k++) m = std::max(m, re[k] * re[k] + im[k] * im[k]);
    float db = 10 * log10f(m / (N * N / 16.f) + 1e-12f);
    float v = std::clamp((db + 90) / 90.f, 0.f, 1.f);
    sm[b] += (v > sm[b] ? .6f : .12f) * (v - sm[b]);
    o[b] = sm[b];
  }
  env->ReleaseFloatArrayElements(out, o, 0);
}
}
