#pragma once
#include <atomic>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <mutex>
#include <vector>
#include <memory>
constexpr float PI = 3.14159265f;
inline float dbl(float db) { return powf(10.f, db / 20.f); }

enum FType { PEAK, LSHELF, HSHELF, LPF, HPF, NOTCH, LPF24, HPF24, BPF };
struct Coef { float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0; };

inline Coef rbj(int t, float fs, float f, float gdb, float Q) {
  f = std::clamp(f, 10.f, fs * 0.49f);
  float A = powf(10.f, gdb / 40.f), w = 2 * PI * f / fs, c = cosf(w), s = sinf(w);
  float al = s / (2 * Q), k = 2 * sqrtf(A) * al, b0, b1, b2, a0, a1, a2;
  switch (t) {
    case PEAK:   b0 = 1 + al * A; b1 = -2 * c; b2 = 1 - al * A; a0 = 1 + al / A; a1 = -2 * c; a2 = 1 - al / A; break;
    case LSHELF: b0 = A * ((A + 1) - (A - 1) * c + k); b1 = 2 * A * ((A - 1) - (A + 1) * c);
                 b2 = A * ((A + 1) - (A - 1) * c - k); a0 = (A + 1) + (A - 1) * c + k;
                 a1 = -2 * ((A - 1) + (A + 1) * c);    a2 = (A + 1) + (A - 1) * c - k; break;
    case HSHELF: b0 = A * ((A + 1) + (A - 1) * c + k); b1 = -2 * A * ((A - 1) + (A + 1) * c);
                 b2 = A * ((A + 1) + (A - 1) * c - k); a0 = (A + 1) - (A - 1) * c + k;
                 a1 = 2 * ((A - 1) - (A + 1) * c);     a2 = (A + 1) - (A - 1) * c - k; break;
    case LPF:    b0 = (1 - c) / 2; b1 = 1 - c; b2 = b0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
    case HPF:    b0 = (1 + c) / 2; b1 = -(1 + c); b2 = b0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
    case BPF:    b0 = al; b1 = 0; b2 = -al; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
    default:     b0 = 1; b1 = -2 * c; b2 = 1; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
  }
  float n = 1.f / a0;
  return {b0 * n, b1 * n, b2 * n, a1 * n, a2 * n};
}

struct BQ {
  float z1[2] = {}, z2[2] = {};
  inline float run(const Coef& c, float x, int ch) {
    float y = c.b0 * x + z1[ch];
    z1[ch] = c.b1 * x - c.a1 * y + z2[ch];
    z2[ch] = c.b2 * x - c.a2 * y;
    return y;
  }
};

struct Band { int type = PEAK; float f = 1000, g = 0, q = 4.3f; bool byp = false; };

struct Peq {
  float fs = 48000;
  Coef c[2][34][2]; int n[2][34] = {};
  std::atomic<int> act{0}; std::mutex mtx; std::atomic<bool> enabled{true};
  BQ st[34][2];

  int stages(const Band& b, Coef* o) {
    if (b.byp) return 0;
    switch (b.type) {
      case LPF24: o[0] = rbj(LPF, fs, b.f, 0, .5412f); o[1] = rbj(LPF, fs, b.f, 0, 1.3066f); return 2;
      case HPF24: o[0] = rbj(HPF, fs, b.f, 0, .5412f); o[1] = rbj(HPF, fs, b.f, 0, 1.3066f); return 2;
      case PEAK: case LSHELF: case HSHELF:
        if (fabsf(b.g) < 0.01f) return 0;
        o[0] = rbj(b.type, fs, b.f, b.g, b.q); return 1;
      default: o[0] = rbj(b.type, fs, b.f, b.g, b.q); return 1;
    }
  }
  void set(int i, const Band& b) {
    if (i < 0 || i >= 34) return;
    std::lock_guard<std::mutex> l(mtx);
    int a = act.load(), s = 1 - a;
    memcpy(c[s], c[a], sizeof c[s]); memcpy(n[s], n[a], sizeof n[s]);
    n[s][i] = stages(b, c[s][i]);
    act.store(s, std::memory_order_release);
  }
  void process(float* x, int frames) {
    if (!enabled.load(std::memory_order_relaxed)) return;
    int a = act.load(std::memory_order_acquire);
    for (int b = 0; b < 34; b++)
      for (int k = 0; k < n[a][b]; k++) {
        const Coef& C = c[a][b][k]; BQ& s = st[b][k];
        for (int i = 0; i < frames; i++) {
          x[2 * i]     = s.run(C, x[2 * i], 0);
          x[2 * i + 1] = s.run(C, x[2 * i + 1], 1);
        }
      }
  }
};

// Sub-harmonic synthesizer: band-limited pitch tracker -> octave-down generator
// (oscillator or flip-flop) -> smoothing -> 2x-oversampled saturator -> subsonic HP.
struct SubSynth {
  std::atomic<float> sweep{45.f}, wide{0.7f}, smooth{1.2f}, sens{0.73f}, drive{0.3f}, pfm{21.f}, gainDb{6.f};
  std::atomic<int> voice{0}, gen{0};
  std::atomic<bool> autoSweep{false};
  std::atomic<float> pitchIn{0}, pitchSub{0}, lockedF{0}, peakSub{0};

  float fs = 48000, aE = .005f, rE = .0007f, env = 0, gate = 0, fIn = 90, ph = 0, ff = 1, sweepEff = 45.f;
  float curC = -1, curQ = -1, curS = -1, curP = -1, sx = 0;
  bool pos = false; int since = 0, sinceValid = 1000000;
  BQ bp, lp1, lp2, hp, aa; Coef cbp, clp, chp, caa;

  void init(float f) {
    fs = f; aE = 1 - expf(-1 / (.004f * fs)); rE = 1 - expf(-1 / (.060f * fs));
    caa = rbj(LPF, 2 * fs, .45f * fs, 0, .707f);
    curC = curQ = curS = curP = -1;
  }
  void process(float* x, int n) {
    float sw = sweep.load(), q = wide.load(), sm = smooth.load(), sn = sens.load();
    float dr = drive.load(), pf = pfm.load(), g = gainDb.load();
    int vo = voice.load(), ge = gen.load(); bool au = autoSweep.load();
    float thr = 0.03f * powf(0.01f, sn);
    float gain = g <= -59.5f ? 0.f : dbl(g);
    float k = 1 + dr * 9, bias = .15f * dr, tk = tanhf(k * bias), comp = 1.f / sqrtf(k);
    if (!au) sweepEff = sw;
    float centre = 2 * sweepEff;
    if (fabsf(centre - curC) > 0.05f || q != curQ) { cbp = rbj(BPF, fs, centre, 0, q); curC = centre; curQ = q; }
    if (pf != curP) { chp = rbj(HPF, fs, std::max(pf, 5.f), 0, .707f); curP = pf; }
    float vmul = vo == 0 ? 1.f : (vo == 1 ? 1.6f : 2.4f);
    float cut = std::clamp(fIn * 0.5f * sm * vmul, 15.f, 500.f);
    if (fabsf(cut - curS) > 0.5f) { clp = rbj(LPF, fs, cut, 0, .707f); curS = cut; }
    int minP = (int)(fs / 126.f), maxP = (int)(fs / 54.f);
    float peak = 0; bool locked = false;
    for (int i = 0; i < n; i++) {
      float m = .5f * (x[2 * i] + x[2 * i + 1]);
      float d = bp.run(cbp, m, 0);
      float ad = fabsf(d);
      env += (ad > env ? aE : rE) * (ad - env);
      float h = std::max(.35f * env, 1e-5f);
      ++since; if (sinceValid < 1000000) ++sinceValid;
      bool rise = false;
      if (!pos && d > h) { pos = true; rise = true; } else if (pos && d < -h) pos = false;
      if (rise) {
        int p = since; since = 0;
        if (p >= minP && p <= maxP) {
          float fi = fs / (float)p;
          fIn = ((float)sinceValid > 0.05f * fs) ? fi : fIn + 0.25f * (fi - fIn);
          sinceValid = 0;
          if (ge == 1) ff = -ff;
        }
      }
      locked = ((float)sinceValid < 0.06f * fs) && env > thr;
      if (au && locked) sweepEff = std::clamp(sweepEff + 0.0004f * (fIn * 0.5f - sweepEff), 27.f, 63.f);
      float gt = locked ? 1.f : 0.f;
      gate += (gt > gate ? 0.004f : 0.0015f) * (gt - gate);
      float s;
      if (ge == 0) {
        ph += fIn * 0.5f / fs; if (ph >= 1.f) ph -= 1.f;
        s = vo == 0 ? sinf(2 * PI * ph) : (vo == 1 ? (2 * ph - 1) : (ph < .5f ? 1.f : -1.f));
      } else s = ff;
      s = lp2.run(clp, lp1.run(clp, s, 0), 0);
      float sub = s * gate * std::min(env * 1.6f, 1.f);
      float u0 = .5f * (sx + sub), u1 = sub; sx = sub;
      aa.run(caa, tanhf(k * (u0 + bias)) - tk, 1);
      float y = aa.run(caa, tanhf(k * (u1 + bias)) - tk, 1) * comp;
      y = hp.run(chp, y, 0) * gain;
      x[2 * i] += y; x[2 * i + 1] += y;
      peak = std::max(peak, fabsf(y));
    }
    pitchIn.store(locked ? fIn : 0.f); pitchSub.store(locked ? fIn * 0.5f : 0.f);
    lockedF.store(locked ? 1.f : 0.f);
    peakSub.store(std::max(peak, peakSub.load() * expf(-(float)n / (0.3f * fs))));
  }
};

struct Limiter {
  static constexpr int N = 64;
  float dl[N][2] = {}, gm[N], g = 1, atk = .9f, rel = .999f; int w = 0;
  std::atomic<float> ceilLin{.89f};
  Limiter() { for (auto& v : gm) v = 1; }
  void init(float fs) { atk = expf(-1 / (.0003f * fs)); rel = expf(-1 / (.08f * fs)); }
  inline void run(float& L, float& R) {
    float ceil = ceilLin.load(std::memory_order_relaxed);
    float pk = std::max(fabsf(L), fabsf(R));
    gm[w] = pk > ceil ? ceil / pk : 1.f; dl[w][0] = L; dl[w][1] = R; w = (w + 1) % N;
    float m = 1; for (int i = 0; i < N; i++) m = std::min(m, gm[i]);
    float c = m < g ? atk : rel; g = c * g + (1 - c) * m;
    L = std::clamp(dl[w][0] * g, -1.f, 1.f); R = std::clamp(dl[w][1] * g, -1.f, 1.f);
  }
};
