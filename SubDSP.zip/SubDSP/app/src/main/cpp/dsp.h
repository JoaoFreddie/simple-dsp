#pragma once
#include <atomic>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <mutex>
#include <vector>
#include <memory>
constexpr float PI = 3.14159265f;
inline float dbl(float db) { return powf(10.f, db / 20.f); }

enum FType { PEAK, LSHELF, HSHELF, LPF, HPF, NOTCH, LPF24, HPF24 };
struct Coef { float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0; };

inline Coef rbj(int t, float fs, float f, float gdb, float Q) {
  f = std::clamp(f, 10.f, fs * 0.49f);
  float A = powf(10.f, gdb / 40.f), w = 2 * PI * f / fs, c = cosf(w), s = sinf(w);
  float al = s / (2 * Q), k = 2 * sqrtf(A) * al, b0, b1, b2, a0, a1, a2;
  switch (t) {
    case PEAK:   b0 = 1 + al * A; b1 = -2 * c; b2 = 1 - al * A; a0 = 1 + al / A; a1 = -2 * c; a2 = 1 - al / A; break;
    case LSHELF: b0 = A * ((A + 1) - (A - 1) * c + k); b1 = 2 * A * ((A - 1) - (A + 1) * c);
                 b2 = A * ((A + 1) - (A - 1) * c - k); a0 = (A + 1) + (A - 1) * c + k;
                 a1 = -2 * ((A - 1) + (A + 1) * c);    a2 = (A + 1) + (A - 1) * c - k; break;
    case HSHELF: b0 = A * ((A + 1) + (A - 1) * c + k); b1 = -2 * A * ((A - 1) + (A + 1) * c);
                 b2 = A * ((A + 1) + (A - 1) * c - k); a0 = (A + 1) - (A - 1) * c + k;
                 a1 = 2 * ((A - 1) - (A + 1) * c);     a2 = (A + 1) - (A - 1) * c - k; break;
    case LPF:    b0 = (1 - c) / 2; b1 = 1 - c; b2 = b0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
    case HPF:    b0 = (1 + c) / 2; b1 = -(1 + c); b2 = b0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
    default:     b0 = 1; b1 = -2 * c; b2 = 1; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
  }
  float n = 1.f / a0;
  return {b0 * n, b1 * n, b2 * n, a1 * n, a2 * n};
}

struct BQ {
  float z1[2] = {}, z2[2] = {};
  inline float run(const Coef& c, float x, int ch) {
    float y = c.b0 * x + z1[ch];
    z1[ch] = c.b1 * x - c.a1 * y + z2[ch];
    z2[ch] = c.b2 * x - c.a2 * y;
    return y;
  }
};

struct Band { int type = PEAK; float f = 1000, g = 0, q = 4.3f; bool byp = false; };

struct Peq {
  float fs = 48000;
  Coef c[2][32][2]; int n[2][32] = {};
  std::atomic<int> act{0}; std::mutex mtx;
  BQ st[32][2];

  int stages(const Band& b, Coef* o) {
    if (b.byp) return 0;
    switch (b.type) {
      case LPF24: o[0] = rbj(LPF, fs, b.f, 0, .5412f); o[1] = rbj(LPF, fs, b.f, 0, 1.3066f); return 2;
      case HPF24: o[0] = rbj(HPF, fs, b.f, 0, .5412f); o[1] = rbj(HPF, fs, b.f, 0, 1.3066f); return 2;
      case PEAK: case LSHELF: case HSHELF:
        if (fabsf(b.g) < 0.01f) return 0;
        o[0] = rbj(b.type, fs, b.f, b.g, b.q); return 1;
      default: o[0] = rbj(b.type, fs, b.f, b.g, b.q); return 1;
    }
  }
  void set(int i, const Band& b) {
    if (i < 0 || i >= 32) return;
    std::lock_guard<std::mutex> l(mtx);
    int a = act.load(), s = 1 - a;
    memcpy(c[s], c[a], sizeof c[s]); memcpy(n[s], n[a], sizeof n[s]);
    n[s][i] = stages(b, c[s][i]);
    act.store(s, std::memory_order_release);
  }
  void process(float* x, int frames) {
    int a = act.load(std::memory_order_acquire);
    for (int b = 0; b < 32; b++)
      for (int k = 0; k < n[a][b]; k++) {
        const Coef& C = c[a][b][k]; BQ& s = st[b][k];
        for (int i = 0; i < frames; i++) {
          x[2 * i]     = s.run(C, x[2 * i], 0);
          x[2 * i + 1] = s.run(C, x[2 * i + 1], 1);
        }
      }
  }
};

struct Epicenter {
  std::atomic<float> drive{.4f}, freq{45.f}, width{1.f}, lvlDb{6.f}, mix{1.f};
  float fs = 48000, env = 0, aE = .01f, rE = .001f, ff = 1, lastSign = -1, sx = 0, cf = -1, cw = -1;
  BQ hp, lp, s1, s2, aa; Coef chp, clp, cs, caa;

  void init(float f) {
    fs = f; aE = 1 - expf(-1 / (.010f * fs)); rE = 1 - expf(-1 / (.080f * fs));
    caa = rbj(LPF, 2 * fs, .45f * fs, 0, .707f);
    cf = cw = -1;
  }
  void process(float* x, int frames) {
    float F = freq.load(), W = width.load();
    if (F != cf || W != cw) {
      cf = F; cw = W;
      chp = rbj(HPF, fs, 60.f / W, 0, .707f);
      clp = rbj(LPF, fs, 160.f * W, 0, .707f);
      cs  = rbj(LPF, fs, F * 1.1f, 0, .707f);
    }
    float dr = drive.load(), k = 1 + dr * 9, bias = .15f * dr, tk = tanhf(k * bias);
    float gain = dbl(lvlDb.load()) * mix.load() / sqrtf(k);
    for (int i = 0; i < frames; i++) {
      float m = .5f * (x[2 * i] + x[2 * i + 1]);
      float d = lp.run(clp, hp.run(chp, m, 0), 0);
      float ad = fabsf(d); env += (ad > env ? aE : rE) * (ad - env);
      if (lastSign < 0 && d > .003f) { ff = -ff; lastSign = 1; }
      else if (d < -.003f) lastSign = -1;
      float sub = s2.run(cs, s1.run(cs, ff, 0), 0) * env * 2.f;
      float u0 = .5f * (sx + sub), u1 = sub; sx = sub;
      aa.run(caa, tanhf(k * (u0 + bias)) - tk, 1);
      float y = aa.run(caa, tanhf(k * (u1 + bias)) - tk, 1);
      x[2 * i] += gain * y; x[2 * i + 1] += gain * y;
    }
  }
};

struct Limiter {
  static constexpr int N = 64;
  float dl[N][2] = {}, gm[N], g = 1, atk = .9f, rel = .999f; int w = 0;
  std::atomic<float> ceilLin{.89f};
  Limiter() { for (auto& v : gm) v = 1; }
  void init(float fs) { atk = expf(-1 / (.0003f * fs)); rel = expf(-1 / (.08f * fs)); }
  inline void run(float& L, float& R) {
    float ceil = ceilLin.load(std::memory_order_relaxed);
    float pk = std::max(fabsf(L), fabsf(R));
    gm[w] = pk > ceil ? ceil / pk : 1.f; dl[w][0] = L; dl[w][1] = R; w = (w + 1) % N;
    float m = 1; for (int i = 0; i < N; i++) m = std::min(m, gm[i]);
    float c = m < g ? atk : rel; g = c * g + (1 - c) * m;
    L = std::clamp(dl[w][0] * g, -1.f, 1.f); R = std::clamp(dl[w][1] * g, -1.f, 1.f);
  }
};
