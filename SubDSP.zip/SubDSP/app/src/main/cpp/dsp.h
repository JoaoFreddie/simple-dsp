#pragma once
#include <atomic>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <mutex>
#include <vector>
#include <memory>
constexpr float PI = 3.14159265f;
constexpr double PI_D = 3.14159265358979323846;
inline float dbl(float db) { return powf(10.f, db / 20.f); }

enum FType { PEAK, LSHELF, HSHELF, LPF, HPF, NOTCH, LPF24, HPF24, BPF };

// Filters run in double precision: float TDF2 biquads are noisy and can misbehave around 20-40 Hz at 48 kHz.
struct Coef { double b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0; };

inline Coef rbj(int t, double fs, double f, double gdb, double Q) {
  f = std::clamp(f, 5.0, fs * 0.49);
  Q = std::max(Q, 0.05);
  double A = pow(10.0, gdb / 40.0), w = 2 * PI_D * f / fs, c = cos(w), s = sin(w);
  double al = s / (2 * Q), k = 2 * sqrt(A) * al, b0, b1, b2, a0, a1, a2;
  switch (t) {
    case PEAK:   b0 = 1 + al * A; b1 = -2 * c; b2 = 1 - al * A; a0 = 1 + al / A; a1 = -2 * c; a2 = 1 - al / A; break;
    case LSHELF: b0 = A * ((A + 1) - (A - 1) * c + k); b1 = 2 * A * ((A - 1) - (A + 1) * c);
                 b2 = A * ((A + 1) - (A - 1) * c - k); a0 = (A + 1) + (A - 1) * c + k;
                 a1 = -2 * ((A - 1) + (A + 1) * c);    a2 = (A + 1) + (A - 1) * c - k; break;
    case HSHELF: b0 = A * ((A + 1) + (A - 1) * c + k); b1 = -2 * A * ((A - 1) + (A + 1) * c);
                 b2 = A * ((A + 1) + (A - 1) * c - k); a0 = (A + 1) - (A - 1) * c + k;
                 a1 = 2 * ((A - 1) - (A + 1) * c);     a2 = (A + 1) - (A - 1) * c - k; break;
    case LPF:    b0 = (1 - c) / 2; b1 = 1 - c; b2 = b0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
    case HPF:    b0 = (1 + c) / 2; b1 = -(1 + c); b2 = b0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
    case BPF:    b0 = al; b1 = 0; b2 = -al; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
    default:     b0 = 1; b1 = -2 * c; b2 = 1; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al; break;
  }
  double n = 1.0 / a0;
  return {b0 * n, b1 * n, b2 * n, a1 * n, a2 * n};
}

struct BQ {
  double z1[2] = {}, z2[2] = {};
  inline double run(const Coef& c, double x, int ch = 0) {
    double y = c.b0 * x + z1[ch];
    z1[ch] = c.b1 * x - c.a1 * y + z2[ch];
    z2[ch] = c.b2 * x - c.a2 * y;
    return y;
  }
  void reset() { z1[0] = z1[1] = z2[0] = z2[1] = 0; }
};

struct Band { int type = PEAK; float f = 1000, g = 0, q = 4.3f; bool byp = false; };

// 34 slots: 0..31 user bands, 32/33 bass+treble tone shelves.
// The UI thread writes into `pend`; the audio thread picks it up with try_lock at the start of a block,
// so it never blocks and never reads half-written coefficients.
struct Peq {
  static constexpr int NB = 34;
  float fs = 48000;
  Coef live[NB][2]; int nl[NB] = {}; BQ st[NB][2];
  Coef pend[NB][2]; int np[NB] = {}; Band bd[NB];
  std::mutex mtx; std::atomic<bool> dirty{false}; std::atomic<bool> enabled{true};

  int stages(const Band& b, Coef* o) {
    if (b.byp) return 0;
    switch (b.type) {
      case LPF24: o[0] = rbj(LPF, fs, b.f, 0, .5412); o[1] = rbj(LPF, fs, b.f, 0, 1.3066); return 2;
      case HPF24: o[0] = rbj(HPF, fs, b.f, 0, .5412); o[1] = rbj(HPF, fs, b.f, 0, 1.3066); return 2;
      case PEAK: case LSHELF: case HSHELF:
        if (fabsf(b.g) < 0.01f) return 0;
        o[0] = rbj(b.type, fs, b.f, b.g, b.q); return 1;
      default: o[0] = rbj(b.type, fs, b.f, b.g, b.q); return 1;
    }
  }
  void set(int i, const Band& b) {
    if (i < 0 || i >= NB) return;
    std::lock_guard<std::mutex> l(mtx);
    bd[i] = b;
    np[i] = stages(b, pend[i]);
    dirty.store(true, std::memory_order_release);
  }
  // The real stream rate is only known after the stream is open: re-derive every coefficient for it.
  void setRate(float f) {
    std::lock_guard<std::mutex> l(mtx);
    fs = f;
    for (int i = 0; i < NB; i++) np[i] = stages(bd[i], pend[i]);
    dirty.store(true, std::memory_order_release);
  }
  void sync() {
    if (!dirty.load(std::memory_order_acquire)) return;
    if (!mtx.try_lock()) return;
    for (int i = 0; i < NB; i++) {
      for (int k = 0; k < 2; k++) live[i][k] = pend[i][k];
      for (int k = np[i]; k < nl[i]; k++) st[i][k].reset();
      nl[i] = np[i];
    }
    dirty.store(false, std::memory_order_release);
    mtx.unlock();
  }
  void process(float* x, int frames) {
    sync();
    if (!enabled.load(std::memory_order_relaxed)) return;
    for (int b = 0; b < NB; b++)
      for (int k = 0; k < nl[b]; k++) {
        const Coef& C = live[b][k]; BQ& s = st[b][k];
        for (int i = 0; i < frames; i++) {
          x[2 * i]     = (float)s.run(C, x[2 * i], 0);
          x[2 * i + 1] = (float)s.run(C, x[2 * i + 1], 1);
        }
      }
  }
};

// ---------------------------------------------------------------------------------------------
// Sub-harmonic synthesiser (v2)
//
//   mono -> band-pass around 2x sweep -> sub-sample zero-crossing period (median of 3, outlier-rejected)
//        -> glide-limited frequency -> phase-locked octave-down oscillator (true divide-by-two relation to the
//           input, so the sub reinforces the original bass instead of beating against it)
//        -> Butterworth smoothing -> even-harmonic shaper (adds the octave = original fundamental, no
//           "ghost fifth") -> smooth envelope * gate -> subsonic high-pass -> gain.
//
// What changed vs v1 and why it sounds smoother:
//  * envelope was a fast |x| follower => 180 Hz ripple modulated the sub (buzz). Now peak follower + 8 ms smoothing.
//  * pitch jitter went straight into the oscillator. Now: median filter + slew, phase continuous.
//  * on/off gate was binary with a 14 ms release (pumping). Now continuous, longer release, tail keeps last pitch.
//  * saturator was symmetric tanh (odd harmonics = 1.5x the original => dissonant). Now even-harmonic shaper.
//  * saw/square voices were 4-6 dB louder than sine and aliased. Now level matched and polyBLEP.
// ---------------------------------------------------------------------------------------------
struct SubSynth {
  std::atomic<float> sweep{45.f}, wide{0.7f}, smooth{1.2f}, sens{0.73f}, drive{0.3f}, pfm{21.f}, gainDb{6.f};
  std::atomic<int> voice{0}, gen{0};
  std::atomic<bool> autoSweep{false};
  std::atomic<float> pitchIn{0}, pitchSub{0}, lockedF{0}, peakSub{0};

  double fs = 48000;
  static constexpr int CHUNK = 32;
  // filters
  BQ bp, lpa, lpb, hp, dl1, dl2; Coef cbp, clpa, clpb, chp, cdl1, cdl2;
  double curC = -1, curQ = -1, curS = -1, curP = -1, curD = -1;
  // detector
  double d1 = 0, tNow = 0, tcPrev = -1, lastGood = -1e9, hist[3] = {0, 0, 0}; int nh = 0;
  bool armed = false;
  double fTrack = 90, fOsc = 90, cand = 0, pRaw = 0; int candN = 0;
  // envelope / gate
  double envF = 0, env = 0, gate = 0, aE = 0, rE = 0, eS = 0, gA = 0, gR = 0, sweepEff = 45, gainS = 1;
  // oscillator
  double ph = 0, pend = 0; int par = 0;
  // scratch for pass-through
  bool lockedNow = false;

  void init(float f) {
    fs = f;
    aE = 1 - exp(-1 / (.003 * fs)); rE = 1 - exp(-1 / (.060 * fs)); eS = 1 - exp(-1 / (.008 * fs));
    gA = 1 - exp(-1 / (.006 * fs)); gR = 1 - exp(-1 / (.150 * fs));
    reset();
  }
  void reset() {
    bp.reset(); lpa.reset(); lpb.reset(); hp.reset(); dl1.reset(); dl2.reset();
    curC = curQ = curS = curP = curD = -1;
    d1 = 0; tNow = 0; tcPrev = -1; lastGood = -1e9; nh = 0; armed = false; candN = 0; pRaw = 0;
    envF = env = gate = 0; ph = 0; pend = 0; par = 0; lockedNow = false;
    fTrack = fOsc = 90; sweepEff = sweep.load(); gainS = 1;
  }

  static inline double blep(double t, double dt) {
    if (t < dt) { t /= dt; return t + t - t * t - 1.0; }
    if (t > 1.0 - dt) { t = (t - 1.0) / dt; return t * t + t + t + 1.0; }
    return 0.0;
  }
  static inline double med3(double a, double b, double c) {
    return std::max(std::min(a, b), std::min(std::max(a, b), c));
  }

  // Renders ONLY the sub signal (mono) for n frames of stereo input.
  void render(const float* x, float* out, int n) {
    const double sw = sweep.load(), q = wide.load(), sm = smooth.load(), sn = sens.load();
    const double dr = drive.load(), pf = pfm.load(), g = gainDb.load();
    const int vo = voice.load(), ge = gen.load(); const bool au = autoSweep.load();
    const double thr = 0.03 * pow(0.01, sn);
    const double gainT = g <= -59.5 ? 0.0 : pow(10.0, g / 20.0);
    const double e2 = 1.6 * dr;                          // even-harmonic amount (2nd harmonic of the sub = original f)
    const double kc = 1.0 + 1.5 * dr;                    // soft clip
    const double meanSq = vo == 0 ? .5 : (vo == 1 ? .82 : .617);
    const double vscale = vo == 0 ? 1.0 : (vo == 1 ? 1.5708 : 0.7854);   // equal fundamental level for every voice
    const double vmul = vo == 0 ? 1.0 : (vo == 1 ? 1.6 : 2.4);
    const double pMin = fs / 140.0, pMax = fs / 50.0;
    if (!au) sweepEff = sw;
    if (fabs(pf - curP) > 0.01) { chp = rbj(HPF, fs, std::max(pf, 5.0), 0, .7071); curP = pf; }
    if (q != curQ) curC = -1;
    double peak = 0;

    for (int i = 0; i < n; i++) {
      if ((i % CHUNK) == 0) {
        double centre = 2 * sweepEff;
        if (fabs(centre - curC) > 0.05 || q != curQ) { cbp = rbj(BPF, fs, centre, 0, q); curC = centre; curQ = q; }
        double cd = std::clamp(centre * 1.25, 60.0, 170.0);
        if (fabs(cd - curD) > 0.5) { cdl1 = rbj(LPF, fs, cd, 0, .5412); cdl2 = rbj(LPF, fs, cd, 0, 1.3066); curD = cd; }
        double cut = std::clamp(fOsc * 0.5 * sm * vmul, 15.0, 500.0);
        if (fabs(cut - curS) > 0.3) { clpa = rbj(LPF, fs, cut, 0, .5412); clpb = rbj(LPF, fs, cut, 0, 1.3066); curS = cut; }
      }
      double m = 0.5 * ((double)x[2 * i] + (double)x[2 * i + 1]);
      double d = bp.run(cbp, dl2.run(cdl2, dl1.run(cdl1, m, 0), 0), 0);
      double ad = fabs(d);
      envF += (ad > envF ? aE : rE) * (ad - envF);
      env += eS * (envF - env);

      // ---- period detector: sub-sample rising zero crossing with hysteresis ----
      double h = std::max(0.40 * envF, 1e-6);
      if (!armed && d < -h) armed = true;
      if (armed && d1 <= 0.0 && d > 0.0) {
        armed = false;
        double tc = tNow - 1.0 + (-d1) / (d - d1);
        double p = tc - tcPrev;
        bool had = tcPrev >= 0; tcPrev = tc;
        // A real bass note repeats: two consecutive periods must agree (within 15 %), otherwise it is a stray crossing.
        bool steady = had && pRaw > 0 && fabs(p - pRaw) < 0.15 * pRaw;
        if (had) pRaw = p;
        if (had && p >= pMin && p <= pMax && steady) {
          hist[2] = hist[1]; hist[1] = hist[0]; hist[0] = p; nh = std::min(nh + 1, 3);
          double pm = nh >= 3 ? med3(hist[0], hist[1], hist[2]) : (nh == 2 ? 0.5 * (hist[0] + hist[1]) : p);
          double fm = fs / pm;
          bool fresh = (tc - lastGood) > 0.12 * fs;
          bool ok = true;
          if (!fresh && (fm < fTrack * 0.8 || fm > fTrack * 1.25)) {
            // possible octave error / stray crossing: only follow it if two measurements in a row agree
            if (candN > 0 && fabs(fm - cand) < 0.12 * cand) { candN = 0; fTrack = fm; }
            else { cand = fm; candN = 1; ok = false; }
          } else {
            candN = 0;
            fTrack = fresh ? fm : fTrack + 0.35 * (fm - fTrack);
          }
          if (ok) {
            if (fresh) { fOsc = fTrack; }
            lastGood = tc;
            // phase lock: after an input cycle the sub phase must be 0 or 0.5 (divide by two)
            par ^= 1;
            double pe = par ? 0.5 : 0.0, e = pe - ph; e -= floor(e + 0.5);
            if (fabs(e) > 0.25) { par ^= 1; pe = par ? 0.5 : 0.0; e = pe - ph; e -= floor(e + 0.5); }
            if (gate < 0.05) { ph = pe; pend = 0; } else pend += 0.30 * e;
          }
        } else if (had && !steady) { nh = 0; }
      }
      d1 = d; tNow += 1.0;

      bool locked = (tNow - lastGood) < 0.60 * fs && env > thr * 0.5;
      lockedNow = locked;
      if (au && locked) sweepEff = std::clamp(sweepEff + 0.0002 * (fTrack * 0.5 - sweepEff), 27.0, 63.0);
      double gt = locked ? 1.0 : 0.0;
      gate += (gt > gate ? gA : gR) * (gt - gate);
      {   // glide: exponential approach, but never faster than one octave per 60 ms, so a wrong detection
          // becomes a short smooth slide instead of a jump
        double lr = log2(fTrack / fOsc), st = std::clamp(lr * 0.004, -1.0 / (0.06 * fs), 1.0 / (0.06 * fs));
        fOsc *= exp2(st);
      }

      // ---- oscillator ----
      double dt = fOsc * 0.5 / fs;
      double corr = pend * (1.0 / 48.0); pend -= corr;      // spread phase corrections over ~1 ms, no clicks
      ph += dt + corr; ph -= floor(ph);
      double s;
      if (ge == 0) {
        s = vo == 0 ? sin(2 * PI_D * ph)
          : vo == 1 ? (2 * ph - 1 - blep(ph, dt))
                    : ((ph < .5 ? 1.0 : -1.0) + blep(ph, dt) - blep(ph + .5 >= 1.0 ? ph - .5 : ph + .5, dt));
      } else {
        // flip: hard divide-by-two square straight from the phase-locked divider; edges follow the input cycles
        s = ph < .5 ? 1.0 : -1.0;
      }
      s *= (ge == 0 ? vscale : 0.7854);
      s = lpb.run(clpb, lpa.run(clpa, s, 0), 0);

      // ---- shaper on the unit-level voice (timbre does not change with volume) ----
      double w = s + e2 * (s * s - meanSq);
      w = tanh(0.6 * kc * w) / (0.6 * kc);                 // transparent at drive 0, rounds peaks as drive rises
      double amp = std::min(1.25 * pow(std::max(env * 1.6, 0.0), 0.85), 1.2) * gate;   // slightly compressive: quiet bass stays audible
      gainS += 0.002 * (gainT - gainS);
      double y = hp.run(chp, w * amp, 0) * gainS;
      out[i] = (float)y;
      peak = std::max(peak, fabs(y));
    }
    pitchIn.store(lockedNow ? (float)fTrack : 0.f); pitchSub.store(lockedNow ? (float)(fTrack * 0.5) : 0.f);
    lockedF.store(lockedNow ? 1.f : 0.f);
    peakSub.store(std::max((float)peak, peakSub.load() * expf(-(float)n / (0.3f * (float)fs))));
  }

  // Adds the sub on top of the stereo signal in place.
  void process(float* x, int n) {
    float tmp[1024];
    for (int o = 0; o < n; o += 1024) {
      int c = std::min(1024, n - o);
      render(x + 2 * o, tmp, c);
      for (int i = 0; i < c; i++) { x[2 * (o + i)] += tmp[i]; x[2 * (o + i) + 1] += tmp[i]; }
    }
  }
  // Replaces the stereo signal by the sub alone (Capture mode: original plays by itself).
  void processOnly(float* x, int n) {
    float tmp[1024];
    for (int o = 0; o < n; o += 1024) {
      int c = std::min(1024, n - o);
      render(x + 2 * o, tmp, c);
      for (int i = 0; i < c; i++) { x[2 * (o + i)] = tmp[i]; x[2 * (o + i) + 1] = tmp[i]; }
    }
  }
};

// Look-ahead brick-wall limiter: 4 ms look-ahead, window-minimum of the required gain, release smoothing, then a
// boxcar over the look-ahead so the gain glides down instead of snapping (snapping is what sounds like distortion).
struct Limiter {
  static constexpr int N = 192;
  float dl[N][2] = {}, rb[N], sb[N]; int w = 0; double sum = N; float rs = 1, rel = .999f;
  std::atomic<float> ceilLin{.89f};
  Limiter() { for (int i = 0; i < N; i++) { rb[i] = 1; sb[i] = 1; } }
  void init(float fs) { rel = expf(-1 / (.09f * fs)); reset(); }
  void reset() { for (int i = 0; i < N; i++) { rb[i] = 1; sb[i] = 1; dl[i][0] = dl[i][1] = 0; } sum = N; rs = 1; w = 0; }
  inline void run(float& L, float& R) {
    float ceil = ceilLin.load(std::memory_order_relaxed);
    float pk = std::max(fabsf(L), fabsf(R));
    rb[w] = pk > ceil ? ceil / pk : 1.f; dl[w][0] = L; dl[w][1] = R;
    float m = 1; for (int i = 0; i < N; i++) m = std::min(m, rb[i]);
    rs = m < rs ? m : rs + (1 - rel) * (m - rs);
    sum += (double)rs - sb[w]; sb[w] = rs;
    float g = (float)(sum / N);
    w = (w + 1) % N;
    L = std::clamp(dl[w][0] * g, -1.f, 1.f); R = std::clamp(dl[w][1] * g, -1.f, 1.f);
  }
};

// Punch / vocal / loudness. Runs in the engine only (Shizuku mode), never in the delayed "Capture" path.
//  punch : harmonics (60-240 Hz) generated from the real bass (30-110 Hz). Small speakers and earbuds cannot play a
//          28 Hz sub but the brain rebuilds the kick from its harmonics ("missing fundamental").
//  vocal : lifts the centre-panned voice band (mid channel, 250 Hz-4.5 kHz) and adds presence around 3 kHz.
struct Enhancer {
  std::atomic<float> punch{0.f}, vocal{0.f}, loudDb{0.f};
  double fs = 48000;
  BQ l1, l2, hpb, oh, ol, vh, vl, pres[1]; Coef c1, c2, chpb, coh, col, cvh, cvl, cpres;
  double env = 0, aE = .01, rE = .0004, lastV = -1;
  void init(float f) {
    fs = f;
    c1 = rbj(LPF, fs, 110, 0, .5412); c2 = rbj(LPF, fs, 110, 0, 1.3066); chpb = rbj(HPF, fs, 28, 0, .7071);
    coh = rbj(HPF, fs, 70, 0, .7071); col = rbj(LPF, fs, 240, 0, .7071);
    cvh = rbj(HPF, fs, 250, 0, .7071); cvl = rbj(LPF, fs, 4500, 0, .7071);
    aE = 1 - exp(-1 / (.002 * fs)); rE = 1 - exp(-1 / (.06 * fs));
    l1.reset(); l2.reset(); hpb.reset(); oh.reset(); ol.reset(); vh.reset(); vl.reset(); pres[0].reset(); env = 0; lastV = -1;
  }
  void process(float* x, int n) {
    const double pu = punch.load(), vo = vocal.load();
    if (pu < 0.005 && vo < 0.005) return;
    if (fabs(vo - lastV) > 0.004) { cpres = rbj(PEAK, fs, 3000, 4.0 * vo, 0.9); lastV = vo; }
    for (int i = 0; i < n; i++) {
      double L = x[2 * i], R = x[2 * i + 1], m = 0.5 * (L + R), add = 0;
      if (pu > 0.005) {
        double b = hpb.run(chpb, l2.run(c2, l1.run(c1, m, 0), 0), 0);
        double ab = fabs(b); env += (ab > env ? aE : rE) * (ab - env);
        double u = std::clamp(b / std::max(env, 1e-3), -1.5, 1.5);
        double w = tanh(2.2 * u) + 0.4 * u * u;              // odd + even harmonics; the DC of u*u is removed below
        add += ol.run(col, oh.run(coh, w, 0), 0) * env * pu * 2.5;
      }
      double vm = 0;
      if (vo > 0.005) vm = vl.run(cvl, vh.run(cvh, m, 0), 0) * vo * 0.8;   // centre band only: vocals, snare, lead
      double l = L + add + vm, r = R + add + vm;
      if (vo > 0.005) { l = pres[0].run(cpres, l, 0); r = pres[0].run(cpres, r, 1); }
      x[2 * i] = (float)l; x[2 * i + 1] = (float)r;
    }
  }
};
