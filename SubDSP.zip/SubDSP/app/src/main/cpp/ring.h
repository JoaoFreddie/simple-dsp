#pragma once
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <vector>
#include <algorithm>

// Single-producer / single-consumer frame buffer between the capture thread and the audio callback.
//
// Capture and playback run on different clocks. Without correction the buffer either drains (clicks) or
// slowly fills up to its full size (seconds of lag). The consumer therefore keeps the fill level near a
// target and nudges the read speed by a few parts per thousand with a 4-point Hermite interpolator
// (imperceptible, and exactly 1.0x when the clocks agree).
struct FrameRing {
  std::vector<float> b;               // interleaved stereo
  size_t cap = 0;                     // frames
  std::atomic<uint64_t> head{0}, tail{0};
  // consumer-side state (audio thread only)
  double frac = 0, fillSm = 0, ratio = 1;
  bool primed = false; int fadeIn = 0;
  int64_t target = 1440, maxFill = 5760;
  float fs = 48000;
  std::atomic<uint32_t> underruns{0}, drops{0};
  std::atomic<float> fillMs{0}, ratioOut{1};

  void init(size_t frames, float rate, float targetMs) {
    cap = frames; b.assign(cap * 2, 0.f); head = 0; tail = 0;
    fs = rate; target = (int64_t)(targetMs * 0.001f * rate); maxFill = target * 4;
    frac = 0; fillSm = (double)target; ratio = 1; primed = false; fadeIn = 0;
    underruns = 0; drops = 0;
  }
  // producer
  size_t push(const float* s, size_t nFrames) {
    if (!cap) return 0;
    uint64_t h = head.load(std::memory_order_relaxed), t = tail.load(std::memory_order_acquire);
    size_t used = (size_t)(h - t);
    size_t freeF = cap > used + 2 ? cap - used - 2 : 0;
    size_t n = std::min(nFrames, freeF);
    for (size_t i = 0; i < n; i++) {
      size_t k = (size_t)((h + i) % cap) * 2;
      b[k] = s[2 * i]; b[k + 1] = s[2 * i + 1];
    }
    head.store(h + n, std::memory_order_release);
    return n;
  }
  static inline float hermite(float ym1, float y0, float y1, float y2, float x) {
    return y0 + 0.5f * x * (y1 - ym1 + x * (2 * ym1 - 5 * y0 + 4 * y1 - y2 + x * (3 * (y0 - y1) + y2 - ym1)));
  }
  // consumer: fills out[2*n]
  void pull(float* out, int n) {
    if (!cap) { memset(out, 0, sizeof(float) * 2 * (size_t)n); return; }
    uint64_t h = head.load(std::memory_order_acquire), t = tail.load(std::memory_order_relaxed);
    int64_t avail = (int64_t)(h - t);
    if (primed && avail > maxFill) {           // way too far behind: skip ahead instead of staying late
      t += (uint64_t)(avail - target); avail = target; frac = 0; drops.fetch_add(1);
    }
    if (!primed) {
      if (avail >= target) { primed = true; fadeIn = (int)(0.005f * fs); fillSm = (double)avail; }
      else { memset(out, 0, sizeof(float) * 2 * (size_t)n); return; }
    }
    // slow fill-level estimate -> tiny speed correction (max +-0.3 %)
    fillSm += 0.02 * ((double)avail - fillSm);
    double err = (fillSm - (double)target) / fs;
    ratio = 1.0 + std::clamp(err * 0.15, -0.003, 0.003);
    int done = 0;
    for (; done < n; done++) {
      if (avail < 3) { underruns.fetch_add(1); primed = false; break; }
      size_t i0 = (size_t)(t % cap), im = (size_t)((t + cap - 1) % cap), i1 = (size_t)((t + 1) % cap), i2 = (size_t)((t + 2) % cap);
      float x = (float)frac;
      float l = hermite(b[im * 2], b[i0 * 2], b[i1 * 2], b[i2 * 2], x);
      float r = hermite(b[im * 2 + 1], b[i0 * 2 + 1], b[i1 * 2 + 1], b[i2 * 2 + 1], x);
      if (fadeIn > 0) { float g = 1.f - (float)fadeIn / (0.005f * fs); l *= g; r *= g; fadeIn--; }
      out[2 * done] = l; out[2 * done + 1] = r;
      frac += ratio;
      while (frac >= 1.0) { frac -= 1.0; t++; avail--; }
    }
    if (done < n) memset(out + 2 * done, 0, sizeof(float) * 2 * (size_t)(n - done));
    tail.store(t, std::memory_order_release);
    fillMs.store((float)(fillSm / fs * 1000.0), std::memory_order_relaxed);
    ratioOut.store((float)ratio, std::memory_order_relaxed);
  }
};
