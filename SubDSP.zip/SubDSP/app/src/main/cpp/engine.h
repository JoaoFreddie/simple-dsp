#pragma once
#include <oboe/Oboe.h>
#include "dsp.h"
#include "ring.h"
#if defined(__x86_64__) || defined(__i386__)
#include <xmmintrin.h>
#endif

// Denormals make low-frequency biquads (20-40 Hz) spike the CPU when the music goes quiet -> underruns. Flush them.
inline void enableFlushToZero() {
#if defined(__aarch64__)
  uint64_t fpcr; asm volatile("mrs %0, fpcr" : "=r"(fpcr)); fpcr |= (1ULL << 24); asm volatile("msr fpcr, %0" :: "r"(fpcr));
#elif defined(__x86_64__) || defined(__i386__)
  _mm_setcsr(_mm_getcsr() | 0x8040);
#endif
}

class Engine : public oboe::AudioStreamDataCallback, public oboe::AudioStreamErrorCallback {
 public:
  Peq peq; SubSynth sub; Limiter lim; FrameRing ring;
  std::atomic<float> inG{1}, outG{1}, mDry{0}, mOut{0};
  std::atomic<bool> on{true}, limOn{true}, subOnly{false};
  static constexpr int TAP = 16384;
  float tap[TAP] = {}; std::atomic<int> tapW{0};
  std::shared_ptr<oboe::AudioStream> stream;
  int statCnt = 0; float lat = 0, xr = 0;
  std::atomic<int> lastError{0};
  int rate = 48000, devId = 0, tgtMs = 35;

  bool start(int sr, int deviceId, int targetMs) {
    stop();
    rate = sr; devId = deviceId; tgtMs = std::max(10, targetMs);
    lastError = 0;
    if (!open(deviceId, oboe::SharingMode::Exclusive, oboe::PerformanceMode::LowLatency)) {
      // Some routes (Bluetooth, USB, a muted capture route) refuse exclusive/low-latency or an explicit device: relax step by step.
      if (!open(deviceId, oboe::SharingMode::Shared, oboe::PerformanceMode::None) &&
          !open(0, oboe::SharingMode::Shared, oboe::PerformanceMode::None)) return false;
    }
    float fs = (float)stream->getSampleRate();
    peq.setRate(fs); sub.init(fs); lim.init(fs);
    ring.init((size_t)(fs * 1.0f), fs, (float)tgtMs);
    // keep the device buffer small but not at the bare burst size: the ring absorbs the capture jitter
    stream->setBufferSizeInFrames(std::max(stream->getFramesPerBurst() * 2, stream->getBufferSizeInFrames()));
    return stream->requestStart() == oboe::Result::OK;
  }
  void stop() {
    if (stream) { stream->stop(); stream->close(); stream.reset(); }
  }

  bool open(int deviceId, oboe::SharingMode sm, oboe::PerformanceMode pm) {
    oboe::AudioStreamBuilder b;
    b.setDirection(oboe::Direction::Output)->setPerformanceMode(pm)
     ->setSharingMode(sm)->setFormat(oboe::AudioFormat::Float)
     ->setChannelCount(2)->setSampleRate(rate)->setUsage(oboe::Usage::Media)
     ->setContentType(oboe::ContentType::Music)
     ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
     ->setDataCallback(this)->setErrorCallback(this);
    if (deviceId > 0) b.setDeviceId(deviceId);
    return b.openStream(stream) == oboe::Result::OK;
  }

  // The output device vanished (headphones unplugged, Bluetooth dropped...): reopen on the default route.
  void onErrorAfterClose(oboe::AudioStream*, oboe::Result r) override {
    lastError = (int)r;
    if (r == oboe::Result::ErrorDisconnected) { stream.reset(); start(rate, 0, tgtMs); }
  }

  static void meter(std::atomic<float>& m, float v, float dec) {
    m.store(std::max(v, m.load(std::memory_order_relaxed) * dec), std::memory_order_relaxed);
  }

  oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* data, int32_t n) override {
    enableFlushToZero();
    float* o = (float*)data;
    ring.pull(o, n);
    float dec = expf(-(float)n / (0.3f * peq.fs));
    float gi = inG.load(), go = outG.load(), pd = 0, po = 0;
    bool so = subOnly.load(std::memory_order_relaxed);
    int w = tapW.load(std::memory_order_relaxed);
    for (int i = 0; i < n * 2; i++) pd = std::max(pd, fabsf(o[i]));
    if (so) for (int i = 0; i < n; i++) tap[(w + i) % TAP] = .5f * (o[2 * i] + o[2 * i + 1]);   // show the music, not just the sub
    if (on.load(std::memory_order_relaxed)) {
      if (so) {
        // Capture mode: the original keeps playing by itself, so only the synthesized sub is output (no echo).
        sub.processOnly(o, n);
      } else {
        sub.process(o, n);
        for (int i = 0; i < n * 2; i++) o[i] *= gi;      // preamp: after the sub, before the EQ
        peq.process(o, n);
      }
      bool lo = limOn.load(std::memory_order_relaxed);
      for (int i = 0; i < n; i++) {
        if (lo) lim.run(o[2 * i], o[2 * i + 1]);
        else { o[2 * i] = std::clamp(o[2 * i], -1.f, 1.f); o[2 * i + 1] = std::clamp(o[2 * i + 1], -1.f, 1.f); }
        o[2 * i] *= go; o[2 * i + 1] *= go;
        po = std::max(po, std::max(fabsf(o[2 * i]), fabsf(o[2 * i + 1])));
      }
    } else {
      if (so) memset(o, 0, (size_t)n * 2 * sizeof(float));   // original already plays by itself
      po = so ? 0.f : pd;
    }
    meter(mDry, pd, dec); meter(mOut, po, dec);
    if (!so) for (int i = 0; i < n; i++) tap[(w + i) % TAP] = .5f * (o[2 * i] + o[2 * i + 1]);
    tapW.store((w + n) % TAP, std::memory_order_release);
    return oboe::DataCallbackResult::Continue;
  }

  void status(float* o) {
    if (stream && (statCnt++ % 30) == 0) {
      auto s = stream;
      auto r = s->calculateLatencyMillis();
      if (r.error() == oboe::Result::OK) lat = (float)r.value();
      auto x = s->getXRunCount();
      if (x.error() == oboe::Result::OK) xr = (float)x.value();
    }
    o[0] = peq.fs; o[1] = lat; o[2] = xr; o[3] = sub.lockedF.load(); o[4] = sub.pitchIn.load();
    o[5] = sub.pitchSub.load(); o[6] = mDry.load(); o[7] = sub.peakSub.load(); o[8] = mOut.load();
    o[9] = ring.fillMs.load(); o[10] = ring.ratioOut.load();
    o[11] = (float)(ring.underruns.load() + ring.drops.load());
  }
};
