#pragma once
#include <oboe/Oboe.h>
#include "dsp.h"

struct Spsc {
  std::vector<float> b; size_t cap = 0; std::atomic<size_t> h{0}, t{0};
  void init(size_t n) { cap = n; b.assign(n, 0); h = 0; t = 0; }
  size_t push(const float* s, size_t n) {
    if (!cap) return 0;
    size_t hh = h.load(std::memory_order_relaxed), tt = t.load(std::memory_order_acquire);
    n = std::min(n, cap - (hh - tt));
    for (size_t i = 0; i < n; i++) b[(hh + i) % cap] = s[i];
    h.store(hh + n, std::memory_order_release); return n;
  }
  size_t pop(float* d, size_t n) {
    if (!cap) return 0;
    size_t tt = t.load(std::memory_order_relaxed), hh = h.load(std::memory_order_acquire);
    n = std::min(n, hh - tt);
    for (size_t i = 0; i < n; i++) d[i] = b[(tt + i) % cap];
    t.store(tt + n, std::memory_order_release); return n;
  }
};

class Engine : public oboe::AudioStreamDataCallback {
 public:
  Peq peq; SubSynth sub; Limiter lim; Spsc ring;
  std::atomic<float> inG{1}, outG{1}, mDry{0}, mOut{0};
  std::atomic<bool> on{true}, limOn{true}, subOnly{false};
  float scratch[8192];
  static constexpr int TAP = 16384;
  float tap[TAP] = {}; std::atomic<int> tapW{0};
  std::shared_ptr<oboe::AudioStream> stream;
  int statCnt = 0; float lat = 0, xr = 0;

  bool start(int sr, int deviceId) {
    stop();
    oboe::AudioStreamBuilder b;
    b.setDirection(oboe::Direction::Output)->setPerformanceMode(oboe::PerformanceMode::LowLatency)
     ->setSharingMode(oboe::SharingMode::Exclusive)->setFormat(oboe::AudioFormat::Float)
     ->setChannelCount(2)->setSampleRate(sr)->setUsage(oboe::Usage::Media)
     ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
     ->setDataCallback(this);
    if (deviceId > 0) b.setDeviceId(deviceId);
    if (b.openStream(stream) != oboe::Result::OK) return false;
    float fs = (float)stream->getSampleRate();
    peq.fs = fs; sub.init(fs); lim.init(fs); ring.init((size_t)sr * 2);
    return stream->requestStart() == oboe::Result::OK;
  }
  void stop() { if (stream) { stream->stop(); stream->close(); stream.reset(); } }

  static void meter(std::atomic<float>& m, float v, float dec) {
    m.store(std::max(v, m.load(std::memory_order_relaxed) * dec), std::memory_order_relaxed);
  }

  oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* data, int32_t n) override {
    float* o = (float*)data;
    size_t got = ring.pop(o, (size_t)n * 2);
    if (got < (size_t)n * 2) memset(o + got, 0, ((size_t)n * 2 - got) * sizeof(float));
    float dec = expf(-(float)n / (0.3f * peq.fs));
    float gi = inG.load(), go = outG.load(), pd = 0, po = 0;
    bool so = subOnly.load(std::memory_order_relaxed);
    if (on.load(std::memory_order_relaxed)) {
      for (int i = 0; i < n * 2; i++) pd = std::max(pd, fabsf(o[i]));
      if (so) {
        // Capture mode: the original keeps playing, so only the synthesized sub is output (no echo).
        if (n * 2 <= 8192) {
          memcpy(scratch, o, (size_t)n * 2 * sizeof(float));
          sub.process(o, n);
          for (int i = 0; i < n * 2; i++) o[i] -= scratch[i];
        } else memset(o, 0, (size_t)n * 2 * sizeof(float));
      } else {
        sub.process(o, n);
        for (int i = 0; i < n * 2; i++) o[i] *= gi;      // preamp: after the sub, before the EQ
        peq.process(o, n);
      }
      bool lo = limOn.load(std::memory_order_relaxed);
      for (int i = 0; i < n; i++) {
        if (lo) lim.run(o[2 * i], o[2 * i + 1]);
        else { o[2 * i] = std::clamp(o[2 * i], -1.f, 1.f); o[2 * i + 1] = std::clamp(o[2 * i + 1], -1.f, 1.f); }
        o[2 * i] *= go; o[2 * i + 1] *= go;
        po = std::max(po, std::max(fabsf(o[2 * i]), fabsf(o[2 * i + 1])));
      }
    } else {
      for (int i = 0; i < n * 2; i++) pd = std::max(pd, fabsf(o[i]));
      if (so) memset(o, 0, (size_t)n * 2 * sizeof(float));   // original already plays by itself
      po = so ? 0.f : pd;
    }
    meter(mDry, pd, dec); meter(mOut, po, dec);
    int w = tapW.load(std::memory_order_relaxed);
    for (int i = 0; i < n; i++) tap[(w + i) % TAP] = .5f * (o[2 * i] + o[2 * i + 1]);
    tapW.store((w + n) % TAP, std::memory_order_release);
    return oboe::DataCallbackResult::Continue;
  }

  void status(float* o) {
    if (stream && (statCnt++ % 30) == 0) {
      auto s = stream;
      auto r = s->calculateLatencyMillis();
      if (r.error() == oboe::Result::OK) lat = (float)r.value();
      auto x = s->getXRunCount();
      if (x.error() == oboe::Result::OK) xr = (float)x.value();
    }
    o[0] = peq.fs; o[1] = lat; o[2] = xr; o[3] = sub.lockedF.load(); o[4] = sub.pitchIn.load();
    o[5] = sub.pitchSub.load(); o[6] = mDry.load(); o[7] = sub.peakSub.load(); o[8] = mOut.load();
  }
};
