#pragma once
#include <oboe/Oboe.h>
#include "dsp.h"

struct Spsc {
  std::vector<float> b; size_t cap = 0; std::atomic<size_t> h{0}, t{0};
  void init(size_t n) { cap = n; b.assign(n, 0); h = 0; t = 0; }
  size_t push(const float* s, size_t n) {
    if (!cap) return 0;
    size_t hh = h.load(std::memory_order_relaxed), tt = t.load(std::memory_order_acquire);
    n = std::min(n, cap - (hh - tt));
    for (size_t i = 0; i < n; i++) b[(hh + i) % cap] = s[i];
    h.store(hh + n, std::memory_order_release); return n;
  }
  size_t pop(float* d, size_t n) {
    if (!cap) return 0;
    size_t tt = t.load(std::memory_order_relaxed), hh = h.load(std::memory_order_acquire);
    n = std::min(n, hh - tt);
    for (size_t i = 0; i < n; i++) d[i] = b[(tt + i) % cap];
    t.store(tt + n, std::memory_order_release); return n;
  }
};

class Engine : public oboe::AudioStreamDataCallback {
 public:
  Peq peq; Epicenter epi; Limiter lim; Spsc ring;
  std::atomic<float> inG{1}, outG{1}; std::atomic<bool> on{true};
  static constexpr int TAP = 4096;
  float tap[TAP] = {}; std::atomic<int> tapW{0};
  std::shared_ptr<oboe::AudioStream> stream;

  bool start(int sr) {
    oboe::AudioStreamBuilder b;
    b.setDirection(oboe::Direction::Output)->setPerformanceMode(oboe::PerformanceMode::LowLatency)
     ->setSharingMode(oboe::SharingMode::Exclusive)->setFormat(oboe::AudioFormat::Float)
     ->setChannelCount(2)->setSampleRate(sr)->setUsage(oboe::Usage::Media)
     ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
     ->setDataCallback(this);
    if (b.openStream(stream) != oboe::Result::OK) return false;
    float fs = (float)stream->getSampleRate();
    peq.fs = fs; epi.init(fs); lim.init(fs); ring.init((size_t)sr * 2);
    return stream->requestStart() == oboe::Result::OK;
  }
  void stop() { if (stream) { stream->stop(); stream->close(); stream.reset(); } }

  oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* data, int32_t n) override {
    float* o = (float*)data;
    size_t got = ring.pop(o, (size_t)n * 2);
    if (got < (size_t)n * 2) memset(o + got, 0, ((size_t)n * 2 - got) * sizeof(float));
    if (on.load(std::memory_order_relaxed)) {
      float gi = inG.load(), go = outG.load();
      for (int i = 0; i < n * 2; i++) o[i] *= gi;
      epi.process(o, n);
      peq.process(o, n);
      for (int i = 0; i < n; i++) { lim.run(o[2 * i], o[2 * i + 1]); o[2 * i] *= go; o[2 * i + 1] *= go; }
    }
    int w = tapW.load(std::memory_order_relaxed);
    for (int i = 0; i < n; i++) tap[(w + i) % TAP] = .5f * (o[2 * i] + o[2 * i + 1]);
    tapW.store((w + n) % TAP, std::memory_order_release);
    return oboe::DataCallbackResult::Continue;
  }
};
