package com.example.dsp;

import android.os.ParcelFileDescriptor;

interface ICaptureService {
    void destroy() = 16777114;
    ParcelFileDescriptor start(int sampleRate) = 1;
    void stop() = 2;
    String lastError() = 3;
}
