package com.example.dsp;

import android.content.AttributionSource;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Process;

/** Makes the shell process look like the "com.android.shell" app so AudioRecord's permission checks pass. */
final class FakeContext extends ContextWrapper {
    static final String PKG = "com.android.shell";

    FakeContext(Context base) { super(base); }

    public String getPackageName() { return PKG; }
    public String getOpPackageName() { return PKG; }
    public Context getApplicationContext() { return this; }
    public int getDeviceId() { return 0; }

    public AttributionSource getAttributionSource() {
        AttributionSource.Builder b = new AttributionSource.Builder(Process.myUid());
        b.setPackageName(PKG);
        return b.build();
    }
}
