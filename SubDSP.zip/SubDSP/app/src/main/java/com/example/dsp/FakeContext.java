package com.example.dsp;

import android.content.AttributionSource;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Process;

/** Makes the privileged helper process look like the "com.android.shell" app so AudioRecord's permission checks pass. */
final class FakeContext extends ContextWrapper {
    private final String pkg;

    FakeContext(Context base) {
        super(base);
        pkg = Process.myUid() == 0 ? "root" : "com.android.shell";
    }

    @Override public String getPackageName() { return pkg; }
    @Override public String getOpPackageName() { return pkg; }
    @Override public Context getApplicationContext() { return this; }
    public int getDeviceId() { return 0; }

    @Override public AttributionSource getAttributionSource() {
        AttributionSource.Builder b = new AttributionSource.Builder(Process.myUid());
        b.setPackageName(pkg);
        return b.build();
    }
}
