package com.example.dsp

import android.os.SystemClock
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

@Composable
fun CheckDot(ok: Boolean) {
    Canvas(Modifier.size(22.dp)) {
        if (ok) {
            drawCircle(C.green, size.minDimension / 2)
            val p = Path()
            p.moveTo(size.width * 0.28f, size.height * 0.52f)
            p.lineTo(size.width * 0.45f, size.height * 0.68f)
            p.lineTo(size.width * 0.74f, size.height * 0.34f)
            drawPath(p, Color.Black, style = Stroke(2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        } else {
            drawCircle(C.card3, size.minDimension / 2 - 1.dp.toPx(), style = Stroke(1.5.dp.toPx()))
        }
    }
}

@Composable
fun ModeRow(title: String, sub: String, on: Boolean, last: Boolean, onClick: () -> Unit) {
    Column(Modifier.tap(onClick)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T(title, 16, C.label, FontWeight.SemiBold)
                Gap(2)
                T(sub, 12, C.label2, maxLines = 5)
            }
            Spacer(Modifier.width(12.dp))
            Canvas(Modifier.size(22.dp)) {
                if (on) {
                    val p = Path()
                    p.moveTo(size.width * 0.12f, size.height * 0.55f)
                    p.lineTo(size.width * 0.4f, size.height * 0.82f)
                    p.lineTo(size.width * 0.9f, size.height * 0.2f)
                    drawPath(p, C.blue, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
        }
        if (!last) Box(Modifier.padding(start = 16.dp).fillMaxWidth().height(0.5.dp).background(C.sep))
    }
}

@Composable
fun FlowingRow() {
    val tk = Live.tick
    val ok = Live.st[6] > 0.0006f
    ListRow("Audio flowing", "The DRY meter on the Sub tab moves when capture works", last = true) { CheckDot(ok) }
}

@Composable
fun BigButton(text: String, color: Color, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(color).press(onClick).padding(vertical = 15.dp),
        contentAlignment = Alignment.Center
    ) { T(text, 16, Color.White, FontWeight.SemiBold) }
}

@Composable
fun SourceScreen(p: Params, a: Actions) {
    val mode by DspState.mode.collectAsState()
    val capturing by DspState.capturing.collectAsState()
    val note by DspState.note.collectAsState()
    val sRun by DspState.sRunning.collectAsState()
    val sPerm by DspState.sPerm.collectAsState()
    val fx by DspState.fxInfo.collectAsState()
    val ctx = LocalContext.current

    LaunchedEffect(Unit) {
        while (true) {
            DspState.sRunning.value = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
            DspState.sPerm.value = try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }
            delay(1000)
        }
    }

    fun pick(m: Int) {
        if (capturing) { a.stopCapture(); a.stopShizuku() }
        DspState.mode.value = m
        p.saveMode(m)
        DspState.note.value = ""
        p.pushMaster()
        p.pushSession()
    }

    Screen("Source", trailing = {}, sub = { T("How audio reaches the engine", 13, C.label2) }) {
        Label("PROCESSING MODE")
        Group {
            ModeRow(
                "Effects",
                "System effects on the player's own audio: 32-band EQ and limiter, SUB GAIN becomes a gentle bass shelf. Only works with players that announce their audio session (Spotify does). The synthesized sub is not available.",
                mode == 0, false
            ) { pick(0) }
            ModeRow(
                "Capture",
                "Adds the synthesized sub on top of the original, so there is no echo. The EQ is applied to the original through system effects. Apps that block capture, such as Spotify, stay silent here.",
                mode == 1, false
            ) { pick(1) }
            ModeRow(
                "Shizuku",
                "Full processing for any app, Spotify included. The original is muted and replaced by the processed signal, so the EQ and the sub both come from this app. Needs Shizuku.",
                mode == 2, true
            ) { pick(2) }
        }

        Label("SETUP")
        if (mode != 2) {
            GlassCard {
                Label("SYSTEM EFFECT SESSIONS")
                Gap(6)
                T(fx, 12, C.label2, maxLines = 6)
                Gap(6)
                T("If nothing shows up here while your player is playing, that player does not support system effects. Use Shizuku mode: its EQ and sub work with every app.", 11, C.label3, maxLines = 4)
            }
        }
        Group {
            ListRow("Notification access", "Lets the app see which player is active", last = mode == 0) { Pill("Open") { a.listener() } }
            if (mode == 1) {
                ListRow("Screen capture", "Allow it when asked. Only audio is used.", last = true) {
                    Pill(if (capturing) "Stop" else "Start") { if (capturing) a.stopCapture() else a.startCapture() }
                }
            }
            if (mode == 2) {
                ListRow("Shizuku is running", "Start it in the Shizuku app with Wireless debugging") {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Pill("Open app") {
                            val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                            if (i != null) ctx.startActivity(i) else DspState.note.value = "Shizuku isn't installed. Get it from the Play Store."
                        }
                        CheckDot(sRun)
                    }
                }
                ListRow("Permission granted") {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (!sPerm) Pill("Allow") { a.startShizuku() }
                        CheckDot(sPerm)
                    }
                }
                ListRow("Output", "Auto follows where music plays. Pick Speaker if you hear nothing.") {
                    Segmented(listOf("Auto", "Speaker"), p.outPref, { p.outPref = it; p.save() }, Modifier.width(150.dp))
                }
                ListRow("Device volume", "Max: sets the real speaker to full on Connect (restored on Disconnect). Use MASTER to adjust.") {
                    Segmented(listOf("Max", "Keep"), p.volPref, { p.volPref = it; p.save() }, Modifier.width(150.dp))
                }
                ListRow("Test beep", "Plays a tone straight out of this app. Hear it = output works.") {
                    Pill("Beep") { NativeDsp.beep() }
                }
                ListRow("Capture connected") { CheckDot(capturing) }
                FlowingRow()
            }
        }
        if (mode == 2) {
            BigButton(if (capturing) "Disconnect" else "Connect", if (capturing) C.card3 else C.blue) {
                if (capturing) a.stopShizuku() else a.startShizuku()
            }
        }
        if (note.isNotEmpty()) {
            GlassCard {
                Label("STATUS")
                Gap(6)
                T(note, 12, C.orange, maxLines = 10)
            }
        }
    }
}
