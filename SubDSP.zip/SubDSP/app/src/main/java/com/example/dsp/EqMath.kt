package com.example.dsp

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

const val FS = 48000.0

/** Centre frequency of band i when the EQ has n bands. 10 bands = classic octave set (31 Hz … 16 kHz). */
fun bandFreq(n: Int, i: Int): Float {
    val k = i.coerceIn(0, n - 1)
    return if (n == 10) (31.25 * Math.pow(2.0, k.toDouble())).toFloat()
    else (20.0 * Math.pow(1000.0, k / (n - 1).toDouble())).toFloat()
}

/** Q that makes neighbouring bells just touch, for n bands. */
fun autoQ(n: Int): Float {
    val lo = bandFreq(n, 0).toDouble()
    val hi = bandFreq(n, n - 1).toDouble()
    val bw = ln(hi / lo) / ln(2.0) / (n - 1)
    val q = Math.pow(2.0, bw / 2) / (Math.pow(2.0, bw) - 1)
    return q.toFloat().coerceIn(0.3f, 24f)
}

// RBJ cookbook biquad, same maths as the native engine (used to draw the true response)
fun rbjK(t: Int, f0: Double, gdb: Double, q: Double): DoubleArray {
    val f = f0.coerceIn(10.0, FS * 0.49)
    val a = Math.pow(10.0, gdb / 40.0)
    val w = 2 * Math.PI * f / FS
    val c = cos(w)
    val s = sin(w)
    val al = s / (2 * q)
    val k = 2 * sqrt(a) * al
    val b0: Double; val b1: Double; val b2: Double; val a0: Double; val a1: Double; val a2: Double
    when (t) {
        0 -> { b0 = 1 + al * a; b1 = -2 * c; b2 = 1 - al * a; a0 = 1 + al / a; a1 = -2 * c; a2 = 1 - al / a }
        1 -> {
            b0 = a * ((a + 1) - (a - 1) * c + k); b1 = 2 * a * ((a - 1) - (a + 1) * c); b2 = a * ((a + 1) - (a - 1) * c - k)
            a0 = (a + 1) + (a - 1) * c + k; a1 = -2 * ((a - 1) + (a + 1) * c); a2 = (a + 1) + (a - 1) * c - k
        }
        2 -> {
            b0 = a * ((a + 1) + (a - 1) * c + k); b1 = -2 * a * ((a - 1) + (a + 1) * c); b2 = a * ((a + 1) + (a - 1) * c - k)
            a0 = (a + 1) - (a - 1) * c + k; a1 = 2 * ((a - 1) - (a + 1) * c); a2 = (a + 1) - (a - 1) * c - k
        }
        3 -> { b0 = (1 - c) / 2; b1 = 1 - c; b2 = b0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al }
        4 -> { b0 = (1 + c) / 2; b1 = -(1 + c); b2 = b0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al }
        else -> { b0 = 1.0; b1 = -2 * c; b2 = 1.0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al }
    }
    return doubleArrayOf(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
}

fun stagesOf(b: BandState): List<DoubleArray> = when {
    b.byp -> emptyList()
    b.type == 6 -> listOf(rbjK(3, b.freq.toDouble(), 0.0, 0.5412), rbjK(3, b.freq.toDouble(), 0.0, 1.3066))
    b.type == 7 -> listOf(rbjK(4, b.freq.toDouble(), 0.0, 0.5412), rbjK(4, b.freq.toDouble(), 0.0, 1.3066))
    b.type <= 2 && Math.abs(b.gain) < 0.01f -> emptyList()
    else -> listOf(rbjK(b.type, b.freq.toDouble(), b.gain.toDouble(), b.q.toDouble()))
}

/** Bass and treble tone shelves (BASS 0..1 → 0..+12 dB at 90 Hz, TREBLE at 8 kHz). */
fun toneStages(p: Params): List<DoubleArray> {
    val l = ArrayList<DoubleArray>()
    if (p.bass > 0.001f) l.add(rbjK(1, 90.0, p.bass * 12.0, 0.7))
    if (p.treble > 0.001f) l.add(rbjK(2, 8000.0, p.treble * 12.0, 0.7))
    return l
}

fun magDb(c: DoubleArray, w: Double): Double {
    val cw = cos(w); val sw = sin(w); val c2 = cos(2 * w); val s2 = sin(2 * w)
    val nr = c[0] + c[1] * cw + c[2] * c2
    val ni = -(c[1] * sw + c[2] * s2)
    val dr = 1 + c[3] * cw + c[4] * c2
    val di = -(c[3] * sw + c[4] * s2)
    return 10 * log10((nr * nr + ni * ni) / (dr * dr + di * di) + 1e-30)
}

fun respDb(stages: List<DoubleArray>, f: Double): Double {
    val w = 2 * Math.PI * f / FS
    var db = 0.0
    for (c in stages) db += magDb(c, w)
    return db
}

/** 10-point preset curves (dB at 31 62 125 250 500 1k 2k 4k 8k 16k); applied to any band count by interpolation. */
val PRESETS: List<Pair<String, FloatArray>> = listOf(
    "Flat" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Bass Boost" to floatArrayOf(6f, 5f, 4f, 2f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Bass Reducer" to floatArrayOf(-6f, -5f, -4f, -2f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Treble Boost" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 1f, 3f, 5f, 6f, 6f),
    "Treble Reducer" to floatArrayOf(0f, 0f, 0f, 0f, 0f, -1f, -3f, -5f, -6f, -6f),
    "Vocal" to floatArrayOf(-2f, -3f, -3f, 1f, 3f, 3f, 3f, 2f, 0f, -1f),
    "Rock" to floatArrayOf(5f, 4f, 3f, 1f, -1f, -1f, 1f, 3f, 4f, 5f),
    "Pop" to floatArrayOf(-1f, 2f, 4f, 4f, 2f, 0f, -1f, -1f, -1f, -1f),
    "Jazz" to floatArrayOf(4f, 3f, 1f, 2f, -2f, -2f, 0f, 1f, 3f, 4f),
    "Classical" to floatArrayOf(4f, 3f, 3f, 2f, -1f, -1f, 0f, 2f, 3f, 4f),
    "Electronic" to floatArrayOf(5f, 4f, 1f, 0f, -2f, 2f, 1f, 1f, 4f, 5f),
    "Hip-Hop" to floatArrayOf(5f, 4f, 1f, 3f, -1f, -1f, 1f, -1f, 2f, 3f),
    "Loudness" to floatArrayOf(6f, 4f, 1f, 0f, -1f, 0f, 0f, 2f, 5f, 6f),
    "Acoustic" to floatArrayOf(4f, 4f, 3f, 1f, 1f, 1f, 3f, 3f, 3f, 2f)
)

fun interpPreset(g: FloatArray, f: Float): Float {
    val pos = (ln(f / 31.25f) / ln(2f)).coerceIn(0f, 9f)
    val i0 = pos.toInt().coerceIn(0, 8)
    val fr = pos - i0
    return g[i0] * (1 - fr) + g[i0 + 1] * fr
}

/** Solves A x = b (A is n x n) with partial pivoting. Returns zeros if the system is singular. */
private fun solveLinear(a: Array<DoubleArray>, b: DoubleArray): DoubleArray {
    val n = b.size
    for (c in 0 until n) {
        var p = c
        for (r in c + 1 until n) if (abs(a[r][c]) > abs(a[p][c])) p = r
        if (abs(a[p][c]) < 1e-12) return DoubleArray(n)
        if (p != c) { val t = a[p]; a[p] = a[c]; a[c] = t; val tb = b[p]; b[p] = b[c]; b[c] = tb }
        for (r in c + 1 until n) {
            val f = a[r][c] / a[c][c]
            if (f == 0.0) continue
            for (k in c until n) a[r][k] -= f * a[c][k]
            b[r] -= f * b[c]
        }
    }
    val x = DoubleArray(n)
    for (r in n - 1 downTo 0) {
        var s = b[r]
        for (k in r + 1 until n) s -= a[r][k] * x[k]
        x[r] = s / a[r][r]
    }
    return x
}

/**
 * Finds the n band gains whose COMBINED response best matches `target(freq) -> dB`.
 *
 * Neighbouring bells overlap, so simply reading the target at each band centre (what the old code did) makes the
 * result louder than intended, and doing it repeatedly (changing the band count) compounds until every band sits
 * at +24 dB. This does a least-squares fit, then refines it against the real (non-linear) filter response.
 */
fun fitGains(n: Int, target: (Double) -> Double): FloatArray {
    val q = autoQ(n).toDouble()
    val centres = DoubleArray(n) { bandFreq(n, it).toDouble() }
    val lo = max(20.0, centres[0] / 1.3)
    val hi = min(20000.0, centres[n - 1] * 1.3)
    val m = 160
    val ws = DoubleArray(m) { 2 * Math.PI * (lo * (hi / lo).pow(it / (m - 1.0))) / FS }
    val tgt = DoubleArray(m) { target(lo * (hi / lo).pow(it / (m - 1.0))) }
    // response of each band at +1 dB (nearly linear in the gain)
    val basis = Array(n) { i -> val c = rbjK(0, centres[i], 1.0, q); DoubleArray(m) { k -> magDb(c, ws[k]) } }
    val ata = Array(n) { i -> DoubleArray(n) { j -> var s = 0.0; for (k in 0 until m) s += basis[i][k] * basis[j][k]; s } }
    val g = DoubleArray(n)
    repeat(5) {
        val cur = DoubleArray(m)
        for (i in 0 until n) if (abs(g[i]) > 1e-6) {
            val c = rbjK(0, centres[i], g[i], q)
            for (k in 0 until m) cur[k] += magDb(c, ws[k])
        }
        val rhs = DoubleArray(n) { i -> var s = 0.0; for (k in 0 until m) s += basis[i][k] * (tgt[k] - cur[k]); s }
        val a = Array(n) { i -> DoubleArray(n) { j -> ata[i][j] + if (i == j) 1e-3 else 0.0 } }
        val d = solveLinear(a, rhs)
        for (i in 0 until n) g[i] = (g[i] + d[i]).coerceIn(-24.0, 24.0)
    }
    return FloatArray(n) { (Math.round(g[it] * 10.0) / 10.0).toFloat() }
}
