package com.example.dsp

import android.os.SystemClock
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt


// ───────────────────────── SUB screen ─────────────────────────
@Composable
fun SubScreen(p: Params) {
    val hooked by DspState.hooked.collectAsState()
    Screen("Subharmonic", trailing = { Pill("Reset") { p.resetSub() } }, sub = { StatusLine(hooked) }) {
        HeroCard(p)
        NowPlayingCard()
        Segmented(
            listOf("Original", "Subharmonic"), if (p.original) 0 else 1,
            { p.original = it == 0; p.pushMaster() }, Modifier.fillMaxWidth()
        )

        Group {
            ListRow("Voice") { Segmented(listOf("Sine", "Saw", "Square"), p.voice, { p.voice = it; p.pushSub() }, Modifier.width(200.dp)) }
            ListRow("Generator") { Segmented(listOf("Osc", "Flip"), p.gen, { p.gen = it; p.pushSub() }, Modifier.width(130.dp)) }
            ListRow("Auto sweep", "Follows the pitch it hears", last = true) { IOSSwitch(p.auto) { p.auto = it; p.pushSub() } }
        }

        GlassCard {
            Label("TRACKING")
            Gap(14)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Knob("SWEEP", p.sweep, 27f, 63f, 45f, C.orange, { "%.1f".format(it) }, "Hz") { p.sweep = it; p.pushSub() }
                Knob("WIDE", p.wide, 0.3f, 3f, 0.7f, C.teal, { "%.2f".format(it) }, "Q") { p.wide = it; p.pushSub() }
                Knob("SMOOTH", p.smooth, 0.5f, 3f, 1.2f, C.teal, { "%.1f".format(it) }, "×f") { p.smooth = it; p.pushSub() }
                Knob("SENS", p.sens, 0f, 1f, 0.73f, C.teal, { "${(it * 100).roundToInt()}" }, "%") { p.sens = it; p.pushSub() }
            }
        }

        GlassCard {
            Label("SUB OUTPUT")
            Gap(14)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Knob("SUB GAIN", p.gainDb, -60f, 12f, 6f, C.pink, { "%+.1f".format(it) }, "dB") { p.gainDb = it; p.pushSub() }
                Knob("DRIVE", p.drive, 0f, 1f, 0.3f, C.pink, { "${(it * 100).roundToInt()}" }, "%") { p.drive = it; p.pushSub() }
                Knob("PFM", p.pfm, 10f, 40f, 21f, C.pink, { "%.0f".format(it) }, "Hz") { p.pfm = it; p.pushSub() }
                Knob("MASTER", p.master, -24f, 12f, 0f, C.green, { "%+.1f".format(it) }, "dB") { p.master = it; p.pushMaster() }
            }
        }

        GlassCard {
            Label("ENHANCE  ·  SHIZUKU MODE")
            Gap(14)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Knob("PUNCH", p.punch, 0f, 1f, 0.4f, C.orange, { "${(it * 100).roundToInt()}" }, "%") { p.punch = it; p.pushEnh() }
                Knob("VOCAL", p.vocal, 0f, 1f, 0.3f, C.teal, { "${(it * 100).roundToInt()}" }, "%") { p.vocal = it; p.pushEnh() }
                Knob("LOUD", p.loud, 0f, 18f, 9f, C.green, { "%+.1f".format(it) }, "dB") { p.loud = it; p.pushEnh() }
            }
            Gap(8)
            T("PUNCH rebuilds the kick from bass harmonics your speaker can play. VOCAL lifts the centred voice. LOUD automatically raises quiet music, by up to this many dB, to a normal listening level.", 11, C.label3, maxLines = 3)
        }

        LevelsCard()
        PitchCard()
        Footer()
    }
}

@Composable
fun Footer() {
    val tk = Live.tick
    val mode by DspState.mode.collectAsState()
    val fs = Live.st[0]
    val txt = "${if (fs > 0f) "%.1f kHz".format(fs / 1000f) else "—"} · ${"%.1f".format(Live.st[1])} ms · buf ${"%.0f".format(Live.st[9])} ms · glitches ${Live.st[11].toInt()} · " +
        when (mode) { 0 -> "Effects"; 1 -> "Capture"; else -> "Shizuku" }
    Box(Modifier.fillMaxWidth().padding(top = 4.dp), contentAlignment = Alignment.Center) { T(txt, 10, C.label3, mono = true) }
}

@Composable
fun HeroCard(p: Params) {
    GlassCard {
        Readouts(p)
        Gap(12)
        SpectrumView(p, Modifier.fillMaxWidth().height(150.dp))
        Gap(6)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            T("20 Hz", 10, C.label3); T("sub 27–63", 10, C.label3); T("200 Hz", 10, C.label3)
        }
    }
}

@Composable
fun Readouts(p: Params) {
    val tk = Live.tick
    val inHz = Live.st[4]
    val subHz = Live.st[5]
    val locked = Live.st[3] > 0.5f
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            T("INPUT ÷2", 10, C.label2, FontWeight.SemiBold, spacing = 0.8f)
            T(if (inHz > 0f) "%.1f".format(inHz) else "—", 28, C.teal, FontWeight.Light, true)
        }
        Column(Modifier.weight(1f)) {
            T("SUB", 10, C.label2, FontWeight.SemiBold, spacing = 0.8f)
            T(if (subHz > 0f) "%.1f".format(subHz) else "—", 28, C.pink, FontWeight.Light, true)
        }
        Column(Modifier.weight(1f)) {
            T("SWEEP", 10, C.label2, FontWeight.SemiBold, spacing = 0.8f)
            T("%.1f".format(p.sweep), 28, C.orange, FontWeight.Light, true)
        }
        Row(
            Modifier.clip(RoundedCornerShape(50)).background(C.well).padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(6.dp).clip(CircleShape).background(if (locked) C.green else C.label3))
            Spacer(Modifier.width(6.dp))
            T(if (locked) "LOCKED" else "SEARCH", 9, if (locked) C.green else C.label2, FontWeight.Bold, spacing = 0.8f)
        }
    }
}

fun curve(bins: FloatArray, w: Float, h: Float, close: Boolean): Path {
    val p = Path()
    val n = bins.size
    if (close) { p.moveTo(0f, h); p.lineTo(0f, h * (1f - bins[0])) } else p.moveTo(0f, h * (1f - bins[0]))
    for (i in 1 until n) {
        val x = w * i / (n - 1)
        val y = h * (1f - bins[i])
        val px = w * (i - 1) / (n - 1)
        val py = h * (1f - bins[i - 1])
        p.cubicTo((px + x) / 2, py, (px + x) / 2, y, x, y)
    }
    if (close) { p.lineTo(w, h); p.close() }
    return p
}

@Composable
fun SpectrumView(p: Params, modifier: Modifier) {
    Canvas(modifier) {
        val tk = Live.tick
        val w = size.width
        val h = size.height
        for (g in 1..3) drawLine(C.grid, Offset(0f, h * g / 4), Offset(w, h * g / 4), 1f)
        drawPath(curve(Live.bins, w, h, true), Brush.verticalGradient(listOf(C.teal.copy(alpha = 0.35f), Color.Transparent)))
        drawPath(curve(Live.bins, w, h, false), C.teal, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
        fun xz(f: Float) = (ln(f / 20f) / ln(10f) * w).coerceIn(0f, w)
        val inHz = Live.st[4]
        val subHz = Live.st[5]
        if (inHz > 0f) drawLine(C.teal, Offset(xz(inHz), 0f), Offset(xz(inHz), h), 1.5f, pathEffect = dash)
        if (subHz > 0f) drawLine(C.pink, Offset(xz(subHz), 0f), Offset(xz(subHz), h), 1.5f, pathEffect = dash)
        drawCircle(C.orange, 4.dp.toPx(), Offset(xz(p.sweep), h - 4.dp.toPx()))
    }
}

@Composable
fun NowPlayingCard() {
    val np by DspState.now.collectAsState()
    var nowMs by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(Unit) { while (true) { nowMs = SystemClock.elapsedRealtime(); delay(500) } }
    GlassCard {
        val n = np
        if (n == null) {
            T("Nothing playing", 15, C.label, FontWeight.SemiBold)
            Gap(2)
            T("Turn on notification access, then start any music app.", 12, C.label2, maxLines = 2)
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val art = n.art
                if (art != null) {
                    Image(art.asImageBitmap(), null, Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)))
                } else {
                    Box(
                        Modifier.size(56.dp).clip(RoundedCornerShape(12.dp))
                            .background(Brush.linearGradient(listOf(C.pink, C.blue)))
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    T(if (n.title.isEmpty()) n.app else n.title, 15, C.label, FontWeight.SemiBold)
                    T(if (n.artist.isEmpty()) n.app else n.artist, 12, C.label2)
                }
                Spacer(Modifier.width(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.press { DspState.controller?.transportControls?.skipToPrevious() }) { Glyph(3, C.label, 22.dp) }
                    Box(Modifier.press {
                        val tc = DspState.controller?.transportControls
                        if (n.playing) tc?.pause() else tc?.play()
                    }) { Glyph(if (n.playing) 1 else 0, C.label, 28.dp) }
                    Box(Modifier.press { DspState.controller?.transportControls?.skipToNext() }) { Glyph(2, C.label, 22.dp) }
                }
            }
            Gap(12)
            val frac = if (n.dur > 0) n.positionAt(nowMs).toFloat() / n.dur else 0f
            Canvas(Modifier.fillMaxWidth().height(4.dp)) {
                drawRoundRect(C.card2, size = size, cornerRadius = CornerRadius(2.dp.toPx()))
                drawRoundRect(C.label, size = Size(size.width * frac.coerceIn(0f, 1f), size.height), cornerRadius = CornerRadius(2.dp.toPx()))
            }
        }
    }
}

@Composable
fun LevelsCard() {
    GlassCard {
        Label("LEVELS · PEAK dBFS")
        Gap(10)
        Level("DRY", 6, C.blue)
        Level("SUB", 7, C.pink)
        Level("OUT", 8, C.green)
    }
}

@Composable
fun Level(name: String, idx: Int, color: Color) {
    val tk = Live.tick
    val v = Live.st[idx]
    val db = if (v < 1e-5f) -100f else 20f * log10(v)
    Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        T(name, 10, C.label2, FontWeight.SemiBold, modifier = Modifier.width(34.dp), spacing = 0.8f)
        Canvas(Modifier.weight(1f).height(6.dp)) {
            drawRoundRect(C.card2, size = size, cornerRadius = CornerRadius(3.dp.toPx()))
            val f = ((db + 60f) / 60f).coerceIn(0f, 1f)
            val col = if (db > -1f) C.pink else if (db > -6f) C.orange else color
            drawRoundRect(col, size = Size(size.width * f, size.height), cornerRadius = CornerRadius(3.dp.toPx()))
        }
        Spacer(Modifier.width(10.dp))
        T(if (db <= -99f) "-inf" else "%.1f".format(db), 11, C.label2, FontWeight.Medium, true, Modifier.width(44.dp))
    }
}

@Composable
fun PitchCard() {
    GlassCard {
        Label("PITCH · LAST 10 S")
        Gap(10)
        Canvas(Modifier.fillMaxWidth().height(90.dp)) {
            val tk = Live.tick
            val w = size.width
            val h = size.height
            for (g in 1..2) drawLine(C.grid, Offset(0f, h * g / 3), Offset(w, h * g / 3), 1f)
            fun line(a: FloatArray, col: Color) {
                val path = Path()
                var started = false
                for (i in a.indices) {
                    val v = a[i]
                    if (v > 0f) {
                        val x = w * i / (a.size - 1)
                        val y = h * (1f - (ln(v / 20f) / ln(7f)).coerceIn(0f, 1f))
                        if (!started) { path.moveTo(x, y); started = true } else path.lineTo(x, y)
                    } else started = false
                }
                drawPath(path, col, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            line(Live.inHist, C.teal)
            line(Live.subHist, C.pink)
        }
        Gap(6)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            T("● input", 10, C.teal); T("● sub", 10, C.pink); T("20–140 Hz", 10, C.label3)
        }
    }
}

