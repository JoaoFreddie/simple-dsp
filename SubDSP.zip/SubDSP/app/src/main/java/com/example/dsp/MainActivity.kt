package com.example.dsp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {
    private lateinit var params: Params

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK && r.data != null) {
            startForegroundService(Intent(this, DspService::class.java)
                .putExtra("code", r.resultCode).putExtra("data", r.data))
        }
    }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        projLauncher.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }
    private val shizukuListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) ShizukuBridge.bind(applicationContext)
        else DspState.note.value = "Shizuku permission was denied"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startForegroundService(Intent(this, FxService::class.java))
        Shizuku.addRequestPermissionResultListener(shizukuListener)
        val app = application as SubApp
        app.ensure()
        params = app.params
        val actions = Actions(
            listener = { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            startCapture = {
                permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS))
            },
            stopCapture = { stopService(Intent(this, DspService::class.java)) },
            startShizuku = { startShizuku() },
            stopShizuku = { ShizukuBridge.stop() }
        )
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { AppRoot(params, actions) } }
    }

    private fun startShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                DspState.note.value = "Shizuku isn't running. Open the Shizuku app and start it first."
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) ShizukuBridge.bind(applicationContext)
            else Shizuku.requestPermission(100)
        } catch (e: Throwable) {
            DspState.note.value = "Shizuku error: ${e.message}"
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(shizukuListener)
        super.onDestroy()
    }
}
