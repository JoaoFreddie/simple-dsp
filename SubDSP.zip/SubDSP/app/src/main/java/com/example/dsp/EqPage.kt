package com.example.dsp

import android.os.SystemClock
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

private val COL_W = 40.dp
private val typeNames = listOf("Bell", "Low shelf", "High shelf", "LP 12", "HP 12", "Notch", "LP 24", "HP 24")

private fun num(v: Float, d: Int): String = String.format(java.util.Locale.US, "%." + d + "f", v)
private fun fLabel(f: Float): String =
    if (f >= 1000f) {
        val k = f / 1000f
        (if (k >= 10f) num(k, 0) else num(k, 1).removeSuffix(".0")) + "K"
    } else num(f, 0)
private fun fmtF(f: Float) = if (f >= 1000f) num(f / 1000f, 2) + " kHz" else num(f, 0) + " Hz"

private fun xOf(f: Float, w: Float) = ln(f / 20f) / ln(1000f) * w
private fun fOf(x: Float, w: Float) = (20.0 * Math.pow(1000.0, (x / w).toDouble().coerceIn(0.0, 1.0))).toFloat()
private fun yOf(g: Float, h: Float) = (24f - g) / 48f * h
private fun gOf(y: Float, h: Float) = (24f - y / h * 48f).coerceIn(-24f, 24f)
private fun qOf(n: Float) = (0.1 * Math.pow(240.0, n.toDouble())).toFloat()
private fun nOfQ(q: Float) = (ln(q / 0.1f) / ln(240f)).coerceIn(0f, 1f)

/** Poweramp-like colour ramp: green when cut, yellow → orange → red as boost grows. */
private fun gainColor(g: Float): Color {
    val stops = listOf(
        -24f to Color(0xFF00D26A), 0f to Color(0xFF14E84A), 4f to Color(0xFF9BEF00),
        8f to Color(0xFFFFE600), 12f to Color(0xFFFF9F0A), 24f to Color(0xFFFF3B30)
    )
    if (g <= stops.first().first) return stops.first().second
    for (i in 1 until stops.size) {
        val a = stops[i - 1]
        val b = stops[i]
        if (g <= b.first) return lerp(a.second, b.second, (g - a.first) / (b.first - a.first))
    }
    return stops.last().second
}

// ───────────────────────── Neon slider ─────────────────────────
@Composable
fun NeonSlider(
    value: Float, lo: Float, hi: Float, def: Float, colored: Boolean,
    onSelect: () -> Unit, modifier: Modifier, onChange: (Float) -> Unit
) {
    val cb by rememberUpdatedState(onChange)
    val sel by rememberUpdatedState(onSelect)
    val curV by rememberUpdatedState(value)
    val haptic = LocalHapticFeedback.current
    Canvas(
        modifier
            .pointerInput(Unit) { detectTapGestures(onTap = { sel() }, onDoubleTap = { sel(); cb(def) }) }
            .pointerInput(Unit) {
                val pad = 34.dp.toPx()
                detectVerticalDragGestures(onDragStart = { sel() }) { c, _ ->
                    val f = ((size.height - pad - c.position.y) / (size.height - 2 * pad)).coerceIn(0f, 1f)
                    val nv = lo + f * (hi - lo)
                    val old = curV
                    if ((old < def && nv >= def) || (old > def && nv <= def)) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    cb(nv)
                }
            }
    ) {
        val w = size.width
        val h = size.height
        val pad = 34.dp.toPx()
        val top = pad
        val bot = h - pad
        val cx = w / 2
        val frac = ((value - lo) / (hi - lo)).coerceIn(0f, 1f)
        val ty = bot - (bot - top) * frac
        val mid = (top + bot) / 2
        val dash = Color(0x59EBEBF5)
        for (yy in floatArrayOf(top, mid, bot)) {
            drawLine(dash, Offset(cx - 19.dp.toPx(), yy), Offset(cx - 12.dp.toPx(), yy), 1.5.dp.toPx(), cap = StrokeCap.Round)
            drawLine(dash, Offset(cx + 12.dp.toPx(), yy), Offset(cx + 19.dp.toPx(), yy), 1.5.dp.toPx(), cap = StrokeCap.Round)
        }
        drawLine(Color(0xFF3A3A3C), Offset(cx, top - 24.dp.toPx()), Offset(cx, ty), 2.dp.toPx(), cap = StrokeCap.Round)
        val end = Offset(cx, bot + 6.dp.toPx())
        if (colored) {
            val col = gainColor(value)
            drawLine(col.copy(alpha = 0.14f), Offset(cx, ty), end, 14.dp.toPx(), cap = StrokeCap.Round)
            drawLine(col.copy(alpha = 0.32f), Offset(cx, ty), end, 7.dp.toPx(), cap = StrokeCap.Round)
            drawLine(col, Offset(cx, ty), end, 2.5.dp.toPx(), cap = StrokeCap.Round)
        } else {
            drawLine(Color(0xFF3A3A3C), Offset(cx, ty), end, 2.dp.toPx(), cap = StrokeCap.Round)
        }
        val tw = 30.dp.toPx()
        val th = 58.dp.toPx()
        drawRoundRect(Color(0x66000000), Offset(cx - tw / 2, ty - th / 2 + 3.dp.toPx()), Size(tw, th), CornerRadius(tw / 2))
        drawRoundRect(Color(0xFF2A2A2D), Offset(cx - tw / 2, ty - th / 2), Size(tw, th), CornerRadius(tw / 2))
        drawRoundRect(Color(0x33FFFFFF), Offset(cx - tw / 2, ty - th / 2), Size(tw, th), CornerRadius(tw / 2), style = Stroke(1.dp.toPx()))
        drawRoundRect(Color(0xFFD1D1D6), Offset(cx - 7.dp.toPx(), ty - 1.5.dp.toPx()), Size(14.dp.toPx(), 3.dp.toPx()), CornerRadius(1.5.dp.toPx()))
    }
}

@Composable
fun PBand(p: Params, i: Int, selected: Boolean, onSel: () -> Unit) {
    val b = p.bands[i]
    Column(Modifier.width(COL_W), horizontalAlignment = Alignment.CenterHorizontally) {
        NeonSlider(b.gain, -24f, 24f, 0f, true, onSel, Modifier.fillMaxWidth().height(260.dp)) {
            b.gain = (it * 10).roundToInt() / 10f
            p.edit(i)
        }
        Gap(6)
        Column(
            Modifier.clip(RoundedCornerShape(10.dp)).background(if (selected) C.card2 else Color.Transparent)
                .press(onSel).padding(horizontal = 4.dp, vertical = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            T(fLabel(b.freq), 14, C.label, FontWeight.Bold)
            T("%.1f".format(b.gain), 12, if (selected) C.label else C.label2, FontWeight.Medium, true)
        }
    }
}

@Composable
fun PowerEq(p: Params, sel: Int, onSel: (Int) -> Unit) {
    val scroll = rememberScrollState()
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(
            Modifier.width(64.dp).clip(RoundedCornerShape(26.dp)).background(Color(0xFF141416))
                .border(0.5.dp, C.sep, RoundedCornerShape(26.dp)),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            NeonSlider(p.preamp, -12f, 12f, 0f, false, {}, Modifier.fillMaxWidth().height(260.dp)) {
                p.preamp = (it * 10).roundToInt() / 10f
                p.pushMaster(); p.pushSession()
            }
            Gap(6)
            Column(Modifier.padding(bottom = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                T("Preamp", 13, C.label, FontWeight.Bold)
                T("%.1f".format(p.preamp), 12, C.label2, FontWeight.Medium, true)
            }
        }
        Row(Modifier.weight(1f).horizontalScroll(scroll)) {
            for (i in 0 until p.bandCount) PBand(p, i, i == sel) { onSel(i) }
        }
    }
    MiniGraph(p, scroll)
}

@Composable
fun MiniGraph(p: Params, scroll: ScrollState) {
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    fun maxV(): Int = if (scroll.maxValue == Int.MAX_VALUE) 0 else scroll.maxValue
    fun goTo(x: Float, wPx: Float) {
        val total = p.bandCount * with(density) { COL_W.toPx() }
        val view = total - maxV()
        val target = (x / wPx * total - view / 2f).toInt().coerceIn(0, maxV())
        scope.launch { scroll.scrollTo(target) }
    }
    Canvas(
        Modifier.fillMaxWidth().height(84.dp).clip(RoundedCornerShape(22.dp)).background(Color(0xFF141416))
            .pointerInput(Unit) { detectTapGestures(onTap = { o -> goTo(o.x, size.width.toFloat()) }) }
            .pointerInput(Unit) { detectDragGestures { c, _ -> goTo(c.position.x, size.width.toFloat()) } }
    ) {
        val w = size.width
        val h = size.height
        val total = p.bandCount * COL_W.toPx()
        val view = (total - maxV()).coerceAtLeast(1f)
        val a = scroll.value / total * w
        val b = ((scroll.value + view) / total * w).coerceAtMost(w)
        drawRoundRect(Color(0xFF2C2C2F), Offset(a, 0f), Size((b - a).coerceAtLeast(0f), h), CornerRadius(20.dp.toPx()))
        val stages = p.stagesAll()
        val f0 = bandFreq(p.bandCount, 0).toDouble()
        val f1 = bandFreq(p.bandCount, p.bandCount - 1).toDouble()
        val zeroY = h / 2
        drawLine(Color(0xFF4A4A4C), Offset(0f, zeroY), Offset(w, zeroY), 1f)
        val n = 120
        var px = 0f
        var py = zeroY
        for (i in 0..n) {
            val t = i / n.toDouble()
            val db = respDb(stages, f0 * Math.pow(f1 / f0, t)).toFloat().coerceIn(-24f, 24f)
            val x = (t * w).toFloat()
            val y = zeroY - db / 24f * (h * 0.42f)
            if (i > 0) drawLine(gainColor(db), Offset(px, py), Offset(x, y), 3.dp.toPx(), cap = StrokeCap.Round)
            px = x
            py = y
        }
    }
}

// ───────────────────────── Parametric curve ─────────────────────────
private fun nearest(p: Params, o: Offset, w: Float, h: Float): Int {
    var best = -1
    var bd = 70f
    for (i in 0 until p.bandCount) {
        val b = p.bands[i]
        val dx = xOf(b.freq, w) - o.x
        val dy = yOf(if (b.type <= 2) b.gain else 0f, h) - o.y
        val d = sqrt(dx * dx + dy * dy)
        if (d < bd) { bd = d; best = i }
    }
    return best
}

@Composable
fun EqCurve(p: Params, sel: Int, onSel: (Int) -> Unit, modifier: Modifier) {
    val cbSel by rememberUpdatedState(onSel)
    Canvas(
        modifier
            .pointerInput(Unit) {
                detectTapGestures(onTap = { o ->
                    val n = nearest(p, o, size.width.toFloat(), size.height.toFloat())
                    if (n >= 0) cbSel(n)
                })
            }
            .pointerInput(Unit) {
                var drag = -1
                detectDragGestures(
                    onDragStart = { o ->
                        drag = nearest(p, o, size.width.toFloat(), size.height.toFloat())
                        if (drag >= 0) cbSel(drag)
                    },
                    onDragEnd = { drag = -1 },
                    onDragCancel = { drag = -1 }
                ) { change, _ ->
                    if (drag >= 0) {
                        val b = p.bands[drag]
                        b.freq = fOf(change.position.x, size.width.toFloat()).coerceIn(20f, 20000f)
                        if (b.type <= 2) b.gain = (gOf(change.position.y, size.height.toFloat()) * 10).roundToInt() / 10f
                        p.edit(drag)
                    }
                }
            }
    ) {
        val tk = Live.tick
        val w = size.width
        val h = size.height
        for (g in listOf(-24, -12, 0, 12, 24)) {
            val y = yOf(g.toFloat(), h)
            drawLine(if (g == 0) C.sep else C.grid, Offset(0f, y), Offset(w, y), 1f)
        }
        for (f in listOf(100f, 1000f, 10000f)) drawLine(C.grid, Offset(xOf(f, w), 0f), Offset(xOf(f, w), h), 1f)
        if (!Live.zoom) drawPath(curve(Live.bins, w, h, true), Brush.verticalGradient(listOf(C.teal.copy(alpha = 0.18f), Color.Transparent)))
        val stages = p.stagesAll()
        val path = Path()
        val n = 160
        for (i in 0..n) {
            val db = respDb(stages, 20.0 * Math.pow(1000.0, i / n.toDouble())).toFloat().coerceIn(-24f, 24f)
            val x = w * i / n
            val y = yOf(db, h)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, C.green, style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        for (i in 0 until p.bandCount) {
            val b = p.bands[i]
            val x = xOf(b.freq, w)
            val y = yOf(if (b.type <= 2) b.gain else 0f, h)
            if (i == sel) {
                drawCircle(C.green.copy(alpha = 0.25f), 13.dp.toPx(), Offset(x, y))
                drawCircle(C.green, 6.dp.toPx(), Offset(x, y))
            } else {
                drawCircle(if (b.byp) C.label3 else C.label2, 3.5.dp.toPx(), Offset(x, y))
            }
        }
    }
}

@Composable
fun CurveCard(p: Params, sel: Int, onSel: (Int) -> Unit) {
    GlassCard(pad = 12) {
        EqCurve(p, sel, onSel, Modifier.fillMaxWidth().height(260.dp))
        Gap(4)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            T("20", 10, C.label3); T("100", 10, C.label3); T("1k", 10, C.label3); T("10k", 10, C.label3); T("20k", 10, C.label3)
        }
    }
}

// ───────────────────────── Cards ─────────────────────────
@Composable
fun BandsCard(p: Params) {
    GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Label("NUMBER OF BANDS")
                T("${p.bandCount}", 34, C.label, FontWeight.Light, true)
            }
            Stepper({ p.changeBandCount(p.bandCount - 1) }, { p.changeBandCount(p.bandCount + 1) })
        }
        Gap(10)
        HSlider((p.bandCount - 5) / 27f, C.green, { val n = 5 + (it * 27f).roundToInt(); p.changeBandCount(n) }, Modifier.fillMaxWidth())
        Gap(6)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(5, 8, 10, 15, 20, 25, 32).forEach { n -> Chip("$n", p.bandCount == n) { p.changeBandCount(n) } }
        }
        Gap(8)
        T("Changing the count keeps your current sound as closely as it can.", 11, C.label2, maxLines = 2)
    }
}

@Composable
fun BandEditor(p: Params, sel: Int) {
    val b = p.bands[sel]
    GlassCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Label("BAND ${sel + 1} OF ${p.bandCount}")
                T(fmtF(b.freq) + "  ·  " + (if (b.type <= 2) num(b.gain, 1) + " dB" else "—"), 20, C.label, FontWeight.Light, true)
            }
            Pill("Reset") {
                b.gain = 0f; b.byp = false; b.type = 0; b.freq = bandFreq(p.bandCount, sel); b.q = autoQ(p.bandCount)
                p.edit(sel)
            }
        }
        Gap(10)
        Label("FREQUENCY")
        HSlider(
            (ln(b.freq / 20f) / ln(1000f)).coerceIn(0f, 1f), C.green,
            { b.freq = (20.0 * Math.pow(1000.0, it.toDouble())).toFloat(); p.edit(sel) }, Modifier.fillMaxWidth()
        )
        Label("Q")
        HSlider(nOfQ(b.q), C.green, { b.q = qOf(it); p.edit(sel) }, Modifier.fillMaxWidth())
        Gap(8)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            typeNames.forEachIndexed { i, n -> Chip(n, b.type == i) { b.type = i; p.edit(sel) } }
        }
        Gap(12)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { T("Bypass this band", 15) }
            IOSSwitch(b.byp) { b.byp = it; p.edit(sel) }
        }
    }
}

@Composable
fun ToneCard(p: Params) {
    GlassCard {
        Label("TONE")
        Gap(14)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Knob("BASS", p.bass, 0f, 1f, 0f, C.orange, { "${(it * 100).roundToInt()}" }, "%") { p.bass = it; p.editTone() }
            Knob("TREBLE", p.treble, 0f, 1f, 0f, C.teal, { "${(it * 100).roundToInt()}" }, "%") { p.treble = it; p.editTone() }
        }
        Gap(10)
        Box(Modifier.fillMaxWidth().height(0.5.dp).background(C.sep))
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T("Limiter", 16)
                T("Soft ceiling at −1 dBFS", 12, C.label2)
            }
            IOSSwitch(p.limOn) { p.limOn = it; p.pushEq() }
        }
    }
}

@Composable
fun PresetCard(p: Params) {
    GlassCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { Label("PRESETS") }
            Pill("Save current") { p.saveCustom() }
        }
        Gap(10)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PRESETS.forEach { (name, g) -> Chip(name, p.presetName == name) { p.applyPreset(name, g) } }
            p.custom.forEach { c -> Chip(c.name, p.presetName == c.name) { p.applyPreset(c.name, c.gains) } }
        }
        if (p.custom.any { it.name == p.presetName }) {
            Gap(10)
            Pill("Delete " + p.presetName) { p.deleteCustom(p.presetName) }
        }
    }
}

@Composable
fun EqScreen(p: Params) {
    var view by remember { mutableIntStateOf(0) }
    var sel by remember { mutableIntStateOf(0) }
    val s = sel.coerceIn(0, p.bandCount - 1)
    Screen(
        "Equalizer",
        trailing = { IOSSwitch(p.eqOn) { p.eqOn = it; p.pushMaster(); p.pushEq() } },
        sub = { T("${p.bandCount} bands · " + (if (p.presetName.isEmpty()) "Custom" else p.presetName), 13, C.label2) }
    ) {
        Segmented(listOf("Sliders", "Curve"), view, { view = it }, Modifier.fillMaxWidth())
        if (view == 0) PowerEq(p, s) { sel = it } else CurveCard(p, s) { sel = it }
        BandsCard(p)
        BandEditor(p, s)
        ToneCard(p)
        PresetCard(p)
    }
}
