package com.example.dsp;

import android.os.Build;
import android.os.ParcelFileDescriptor;

import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * Started by the app through Shizuku as a plain shell command (same way scrcpy launches its server):
 *   CLASSPATH=base.apk app_process /system/bin com.example.dsp.CaptureMain 48000
 * Captures the device's audio output and writes raw 16-bit stereo PCM to stdout. Progress and errors go to stderr,
 * which the app shows on the Status card.
 */
public final class CaptureMain {
    public static void main(String[] args) {
        int sr = 48000;
        try { if (args.length > 0) sr = Integer.parseInt(args[0]); } catch (Throwable ignored) {}
        CaptureService svc = null;
        // exit when the app goes away (its end of stdin closes), so no stale helper keeps the capture slot busy
        final long t0 = System.currentTimeMillis();
        Thread watchdog = new Thread(() -> {
            try { while (System.in.read() >= 0) { /* ignore */ } } catch (Throwable ignored) {}
            if (System.currentTimeMillis() - t0 > 3000) {
                System.err.println("helper: app closed the connection, exiting");
                System.exit(0);
            }
        }, "parent-watch");
        watchdog.setDaemon(true);
        watchdog.start();
        try {
            System.err.println("helper: started uid=" + android.os.Process.myUid() + " sdk=" + Build.VERSION.SDK_INT
                    + " device=" + Build.MANUFACTURER + " " + Build.MODEL);
            svc = new CaptureService();
            ParcelFileDescriptor pfd = svc.start(sr);
            if (pfd == null) {
                System.err.println("capture failed: " + svc.lastError());
                System.exit(2);
                return;
            }
            System.err.println("helper: capturing");
            FileOutputStream out = new FileOutputStream(FileDescriptor.out);
            out.write(new byte[1920]);                 // handshake: tells the app capture is live
            InputStream in = new ParcelFileDescriptor.AutoCloseInputStream(pfd);
            byte[] buf = new byte[1920];
            int n;
            while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);   // throws when the app goes away -> we exit
        } catch (Throwable t) {
            t.printStackTrace();
        }
        try { if (svc != null) svc.stop(); } catch (Throwable ignored) {}
        System.exit(0);
    }
}
