package com.example.dsp

import android.os.SystemClock
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

// ───────────────────────── Design tokens (iOS dark) ─────────────────────────
object C {
    val bg = Color(0xFF000000)
    val card = Color(0xFF1C1C1E)
    val card2 = Color(0xFF2C2C2E)
    val well = Color(0xFF111113)
    val sep = Color(0xFF38383A)
    val grid = Color(0xFF232325)
    val label = Color(0xFFFFFFFF)
    val label2 = Color(0x99EBEBF5)
    val label3 = Color(0x4DEBEBF5)
    val blue = Color(0xFF0A84FF)
    val teal = Color(0xFF64D2FF)
    val pink = Color(0xFFFF375F)
    val orange = Color(0xFFFF9F0A)
    val green = Color(0xFF30D158)
}

class Actions(
    val listener: () -> Unit,
    val startCapture: () -> Unit,
    val stopCapture: () -> Unit,
    val startShizuku: () -> Unit,
    val stopShizuku: () -> Unit
)

/** Live readings from the native engine, polled once per frame. */
object Live {
    val bins = FloatArray(96)
    val st = FloatArray(12)
    val inHist = FloatArray(200)
    val subHist = FloatArray(200)
    var tick by mutableLongStateOf(0L)
    var zoom = true
    private var frame = 0

    fun poll(now: Long) {
        if (zoom) NativeDsp.spectrum(bins, 20f, 200f) else NativeDsp.spectrum(bins, 20f, 20000f)
        NativeDsp.status(st)
        frame++
        if (frame % 3 == 0) {
            System.arraycopy(inHist, 1, inHist, 0, 199); inHist[199] = st[4]
            System.arraycopy(subHist, 1, subHist, 0, 199); subHist[199] = st[5]
        }
        tick = now
    }
}

// ───────────────────────── Primitives ─────────────────────────
@Composable
fun T(
    s: String, size: Int = 14, color: Color = C.label, weight: FontWeight = FontWeight.Normal,
    mono: Boolean = false, modifier: Modifier = Modifier, spacing: Float = 0f, maxLines: Int = 1
) {
    Text(
        s, modifier = modifier, maxLines = maxLines, overflow = TextOverflow.Ellipsis,
        style = TextStyle(
            color = color, fontSize = size.sp, fontWeight = weight, letterSpacing = spacing.sp,
            fontFeatureSettings = if (mono) "tnum" else null
        )
    )
}

@Composable
fun Gap(h: Int) { Spacer(Modifier.height(h.dp)) }

@Composable
fun Label(s: String) { T(s, 11, C.label2, FontWeight.SemiBold, spacing = 1f) }

@Composable
fun Modifier.tap(onClick: () -> Unit): Modifier =
    this.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)

@Composable
fun GlassCard(modifier: Modifier = Modifier, pad: Int = 16, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier.fillMaxWidth().clip(shape).background(C.card).border(0.5.dp, C.sep, shape).padding(pad.dp),
        content = content
    )
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val haptic = LocalHapticFeedback.current
    Row(modifier.clip(RoundedCornerShape(11.dp)).background(C.well).padding(2.dp)) {
        options.forEachIndexed { i, o ->
            val on = i == selected
            val bg by animateColorAsState(if (on) C.card2 else Color.Transparent)
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(9.dp)).background(bg)
                    .tap { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onSelect(i) }
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) { T(o, 12, if (on) C.label else C.label2, if (on) FontWeight.SemiBold else FontWeight.Medium) }
        }
    }
}

@Composable
fun Chip(text: String, on: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (on) C.blue else C.card2)
    Box(Modifier.clip(RoundedCornerShape(50)).background(bg).tap(onClick).padding(horizontal = 14.dp, vertical = 8.dp)) {
        T(text, 12, if (on) Color.White else C.label2, FontWeight.SemiBold)
    }
}

@Composable
fun Pill(text: String, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(C.card2).tap(onClick).padding(horizontal = 16.dp, vertical = 9.dp)) {
        T(text, 12, C.blue, FontWeight.SemiBold)
    }
}

@Composable
fun Knob(
    label: String, value: Float, lo: Float, hi: Float, def: Float, accent: Color,
    fmt: (Float) -> String, unit: String, onChange: (Float) -> Unit
) {
    val v by rememberUpdatedState(value)
    val cb by rememberUpdatedState(onChange)
    val norm = ((value - lo) / (hi - lo)).coerceIn(0f, 1f)
    val anim by animateFloatAsState(norm)
    val haptic = LocalHapticFeedback.current
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(76.dp)) {
        Box(
            Modifier.size(68.dp)
                .pointerInput(Unit) {
                    detectTapGestures(onDoubleTap = {
                        cb(def); haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    })
                }
                .pointerInput(Unit) {
                    detectDragGestures { _, d -> cb((v - d.y * (hi - lo) / 220f).coerceIn(lo, hi)) }
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = 4.dp.toPx()
                val tl = Offset(stroke / 2, stroke / 2)
                val sz = Size(size.width - stroke, size.height - stroke)
                drawArc(C.card2, 135f, 270f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
                drawArc(accent, 135f, 270f * anim, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                T(fmt(value), 14, C.label, FontWeight.SemiBold, true)
                T(unit, 9, C.label2)
            }
        }
        Gap(6)
        T(label, 10, C.label2, FontWeight.Medium, spacing = 0.6f)
    }
}

@Composable
fun HSlider(norm: Float, accent: Color, onNorm: (Float) -> Unit, modifier: Modifier = Modifier) {
    val cb by rememberUpdatedState(onNorm)
    Canvas(
        modifier.height(28.dp).pointerInput(Unit) {
            detectDragGestures(onDragStart = { o -> cb((o.x / size.width).coerceIn(0f, 1f)) }) { c, _ ->
                cb((c.position.x / size.width).coerceIn(0f, 1f))
            }
        }
    ) {
        val cy = size.height / 2
        drawRoundRect(C.card2, Offset(0f, cy - 2.dp.toPx()), Size(size.width, 4.dp.toPx()), CornerRadius(2.dp.toPx()))
        drawRoundRect(accent, Offset(0f, cy - 2.dp.toPx()), Size(size.width * norm, 4.dp.toPx()), CornerRadius(2.dp.toPx()))
        drawCircle(Color.White, 10.dp.toPx(), Offset(size.width * norm, cy))
    }
}

@Composable
fun Glyph(kind: Int, tint: Color, sz: Dp) {
    Canvas(Modifier.size(sz)) {
        val w = size.width
        val h = size.height
        when (kind) {
            0 -> { // play
                val p = Path(); p.moveTo(w * 0.24f, h * 0.12f); p.lineTo(w * 0.88f, h * 0.5f); p.lineTo(w * 0.24f, h * 0.88f); p.close()
                drawPath(p, tint)
            }
            1 -> { // pause
                drawRoundRect(tint, Offset(w * 0.18f, h * 0.12f), Size(w * 0.24f, h * 0.76f), CornerRadius(w * 0.06f))
                drawRoundRect(tint, Offset(w * 0.58f, h * 0.12f), Size(w * 0.24f, h * 0.76f), CornerRadius(w * 0.06f))
            }
            2 -> { // next
                val p = Path(); p.moveTo(w * 0.12f, h * 0.18f); p.lineTo(w * 0.68f, h * 0.5f); p.lineTo(w * 0.12f, h * 0.82f); p.close()
                drawPath(p, tint)
                drawRoundRect(tint, Offset(w * 0.74f, h * 0.18f), Size(w * 0.14f, h * 0.64f), CornerRadius(w * 0.04f))
            }
            else -> { // previous
                val p = Path(); p.moveTo(w * 0.88f, h * 0.18f); p.lineTo(w * 0.32f, h * 0.5f); p.lineTo(w * 0.88f, h * 0.82f); p.close()
                drawPath(p, tint)
                drawRoundRect(tint, Offset(w * 0.12f, h * 0.18f), Size(w * 0.14f, h * 0.64f), CornerRadius(w * 0.04f))
            }
        }
    }
}

// ───────────────────────── Root ─────────────────────────
@Composable
fun AppRoot(p: Params, a: Actions) {
    var tab by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { p.pushAll() }
    LaunchedEffect(tab) { Live.zoom = tab == 0 }
    LaunchedEffect(Unit) { while (true) { withFrameNanos { Live.poll(it) } } }
    Column(Modifier.fillMaxSize().background(C.bg).statusBarsPadding()) {
        Header(tab) { tab = it }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (tab == 0) SubPage(p, a) else EqPage(p)
            Spacer(Modifier.height(24.dp).navigationBarsPadding())
        }
    }
}

@Composable
fun Header(tab: Int, onTab: (Int) -> Unit) {
    val hooked by DspState.hooked.collectAsState()
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            T("Subharmonic", 26, C.label, FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(6.dp).clip(CircleShape).background(if (hooked != null) C.green else C.label3))
                Spacer(Modifier.width(6.dp))
                T(hooked?.let { "Hooked · $it" } ?: "Waiting for playback", 12, C.label2)
            }
        }
        Segmented(listOf("SUB", "EQ"), tab, onTab, Modifier.width(120.dp))
    }
}

// ───────────────────────── SUB page ─────────────────────────
@Composable
fun SubPage(p: Params, a: Actions) {
    HeroCard(p)
    NowPlayingCard()
    Segmented(listOf("Original", "Subharmonic"), if (p.original) 0 else 1,
        { p.original = it == 0; p.pushMaster() }, Modifier.fillMaxWidth())

    GlassCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { Label("GENERATOR") }
            Pill("Reset") { p.resetSub() }
        }
        Gap(10)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Segmented(listOf("Sine", "Saw", "Square"), p.voice, { p.voice = it; p.pushSub() }, Modifier.weight(1.4f))
            Segmented(listOf("Osc", "Flip"), p.gen, { p.gen = it; p.pushSub() }, Modifier.weight(1f))
        }
        Gap(12)
        Chip("Auto sweep", p.auto) { p.auto = !p.auto; p.pushSub() }
    }

    GlassCard {
        Label("TRACKING")
        Gap(14)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Knob("SWEEP", p.sweep, 27f, 63f, 45f, C.orange, { "%.1f".format(it) }, "Hz") { p.sweep = it; p.pushSub() }
            Knob("WIDE", p.wide, 0.3f, 3f, 0.7f, C.teal, { "%.2f".format(it) }, "Q") { p.wide = it; p.pushSub() }
            Knob("SMOOTH", p.smooth, 0.5f, 3f, 1.2f, C.teal, { "%.1f".format(it) }, "×f") { p.smooth = it; p.pushSub() }
            Knob("SENS", p.sens, 0f, 1f, 0.73f, C.teal, { "${(it * 100).roundToInt()}" }, "%") { p.sens = it; p.pushSub() }
        }
    }

    GlassCard {
        Label("SUB OUTPUT")
        Gap(14)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Knob("SUB GAIN", p.gainDb, -60f, 12f, 6f, C.pink, { "%+.1f".format(it) }, "dB") { p.gainDb = it; p.pushSub() }
            Knob("DRIVE", p.drive, 0f, 1f, 0.3f, C.pink, { "${(it * 100).roundToInt()}" }, "%") { p.drive = it; p.pushSub() }
            Knob("PFM", p.pfm, 10f, 40f, 21f, C.pink, { "%.0f".format(it) }, "Hz") { p.pfm = it; p.pushSub() }
            Knob("MASTER", p.master, -24f, 12f, 0f, C.green, { "%+.1f".format(it) }, "dB") { p.master = it; p.pushMaster() }
        }
    }

    LevelsCard()
    PitchCard()
    SourceCard(p, a)
    Footer()
}

@Composable
fun HeroCard(p: Params) {
    GlassCard {
        Readouts(p)
        Gap(12)
        SpectrumView(p, Modifier.fillMaxWidth().height(150.dp))
        Gap(6)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            T("20 Hz", 10, C.label3); T("sub 27–63", 10, C.label3); T("200 Hz", 10, C.label3)
        }
    }
}

@Composable
fun Readouts(p: Params) {
    val tk = Live.tick
    val inHz = Live.st[4]
    val subHz = Live.st[5]
    val locked = Live.st[3] > 0.5f
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            T("INPUT ÷2", 10, C.label2, FontWeight.SemiBold, spacing = 0.8f)
            T(if (inHz > 0f) "%.1f".format(inHz) else "—", 28, C.teal, FontWeight.Light, true)
        }
        Column(Modifier.weight(1f)) {
            T("SUB", 10, C.label2, FontWeight.SemiBold, spacing = 0.8f)
            T(if (subHz > 0f) "%.1f".format(subHz) else "—", 28, C.pink, FontWeight.Light, true)
        }
        Column(Modifier.weight(1f)) {
            T("SWEEP", 10, C.label2, FontWeight.SemiBold, spacing = 0.8f)
            T("%.1f".format(p.sweep), 28, C.orange, FontWeight.Light, true)
        }
        Row(
            Modifier.clip(RoundedCornerShape(50)).background(C.well).padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(6.dp).clip(CircleShape).background(if (locked) C.green else C.label3))
            Spacer(Modifier.width(6.dp))
            T(if (locked) "LOCKED" else "SEARCH", 9, if (locked) C.green else C.label2, FontWeight.Bold, spacing = 0.8f)
        }
    }
}

private fun curve(bins: FloatArray, w: Float, h: Float, close: Boolean): Path {
    val p = Path()
    val n = bins.size
    if (close) { p.moveTo(0f, h); p.lineTo(0f, h * (1f - bins[0])) } else p.moveTo(0f, h * (1f - bins[0]))
    for (i in 1 until n) {
        val x = w * i / (n - 1)
        val y = h * (1f - bins[i])
        val px = w * (i - 1) / (n - 1)
        val py = h * (1f - bins[i - 1])
        p.cubicTo((px + x) / 2, py, (px + x) / 2, y, x, y)
    }
    if (close) { p.lineTo(w, h); p.close() }
    return p
}

@Composable
fun SpectrumView(p: Params, modifier: Modifier) {
    Canvas(modifier) {
        val tk = Live.tick
        val w = size.width
        val h = size.height
        for (g in 1..3) drawLine(C.grid, Offset(0f, h * g / 4), Offset(w, h * g / 4), 1f)
        drawPath(curve(Live.bins, w, h, true), Brush.verticalGradient(listOf(C.teal.copy(alpha = 0.35f), Color.Transparent)))
        drawPath(curve(Live.bins, w, h, false), C.teal, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
        fun xz(f: Float) = (ln(f / 20f) / ln(10f) * w).coerceIn(0f, w)
        val inHz = Live.st[4]
        val subHz = Live.st[5]
        if (inHz > 0f) drawLine(C.teal, Offset(xz(inHz), 0f), Offset(xz(inHz), h), 1.5f, pathEffect = dash)
        if (subHz > 0f) drawLine(C.pink, Offset(xz(subHz), 0f), Offset(xz(subHz), h), 1.5f, pathEffect = dash)
        drawCircle(C.orange, 4.dp.toPx(), Offset(xz(p.sweep), h - 4.dp.toPx()))
    }
}

@Composable
fun NowPlayingCard() {
    val np by DspState.now.collectAsState()
    var nowMs by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(Unit) { while (true) { nowMs = SystemClock.elapsedRealtime(); delay(500) } }
    GlassCard {
        val n = np
        if (n == null) {
            T("Nothing playing", 15, C.label, FontWeight.SemiBold)
            Gap(2)
            T("Turn on notification access, then start any music app.", 12, C.label2, maxLines = 2)
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val art = n.art
                if (art != null) {
                    Image(art.asImageBitmap(), null, Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)))
                } else {
                    Box(
                        Modifier.size(56.dp).clip(RoundedCornerShape(12.dp))
                            .background(Brush.linearGradient(listOf(C.pink, C.blue)))
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    T(if (n.title.isEmpty()) n.app else n.title, 15, C.label, FontWeight.SemiBold)
                    T(if (n.artist.isEmpty()) n.app else n.artist, 12, C.label2)
                }
                Spacer(Modifier.width(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.tap { DspState.controller?.transportControls?.skipToPrevious() }) { Glyph(3, C.label, 22.dp) }
                    Box(Modifier.tap {
                        val tc = DspState.controller?.transportControls
                        if (n.playing) tc?.pause() else tc?.play()
                    }) { Glyph(if (n.playing) 1 else 0, C.label, 28.dp) }
                    Box(Modifier.tap { DspState.controller?.transportControls?.skipToNext() }) { Glyph(2, C.label, 22.dp) }
                }
            }
            Gap(12)
            val frac = if (n.dur > 0) n.positionAt(nowMs).toFloat() / n.dur else 0f
            Canvas(Modifier.fillMaxWidth().height(4.dp)) {
                drawRoundRect(C.card2, size = size, cornerRadius = CornerRadius(2.dp.toPx()))
                drawRoundRect(C.label, size = Size(size.width * frac.coerceIn(0f, 1f), size.height), cornerRadius = CornerRadius(2.dp.toPx()))
            }
        }
    }
}

@Composable
fun LevelsCard() {
    GlassCard {
        Label("LEVELS · PEAK dBFS")
        Gap(10)
        Level("DRY", 6, C.blue)
        Level("SUB", 7, C.pink)
        Level("OUT", 8, C.green)
    }
}

@Composable
fun Level(name: String, idx: Int, color: Color) {
    val tk = Live.tick
    val v = Live.st[idx]
    val db = if (v < 1e-5f) -100f else 20f * log10(v)
    Row(Modifier.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        T(name, 10, C.label2, FontWeight.SemiBold, modifier = Modifier.width(34.dp), spacing = 0.8f)
        Canvas(Modifier.weight(1f).height(6.dp)) {
            drawRoundRect(C.card2, size = size, cornerRadius = CornerRadius(3.dp.toPx()))
            val f = ((db + 60f) / 60f).coerceIn(0f, 1f)
            val col = if (db > -1f) C.pink else if (db > -6f) C.orange else color
            drawRoundRect(col, size = Size(size.width * f, size.height), cornerRadius = CornerRadius(3.dp.toPx()))
        }
        Spacer(Modifier.width(10.dp))
        T(if (db <= -99f) "-inf" else "%.1f".format(db), 11, C.label2, FontWeight.Medium, true, Modifier.width(44.dp))
    }
}

@Composable
fun PitchCard() {
    GlassCard {
        Label("PITCH · LAST 10 S")
        Gap(10)
        Canvas(Modifier.fillMaxWidth().height(90.dp)) {
            val tk = Live.tick
            val w = size.width
            val h = size.height
            for (g in 1..2) drawLine(C.grid, Offset(0f, h * g / 3), Offset(w, h * g / 3), 1f)
            fun line(a: FloatArray, col: Color) {
                val path = Path()
                var started = false
                for (i in a.indices) {
                    val v = a[i]
                    if (v > 0f) {
                        val x = w * i / (a.size - 1)
                        val y = h * (1f - (ln(v / 20f) / ln(7f)).coerceIn(0f, 1f))
                        if (!started) { path.moveTo(x, y); started = true } else path.lineTo(x, y)
                    } else started = false
                }
                drawPath(path, col, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            line(Live.inHist, C.teal)
            line(Live.subHist, C.pink)
        }
        Gap(6)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            T("● input", 10, C.teal); T("● sub", 10, C.pink); T("20–140 Hz", 10, C.label3)
        }
    }
}

@Composable
fun SourceCard(p: Params, a: Actions) {
    val mode by DspState.mode.collectAsState()
    val capturing by DspState.capturing.collectAsState()
    val note by DspState.note.collectAsState()
    GlassCard {
        Label("SOURCE")
        Gap(10)
        Segmented(listOf("Effects", "Capture", "Shizuku"), mode, { m ->
            if (capturing) { a.stopCapture(); a.stopShizuku() }
            DspState.mode.value = m
            DspState.note.value = ""
            p.pushMaster()
        }, Modifier.fillMaxWidth())
        Gap(10)
        T(
            when (mode) {
                0 -> "Works with Spotify and most players, with no echo. Applies the EQ, bass boost and limiter through Android audio effects. The synthesized sub is not available here."
                1 -> "Full DSP, but apps like Spotify block capture, and the original stays audible next to the processed copy."
                else -> "Full DSP on any app, Spotify included, and the original is muted so there is no echo. Needs Shizuku running."
            }, 12, C.label2, maxLines = 4
        )
        Gap(12)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill("Notification access") { a.listener() }
            if (mode == 1) Pill(if (capturing) "Stop capture" else "Start capture") { if (capturing) a.stopCapture() else a.startCapture() }
            if (mode == 2) Pill(if (capturing) "Disconnect" else "Connect") { if (capturing) a.stopShizuku() else a.startShizuku() }
        }
        if (note.isNotEmpty()) { Gap(10); T(note, 11, C.orange, maxLines = 6) }
    }
}

@Composable
fun Footer() {
    val tk = Live.tick
    val mode by DspState.mode.collectAsState()
    val fs = Live.st[0]
    val txt = "${if (fs > 0f) "%.1f kHz".format(fs / 1000f) else "—"} · ${"%.1f".format(Live.st[1])} ms · underruns ${Live.st[2].toInt()} · " +
        when (mode) { 0 -> "Effects"; 1 -> "Capture"; else -> "Shizuku" }
    Box(Modifier.fillMaxWidth().padding(top = 4.dp), contentAlignment = Alignment.Center) { T(txt, 10, C.label3, mono = true) }
}

// ───────────────────────── EQ page ─────────────────────────
private const val FS = 48000.0
private val typeNames = listOf("Bell", "Low shelf", "High shelf", "LP 12", "HP 12", "Notch", "LP 24", "HP 24")

private fun xOf(f: Float, w: Float) = ln(f / 20f) / ln(1000f) * w
private fun fOf(x: Float, w: Float) = (20.0 * Math.pow(1000.0, (x / w).toDouble().coerceIn(0.0, 1.0))).toFloat()
private fun yOf(g: Float, h: Float) = (24f - g) / 48f * h
private fun gOf(y: Float, h: Float) = (24f - y / h * 48f).coerceIn(-24f, 24f)
private fun qOf(n: Float) = (0.1 * Math.pow(240.0, n.toDouble())).toFloat()
private fun nOfQ(q: Float) = (ln(q / 0.1f) / ln(240f)).coerceIn(0f, 1f)
private fun fmtF(f: Float) = if (f >= 1000f) "%.2f kHz".format(f / 1000f) else "%.0f Hz".format(f)

// RBJ cookbook biquad, same maths as the native engine (used to draw the true response)
private fun rbjK(t: Int, f0: Double, gdb: Double, q: Double): DoubleArray {
    val f = f0.coerceIn(10.0, FS * 0.49)
    val a = Math.pow(10.0, gdb / 40.0)
    val w = 2 * Math.PI * f / FS
    val c = cos(w)
    val s = sin(w)
    val al = s / (2 * q)
    val k = 2 * sqrt(a) * al
    val b0: Double; val b1: Double; val b2: Double; val a0: Double; val a1: Double; val a2: Double
    when (t) {
        0 -> { b0 = 1 + al * a; b1 = -2 * c; b2 = 1 - al * a; a0 = 1 + al / a; a1 = -2 * c; a2 = 1 - al / a }
        1 -> {
            b0 = a * ((a + 1) - (a - 1) * c + k); b1 = 2 * a * ((a - 1) - (a + 1) * c); b2 = a * ((a + 1) - (a - 1) * c - k)
            a0 = (a + 1) + (a - 1) * c + k; a1 = -2 * ((a - 1) + (a + 1) * c); a2 = (a + 1) + (a - 1) * c - k
        }
        2 -> {
            b0 = a * ((a + 1) + (a - 1) * c + k); b1 = -2 * a * ((a - 1) + (a + 1) * c); b2 = a * ((a + 1) + (a - 1) * c - k)
            a0 = (a + 1) - (a - 1) * c + k; a1 = 2 * ((a - 1) - (a + 1) * c); a2 = (a + 1) - (a - 1) * c - k
        }
        3 -> { b0 = (1 - c) / 2; b1 = 1 - c; b2 = b0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al }
        4 -> { b0 = (1 + c) / 2; b1 = -(1 + c); b2 = b0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al }
        else -> { b0 = 1.0; b1 = -2 * c; b2 = 1.0; a0 = 1 + al; a1 = -2 * c; a2 = 1 - al }
    }
    return doubleArrayOf(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
}

private fun stagesOf(b: BandState): List<DoubleArray> = when {
    b.byp -> emptyList()
    b.type == 6 -> listOf(rbjK(3, b.freq.toDouble(), 0.0, 0.5412), rbjK(3, b.freq.toDouble(), 0.0, 1.3066))
    b.type == 7 -> listOf(rbjK(4, b.freq.toDouble(), 0.0, 0.5412), rbjK(4, b.freq.toDouble(), 0.0, 1.3066))
    b.type <= 2 && abs(b.gain) < 0.01f -> emptyList()
    else -> listOf(rbjK(b.type, b.freq.toDouble(), b.gain.toDouble(), b.q.toDouble()))
}

private fun magDb(c: DoubleArray, w: Double): Double {
    val cw = cos(w); val sw = sin(w); val c2 = cos(2 * w); val s2 = sin(2 * w)
    val nr = c[0] + c[1] * cw + c[2] * c2
    val ni = -(c[1] * sw + c[2] * s2)
    val dr = 1 + c[3] * cw + c[4] * c2
    val di = -(c[3] * sw + c[4] * s2)
    return 10 * log10((nr * nr + ni * ni) / (dr * dr + di * di) + 1e-30)
}

private fun nearest(p: Params, o: Offset, w: Float, h: Float): Int {
    var best = -1
    var bd = 70f
    for (i in 0 until 32) {
        val b = p.bands[i]
        val dx = xOf(b.freq, w) - o.x
        val dy = yOf(if (b.type <= 2) b.gain else 0f, h) - o.y
        val d = sqrt(dx * dx + dy * dy)
        if (d < bd) { bd = d; best = i }
    }
    return best
}

@Composable
fun EqPage(p: Params) {
    var sel by remember { mutableIntStateOf(0) }
    GlassCard(pad = 12) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { Label("PARAMETRIC EQ · 32 BANDS") }
            Pill("Flat") { p.resetEq() }
        }
        Gap(8)
        EqCurve(p, sel, { sel = it }, Modifier.fillMaxWidth().height(250.dp))
        Gap(4)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            T("20", 10, C.label3); T("100", 10, C.label3); T("1k", 10, C.label3); T("10k", 10, C.label3); T("20k", 10, C.label3)
        }
    }
    val b = p.bands[sel]
    GlassCard {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T("Band ${sel + 1}", 17, C.label, FontWeight.SemiBold)
                T("${fmtF(b.freq)} · ${if (b.type <= 2) "%+.1f dB".format(b.gain) else "—"} · Q ${"%.2f".format(b.q)}", 12, C.label2, mono = true)
            }
            Chip("Bypass", b.byp) { b.byp = !b.byp; p.applyBand(sel) }
        }
        Gap(12)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            typeNames.forEachIndexed { i, n -> Chip(n, b.type == i) { b.type = i; p.applyBand(sel) } }
        }
        Gap(12)
        Label("Q")
        HSlider(nOfQ(b.q), C.blue, { b.q = qOf(it); p.applyBand(sel) }, Modifier.fillMaxWidth())
    }
}

@Composable
fun EqCurve(p: Params, sel: Int, onSel: (Int) -> Unit, modifier: Modifier) {
    val cbSel by rememberUpdatedState(onSel)
    Canvas(
        modifier
            .pointerInput(Unit) {
                detectTapGestures(onTap = { o ->
                    val n = nearest(p, o, size.width.toFloat(), size.height.toFloat())
                    if (n >= 0) cbSel(n)
                })
            }
            .pointerInput(Unit) {
                var drag = -1
                detectDragGestures(
                    onDragStart = { o ->
                        drag = nearest(p, o, size.width.toFloat(), size.height.toFloat())
                        if (drag >= 0) cbSel(drag)
                    },
                    onDragEnd = { drag = -1 },
                    onDragCancel = { drag = -1 }
                ) { change, _ ->
                    if (drag >= 0) {
                        val b = p.bands[drag]
                        b.freq = fOf(change.position.x, size.width.toFloat()).coerceIn(20f, 20000f)
                        if (b.type <= 2) b.gain = gOf(change.position.y, size.height.toFloat())
                        p.applyBand(drag)
                    }
                }
            }
    ) {
        val tk = Live.tick
        val w = size.width
        val h = size.height
        for (g in listOf(-24, -12, 0, 12, 24)) {
            val y = yOf(g.toFloat(), h)
            drawLine(if (g == 0) C.sep else C.grid, Offset(0f, y), Offset(w, y), 1f)
        }
        for (f in listOf(100f, 1000f, 10000f)) drawLine(C.grid, Offset(xOf(f, w), 0f), Offset(xOf(f, w), h), 1f)
        if (!Live.zoom) drawPath(curve(Live.bins, w, h, true), Brush.verticalGradient(listOf(C.teal.copy(alpha = 0.18f), Color.Transparent)))

        val all = p.bands.map { stagesOf(it) }
        val path = Path()
        val n = 160
        for (i in 0..n) {
            val f = 20.0 * Math.pow(1000.0, i / n.toDouble())
            val wv = 2 * Math.PI * f / FS
            var db = 0.0
            for (st in all) for (c in st) db += magDb(c, wv)
            val y = yOf(db.toFloat().coerceIn(-24f, 24f), h)
            val x = w * i / n
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, C.label, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))

        for (i in 0 until 32) {
            val b = p.bands[i]
            val x = xOf(b.freq, w)
            val y = yOf(if (b.type <= 2) b.gain else 0f, h)
            if (i == sel) {
                drawCircle(C.blue.copy(alpha = 0.25f), 13.dp.toPx(), Offset(x, y))
                drawCircle(C.blue, 6.dp.toPx(), Offset(x, y))
            } else {
                drawCircle(if (b.byp) C.label3 else C.label2, 3.5.dp.toPx(), Offset(x, y))
            }
        }
    }
}
