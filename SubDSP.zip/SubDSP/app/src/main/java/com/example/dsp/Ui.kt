package com.example.dsp

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.Button
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.lazy.items

@Composable
fun DspScreen(onStart: () -> Unit, onStop: () -> Unit, onGrantListener: () -> Unit) {
    val hooked by DspState.hooked.collectAsState()
    val capturing by DspState.capturing.collectAsState()
    var on by remember { mutableStateOf(true) }
    var drive by remember { mutableFloatStateOf(.4f) }
    var sweep by remember { mutableFloatStateOf(.5f) }
    var sub by remember { mutableFloatStateOf(.33f) }

    fun pushEpi() = NativeDsp.setEpicenter(drive, 27f + 36f * sweep, 1f, 18f * sub, 1f)
    LaunchedEffect(Unit) { pushEpi(); NativeDsp.setMaster(0f, 0f, -1f, true) }

    Column(Modifier.fillMaxSize().background(Color(0xFF0D0D0D)).statusBarsPadding().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            Text(hooked?.let { "Hooked: $it" } ?: "No active playback", color = Color(0xFF00E5FF), fontSize = 14.sp)
            Switch(on, { on = it; NativeDsp.setMaster(0f, 0f, -1f, it) })
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onGrantListener) { Text("Listener", fontSize = 12.sp) }
            Button(onClick = { if (capturing) onStop() else onStart() }) {
                Text(if (capturing) "Stop" else "Start capture", fontSize = 12.sp)
            }
        }
        Spectrum(Modifier.fillMaxWidth().height(180.dp).padding(vertical = 12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Knob("Drive", drive) { drive = it; pushEpi() }
            Knob("Sweep", sweep) { sweep = it; pushEpi() }
            Knob("Sub", sub) { sub = it; pushEpi() }
        }
        Spacer(Modifier.height(12.dp))
        EqStrip()
    }
}

@Composable
fun Spectrum(modifier: Modifier) {
    val bins = remember { FloatArray(96) }
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) { while (true) withFrameNanos { NativeDsp.spectrum(bins); tick = it } }
    Canvas(modifier) {
        tick
        val p = Path(); val dx = size.width / (bins.size - 1)
        p.moveTo(0f, size.height)
        bins.forEachIndexed { i, v ->
            val x = i * dx; val y = size.height * (1 - v)
            if (i == 0) p.lineTo(x, y)
            else {
                val px = (i - 1) * dx; val py = size.height * (1 - bins[i - 1])
                p.cubicTo((px + x) / 2, py, (px + x) / 2, y, x, y)
            }
        }
        p.lineTo(size.width, size.height); p.close()
        drawPath(p, Brush.verticalGradient(listOf(Color(0x8800E5FF), Color.Transparent)))
        for (g in 1..3) drawLine(Color(0x22FFFFFF), Offset(0f, size.height * g / 4), Offset(size.width, size.height * g / 4))
    }
}

@Composable
fun Knob(label: String, value: Float, onChange: (Float) -> Unit) {
    val v by rememberUpdatedState(value)
    val cb by rememberUpdatedState(onChange)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.size(72.dp).pointerInput(Unit) {
            detectDragGestures { _, d -> cb((v - d.y / 250f).coerceIn(0f, 1f)) }
        }) {
            val s = Stroke(6.dp.toPx(), cap = StrokeCap.Round)
            drawArc(Color(0xFF222222), 135f, 270f, false, style = s)
            drawArc(Color(0xFF00E5FF), 135f, 270f * v, false, style = s)
        }
        Text(label, color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun EqStrip() {
    val gains = remember { mutableStateListOf<Float>().apply { repeat(32) { add(0f) } } }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items(32) { i ->
            val f = 20f * Math.pow(1000.0, i / 31.0).toFloat()
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Canvas(Modifier.width(24.dp).height(160.dp).pointerInput(i) {
                    detectDragGestures { c, _ ->
                        val g = (1f - c.position.y / size.height) * 48f - 24f
                        gains[i] = g.coerceIn(-24f, 24f)
                        NativeDsp.setBand(i, 0, f, gains[i], 4.3f, false)
                    }
                }) {
                    drawRoundRect(Color(0xFF1A1A1A), cornerRadius = CornerRadius(8f))
                    val y = size.height * (1 - (gains[i] + 24f) / 48f)
                    drawCircle(Color(0xFF00E5FF), 8.dp.toPx(), Offset(size.width / 2, y))
                }
                Text(if (f >= 1000) "%.1fk".format(f / 1000) else "${f.toInt()}", color = Color.Gray, fontSize = 8.sp)
            }
        }
    }
}
