package com.example.dsp

import android.os.SystemClock
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

// ───────────────────────── Design tokens (iOS dark) ─────────────────────────
object C {
    val bg = Color(0xFF000000)
    val card = Color(0xFF1C1C1E)
    val card2 = Color(0xFF2C2C2E)
    val card3 = Color(0xFF48484A)
    val well = Color(0xFF0C0C0E)
    val sep = Color(0xFF38383A)
    val grid = Color(0xFF232325)
    val label = Color(0xFFFFFFFF)
    val label2 = Color(0x99EBEBF5)
    val label3 = Color(0x4DEBEBF5)
    val blue = Color(0xFF0A84FF)
    val teal = Color(0xFF64D2FF)
    val pink = Color(0xFFFF375F)
    val orange = Color(0xFFFF9F0A)
    val green = Color(0xFF30D158)
}

class Actions(
    val listener: () -> Unit,
    val startCapture: () -> Unit,
    val stopCapture: () -> Unit,
    val startShizuku: () -> Unit,
    val stopShizuku: () -> Unit
)

/** Live readings from the native engine, polled once per frame. */
object Live {
    val bins = FloatArray(96)
    val st = FloatArray(16)
    val inHist = FloatArray(200)
    val subHist = FloatArray(200)
    var tick by mutableLongStateOf(0L)
    var zoom = true
    private var frame = 0

    fun poll(now: Long) {
        if (zoom) NativeDsp.spectrum(bins, 20f, 200f) else NativeDsp.spectrum(bins, 20f, 20000f)
        NativeDsp.status(st)
        frame++
        if (frame % 3 == 0) {
            System.arraycopy(inHist, 1, inHist, 0, 199); inHist[199] = st[4]
            System.arraycopy(subHist, 1, subHist, 0, 199); subHist[199] = st[5]
        }
        tick = now
    }
}

// ───────────────────────── Primitives ─────────────────────────
@Composable
fun T(
    s: String, size: Int = 14, color: Color = C.label, weight: FontWeight = FontWeight.Normal,
    mono: Boolean = false, modifier: Modifier = Modifier, spacing: Float = 0f, maxLines: Int = 1
) {
    Text(
        s, modifier = modifier, maxLines = maxLines, overflow = TextOverflow.Ellipsis,
        style = TextStyle(
            color = color, fontSize = size.sp, fontWeight = weight, letterSpacing = spacing.sp,
            fontFeatureSettings = if (mono) "tnum" else null
        )
    )
}

@Composable
fun Gap(h: Int) { Spacer(Modifier.height(h.dp)) }

@Composable
fun Label(s: String) { T(s, 11, C.label2, FontWeight.SemiBold, spacing = 1f) }

@Composable
fun Modifier.tap(onClick: () -> Unit): Modifier =
    this.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)

/** Tap with an iOS-style springy press-down scale. */
@Composable
fun Modifier.press(onClick: () -> Unit): Modifier {
    var down by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (down) 0.95f else 1f, spring(dampingRatio = 0.55f, stiffness = 600f))
    val cb by rememberUpdatedState(onClick)
    return this.graphicsLayer { scaleX = sc; scaleY = sc }.pointerInput(Unit) {
        detectTapGestures(onPress = { down = true; tryAwaitRelease(); down = false }, onTap = { cb() })
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, pad: Int = 16, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Column(
        modifier.fillMaxWidth().clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF212124), Color(0xFF19191B))))
            .border(0.5.dp, Brush.verticalGradient(listOf(Color(0x40FFFFFF), Color(0x0FFFFFFF))), shape)
            .padding(pad.dp),
        content = content
    )
}

@Composable
fun Group(content: @Composable ColumnScope.() -> Unit) { GlassCard(pad = 0, content = content) }

@Composable
fun ListRow(title: String, subtitle: String? = null, last: Boolean = false, trailing: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            T(title, 16, C.label)
            if (subtitle != null) T(subtitle, 12, C.label2, maxLines = 3)
        }
        Spacer(Modifier.width(12.dp))
        trailing()
    }
    if (!last) Box(Modifier.padding(start = 16.dp).fillMaxWidth().height(0.5.dp).background(C.sep))
}

@Composable
fun IOSSwitch(on: Boolean, onChange: (Boolean) -> Unit) {
    val haptic = LocalHapticFeedback.current
    val track by animateColorAsState(if (on) C.green else Color(0xFF39393D))
    val x by animateDpAsState(if (on) 20.dp else 0.dp, spring(dampingRatio = 0.7f, stiffness = 600f))
    Box(
        Modifier.width(51.dp).height(31.dp).clip(RoundedCornerShape(50)).background(track)
            .tap { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onChange(!on) }.padding(2.dp)
    ) {
        Box(Modifier.offset(x = x).size(27.dp).shadow(3.dp, CircleShape).background(Color.White, CircleShape))
    }
}

/** iOS segmented control with a sliding thumb. */
@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val haptic = LocalHapticFeedback.current
    BoxWithConstraints(modifier.clip(RoundedCornerShape(12.dp)).background(C.well).padding(2.dp)) {
        val segW = maxWidth / options.size
        val x by animateDpAsState(segW * selected, spring(dampingRatio = 0.8f, stiffness = 500f))
        Box(
            Modifier.offset(x = x).width(segW).height(34.dp).shadow(1.dp, RoundedCornerShape(10.dp))
                .clip(RoundedCornerShape(10.dp)).background(C.card3)
        )
        Row(Modifier.fillMaxWidth()) {
            options.forEachIndexed { i, o ->
                Box(
                    Modifier.weight(1f).height(34.dp)
                        .press { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onSelect(i) },
                    contentAlignment = Alignment.Center
                ) { T(o, 12, if (i == selected) C.label else C.label2, if (i == selected) FontWeight.SemiBold else FontWeight.Medium) }
            }
        }
    }
}

@Composable
fun Chip(text: String, on: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (on) C.blue else C.card2)
    Box(Modifier.clip(RoundedCornerShape(50)).background(bg).press(onClick).padding(horizontal = 14.dp, vertical = 8.dp)) {
        T(text, 12, if (on) Color.White else C.label2, FontWeight.SemiBold)
    }
}

@Composable
fun Pill(text: String, onClick: () -> Unit) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(C.card2).press(onClick).padding(horizontal = 16.dp, vertical = 9.dp)) {
        T(text, 12, C.blue, FontWeight.SemiBold)
    }
}

@Composable
fun Stepper(onMinus: () -> Unit, onPlus: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    Row(Modifier.clip(RoundedCornerShape(12.dp)).background(C.card2)) {
        Box(Modifier.size(width = 52.dp, height = 36.dp).press { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onMinus() }, contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(14.dp)) { drawLine(C.label, Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 2.dp.toPx(), cap = StrokeCap.Round) }
        }
        Box(Modifier.width(0.5.dp).height(36.dp).background(C.sep))
        Box(Modifier.size(width = 52.dp, height = 36.dp).press { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onPlus() }, contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(14.dp)) {
                drawLine(C.label, Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 2.dp.toPx(), cap = StrokeCap.Round)
                drawLine(C.label, Offset(size.width / 2, 0f), Offset(size.width / 2, size.height), 2.dp.toPx(), cap = StrokeCap.Round)
            }
        }
    }
}

@Composable
fun Knob(
    label: String, value: Float, lo: Float, hi: Float, def: Float, accent: Color,
    fmt: (Float) -> String, unit: String, onChange: (Float) -> Unit
) {
    val v by rememberUpdatedState(value)
    val cb by rememberUpdatedState(onChange)
    val norm = ((value - lo) / (hi - lo)).coerceIn(0f, 1f)
    val anim by animateFloatAsState(norm, spring(dampingRatio = 0.9f, stiffness = 400f))
    val haptic = LocalHapticFeedback.current
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(76.dp)) {
        Box(
            Modifier.size(68.dp)
                .pointerInput(Unit) {
                    detectTapGestures(onDoubleTap = {
                        cb(def); haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    })
                }
                .pointerInput(Unit) {
                    detectDragGestures { _, d -> cb((v - d.y * (hi - lo) / 220f).coerceIn(lo, hi)) }
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = 4.dp.toPx()
                val tl = Offset(stroke / 2, stroke / 2)
                val sz = Size(size.width - stroke, size.height - stroke)
                drawArc(C.card2, 135f, 270f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
                drawArc(accent.copy(alpha = 0.25f), 135f, 270f * anim, false, tl, sz, style = Stroke(stroke * 2.2f, cap = StrokeCap.Round))
                drawArc(accent, 135f, 270f * anim, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                T(fmt(value), 14, C.label, FontWeight.SemiBold, true)
                T(unit, 9, C.label2)
            }
        }
        Gap(6)
        T(label, 10, C.label2, FontWeight.Medium, spacing = 0.6f)
    }
}

@Composable
fun HSlider(norm: Float, accent: Color, onNorm: (Float) -> Unit, modifier: Modifier = Modifier) {
    val cb by rememberUpdatedState(onNorm)
    Canvas(
        modifier.height(30.dp).pointerInput(Unit) {
            detectDragGestures(onDragStart = { o -> cb((o.x / size.width).coerceIn(0f, 1f)) }) { c, _ ->
                cb((c.position.x / size.width).coerceIn(0f, 1f))
            }
        }
    ) {
        val cy = size.height / 2
        val x = size.width * norm.coerceIn(0f, 1f)
        drawRoundRect(C.card2, Offset(0f, cy - 2.dp.toPx()), Size(size.width, 4.dp.toPx()), CornerRadius(2.dp.toPx()))
        drawRoundRect(accent, Offset(0f, cy - 2.dp.toPx()), Size(x, 4.dp.toPx()), CornerRadius(2.dp.toPx()))
        drawCircle(Color(0x33000000), 12.dp.toPx(), Offset(x, cy + 1.dp.toPx()))
        drawCircle(Color.White, 10.dp.toPx(), Offset(x, cy))
    }
}

@Composable
fun Glyph(kind: Int, tint: Color, sz: Dp) {
    Canvas(Modifier.size(sz)) {
        val w = size.width
        val h = size.height
        when (kind) {
            0 -> {
                val p = Path(); p.moveTo(w * 0.24f, h * 0.12f); p.lineTo(w * 0.88f, h * 0.5f); p.lineTo(w * 0.24f, h * 0.88f); p.close()
                drawPath(p, tint)
            }
            1 -> {
                drawRoundRect(tint, Offset(w * 0.18f, h * 0.12f), Size(w * 0.24f, h * 0.76f), CornerRadius(w * 0.06f))
                drawRoundRect(tint, Offset(w * 0.58f, h * 0.12f), Size(w * 0.24f, h * 0.76f), CornerRadius(w * 0.06f))
            }
            2 -> {
                val p = Path(); p.moveTo(w * 0.12f, h * 0.18f); p.lineTo(w * 0.68f, h * 0.5f); p.lineTo(w * 0.12f, h * 0.82f); p.close()
                drawPath(p, tint)
                drawRoundRect(tint, Offset(w * 0.74f, h * 0.18f), Size(w * 0.14f, h * 0.64f), CornerRadius(w * 0.04f))
            }
            else -> {
                val p = Path(); p.moveTo(w * 0.88f, h * 0.18f); p.lineTo(w * 0.32f, h * 0.5f); p.lineTo(w * 0.88f, h * 0.82f); p.close()
                drawPath(p, tint)
                drawRoundRect(tint, Offset(w * 0.12f, h * 0.18f), Size(w * 0.14f, h * 0.64f), CornerRadius(w * 0.04f))
            }
        }
    }
}

@Composable
fun StatusLine(hooked: String?) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(if (hooked != null) C.green else C.label3))
        Spacer(Modifier.width(7.dp))
        T(hooked?.let { "Hooked · $it" } ?: "Waiting for playback", 13, C.label2)
    }
}

// ───────────────────────── Navigation ─────────────────────────
@Composable
fun TabIcon(kind: Int, tint: Color) {
    Canvas(Modifier.size(24.dp)) {
        val w = size.width
        val h = size.height
        val st = 2.dp.toPx()
        when (kind) {
            0 -> { // waveform
                val hs = floatArrayOf(0.35f, 0.7f, 1f, 0.55f, 0.3f)
                for (i in 0 until 5) {
                    val x = w * (0.1f + 0.2f * i)
                    drawLine(tint, Offset(x, h * (0.5f - hs[i] * 0.45f)), Offset(x, h * (0.5f + hs[i] * 0.45f)), st, cap = StrokeCap.Round)
                }
            }
            1 -> { // sliders
                for (i in 0 until 3) {
                    val x = w * (0.2f + 0.3f * i)
                    drawLine(tint, Offset(x, h * 0.08f), Offset(x, h * 0.92f), st, cap = StrokeCap.Round)
                    drawCircle(tint, 3.6.dp.toPx(), Offset(x, h * (0.3f + 0.2f * ((i * 2) % 3))))
                }
            }
            else -> { // source / broadcast
                drawCircle(tint, 2.6.dp.toPx(), Offset(w / 2, h / 2))
                drawArc(tint, -50f, 100f, false, Offset(w * 0.2f, h * 0.2f), Size(w * 0.6f, h * 0.6f), style = Stroke(st, cap = StrokeCap.Round))
                drawArc(tint, 130f, 100f, false, Offset(w * 0.2f, h * 0.2f), Size(w * 0.6f, h * 0.6f), style = Stroke(st, cap = StrokeCap.Round))
                drawArc(tint, -50f, 100f, false, Offset(0f, 0f), Size(w, h), style = Stroke(st, cap = StrokeCap.Round))
                drawArc(tint, 130f, 100f, false, Offset(0f, 0f), Size(w, h), style = Stroke(st, cap = StrokeCap.Round))
            }
        }
    }
}

@Composable
fun TabBar(tab: Int, onTab: (Int) -> Unit) {
    val haptic = LocalHapticFeedback.current
    val names = listOf("Sub", "EQ", "Source")
    val accents = listOf(C.pink, C.green, C.blue)
    val shape = RoundedCornerShape(32.dp)
    Row(
        Modifier.navigationBarsPadding().padding(horizontal = 24.dp, vertical = 10.dp).fillMaxWidth()
            .clip(shape).background(Color(0xF01C1C1E)).border(0.5.dp, Color(0x33FFFFFF), shape).padding(6.dp)
    ) {
        names.forEachIndexed { i, n ->
            val on = i == tab
            val bg by animateColorAsState(if (on) Color(0x26FFFFFF) else Color.Transparent)
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(26.dp)).background(bg)
                    .press { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onTab(i) }
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                TabIcon(i, if (on) accents[i] else C.label2)
                Gap(2)
                T(n, 10, if (on) C.label else C.label2, FontWeight.Medium)
            }
        }
    }
}

@Composable
fun Screen(
    title: String, trailing: @Composable () -> Unit, sub: @Composable () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T(title, 34, C.label, FontWeight.Bold, spacing = -0.5f)
                sub()
            }
            trailing()
        }
        content()
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun AppRoot(p: Params, a: Actions) {
    var tab by remember { mutableIntStateOf(0) }
    val glow by animateColorAsState(if (tab == 0) C.pink else if (tab == 1) C.green else C.blue)
    LaunchedEffect(Unit) { p.pushAll() }
    LaunchedEffect(tab) { Live.zoom = tab == 0 }
    LaunchedEffect(Unit) { while (true) { withFrameNanos { Live.poll(it) } } }
    Box(
        Modifier.fillMaxSize().background(C.bg).drawBehind {
            drawRect(
                Brush.radialGradient(
                    listOf(glow.copy(alpha = 0.22f), Color.Transparent),
                    center = Offset(size.width * 0.85f, 0f), radius = size.width * 0.95f
                )
            )
        }
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> SubScreen(p)
                    1 -> EqScreen(p)
                    else -> SourceScreen(p, a)
                }
            }
            TabBar(tab) { tab = it }
        }
    }
}
