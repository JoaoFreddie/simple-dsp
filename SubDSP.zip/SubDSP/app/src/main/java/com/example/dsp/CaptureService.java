package com.example.dsp;

import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.os.Build;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import java.io.OutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

/**
 * Runs with shell privileges (started by Shizuku). Captures the device's whole audio output
 * (REMOTE_SUBMIX, same technique as scrcpy). That also silences the original on the device,
 * so only the processed copy is heard. PCM goes back to the app through a pipe.
 */
public class CaptureService extends ICaptureService.Stub {
    private static final String TAG = "SubDSP-capture";
    private volatile boolean running = false;
    private AudioRecord rec;
    private volatile String err = "";
    private Context cachedCtx;

    public CaptureService() {}

    @Override public void destroy() { stop(); System.exit(0); }
    @Override public String lastError() { return err; }

    @Override public void stop() {
        running = false;
        try { if (rec != null) { rec.stop(); rec.release(); } } catch (Throwable ignored) {}
        rec = null;
    }

    /** Several ways to get a system Context in a bare app_process; the first that works wins. */
    private Context systemContext() throws Exception {
        if (cachedCtx != null) return cachedCtx;
        StringBuilder why = new StringBuilder();
        Class<?> atc = Class.forName("android.app.ActivityThread");
        // 1) already inside a process that has an ActivityThread
        try {
            Object at = atc.getMethod("currentActivityThread").invoke(null);
            if (at != null) { cachedCtx = (Context) atc.getMethod("getSystemContext").invoke(at); return cachedCtx; }
        } catch (Throwable t) { why.append("current: ").append(t).append('\n'); }
        // 2) scrcpy's way: build an ActivityThread by hand and install it as the current one
        try {
            if (Looper.getMainLooper() == null) {
                try { Looper.prepareMainLooper(); } catch (Throwable ignored) {}
            }
            Constructor<?> ctor = atc.getDeclaredConstructor();
            ctor.setAccessible(true);
            Object at = ctor.newInstance();
            Field cur = atc.getDeclaredField("sCurrentActivityThread");
            cur.setAccessible(true);
            cur.set(null, at);
            try {
                Field sys = atc.getDeclaredField("mSystemThread");
                sys.setAccessible(true);
                sys.setBoolean(at, true);
            } catch (Throwable ignored) {}
            Context sc = (Context) atc.getMethod("getSystemContext").invoke(at);
            try {
                Application app = Application.class.getDeclaredConstructor().newInstance();
                Field base = ContextWrapper.class.getDeclaredField("mBase");
                base.setAccessible(true);
                base.set(app, new FakeContext(sc));
                Field init = atc.getDeclaredField("mInitialApplication");
                init.setAccessible(true);
                init.set(at, app);
            } catch (Throwable t) { why.append("app: ").append(t).append('\n'); }
            cachedCtx = sc;
            return sc;
        } catch (Throwable t) { why.append("manual: ").append(t).append('\n'); }
        // 3) systemMain()
        try {
            if (Looper.getMainLooper() == null) {
                try { Looper.prepareMainLooper(); } catch (Throwable ignored) {}
            }
            Object at = atc.getMethod("systemMain").invoke(null);
            cachedCtx = (Context) atc.getMethod("getSystemContext").invoke(at);
            return cachedCtx;
        } catch (Throwable t) { why.append("systemMain: ").append(t).append('\n'); }
        throw new IllegalStateException("no system context\n" + why);
    }

    private AudioRecord build(Context ctx, int sr, int enc, int mask, int bytes) throws Exception {
        AudioFormat fmt = new AudioFormat.Builder().setEncoding(enc).setSampleRate(sr).setChannelMask(mask).build();
        int min = AudioRecord.getMinBufferSize(sr, mask, enc);
        AudioRecord.Builder b = new AudioRecord.Builder()
                .setAudioSource(8) // MediaRecorder.AudioSource.REMOTE_SUBMIX
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(Math.max(min, bytes) * 4);
        if (Build.VERSION.SDK_INT >= 31) {
            try { b.setContext(ctx); }
            catch (Throwable t) {
                try { AudioRecord.Builder.class.getMethod("setContext", Context.class).invoke(b, ctx); }
                catch (Throwable t2) { err += "setContext: " + t2 + "\n"; }
            }
        }
        return b.build();
    }

    @Override public ParcelFileDescriptor start(int sr) {
        stop();
        err = "";
        try {
            Context ctx = new FakeContext(systemContext());
            AudioRecord r = null;
            String lastFail = "";
            // try 16-bit stereo first (what the remote-submix HAL always supports), then other layouts
            int[][] tries = {
                    {AudioFormat.ENCODING_PCM_16BIT, AudioFormat.CHANNEL_IN_STEREO},
                    {AudioFormat.ENCODING_PCM_16BIT, AudioFormat.CHANNEL_IN_FRONT | AudioFormat.CHANNEL_IN_BACK},
            };
            for (int[] t : tries) {
                try {
                    AudioRecord c = build(ctx, sr, t[0], t[1], 1920);
                    if (c.getState() == AudioRecord.STATE_INITIALIZED) { r = c; break; }
                    lastFail += "format " + t[1] + " not initialized\n";
                    c.release();
                } catch (Throwable ex) { lastFail += "format " + t[1] + ": " + ex + "\n"; }
            }
            if (r == null) {
                err = "AudioRecord (REMOTE_SUBMIX) could not be created.\n" + err + lastFail;
                return null;
            }
            r.startRecording();
            if (r.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                err = "startRecording refused (state " + r.getRecordingState() + ")";
                r.release();
                return null;
            }
            final ParcelFileDescriptor[] pipe = ParcelFileDescriptor.createPipe();
            final AudioRecord rr = r;
            rec = rr;
            running = true;
            new Thread(() -> {
                OutputStream os = new ParcelFileDescriptor.AutoCloseOutputStream(pipe[1]);
                byte[] buf = new byte[1920];
                try {
                    while (running) {
                        int n = rr.read(buf, 0, buf.length);
                        if (n > 0) os.write(buf, 0, n);
                        else if (n < 0) { err = "read error " + n; break; }
                    }
                } catch (Throwable t) {
                    err = "pipe: " + t;
                } finally {
                    try { os.close(); } catch (Throwable ignored) {}
                }
            }, "sub-capture").start();
            return pipe[0];
        } catch (Throwable t) {
            String s = Log.getStackTraceString(t);
            err = s.length() > 900 ? s.substring(0, 900) : s;
            return null;
        }
    }
}
