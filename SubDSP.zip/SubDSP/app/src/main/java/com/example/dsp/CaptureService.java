package com.example.dsp;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.os.Build;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import java.io.OutputStream;

/**
 * Runs with shell privileges (started by Shizuku). Captures the device's whole audio output
 * (REMOTE_SUBMIX, same technique as scrcpy). That also silences the original on the device,
 * so only the processed copy is heard. PCM goes back to the app through a pipe.
 */
public class CaptureService extends ICaptureService.Stub {
    private volatile boolean running = false;
    private AudioRecord rec;
    private String err = "";

    public CaptureService() {}

    @Override public void destroy() { stop(); System.exit(0); }
    @Override public String lastError() { return err; }

    @Override public void stop() {
        running = false;
        try { if (rec != null) { rec.stop(); rec.release(); } } catch (Throwable ignored) {}
        rec = null;
    }

    private static Context systemContext() throws Exception {
        Class<?> c = Class.forName("android.app.ActivityThread");
        Object at = c.getMethod("currentActivityThread").invoke(null);
        if (at == null) {
            if (Looper.getMainLooper() == null) Looper.prepareMainLooper();
            at = c.getMethod("systemMain").invoke(null);
        }
        return (Context) c.getMethod("getSystemContext").invoke(at);
    }

    @Override public ParcelFileDescriptor start(int sr) {
        stop();
        err = "";
        try {
            Context ctx = new FakeContext(systemContext());
            AudioFormat fmt = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build();
            int min = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
            AudioRecord.Builder b = new AudioRecord.Builder()
                    .setAudioSource(8) // MediaRecorder.AudioSource.REMOTE_SUBMIX
                    .setAudioFormat(fmt)
                    .setBufferSizeInBytes(Math.max(min, 1920) * 4);
            if (Build.VERSION.SDK_INT >= 31) {
                try {
                    AudioRecord.Builder.class.getMethod("setContext", Context.class).invoke(b, ctx);
                } catch (Throwable t) { err = "setContext: " + t; }
            }
            final AudioRecord r = b.build();
            if (r.getState() != AudioRecord.STATE_INITIALIZED) {
                err = "AudioRecord not initialized. " + err;
                r.release();
                return null;
            }
            r.startRecording();
            final ParcelFileDescriptor[] pipe = ParcelFileDescriptor.createPipe();
            rec = r;
            running = true;
            new Thread(() -> {
                OutputStream os = new ParcelFileDescriptor.AutoCloseOutputStream(pipe[1]);
                byte[] buf = new byte[1920];
                try {
                    while (running) {
                        int n = r.read(buf, 0, buf.length);
                        if (n > 0) os.write(buf, 0, n);
                        else if (n < 0) { err = "read error " + n; break; }
                    }
                } catch (Throwable t) {
                    err = "pipe: " + t;
                } finally {
                    try { os.close(); } catch (Throwable ignored) {}
                }
            }, "sub-capture").start();
            return pipe[0];
        } catch (Throwable t) {
            String s = Log.getStackTraceString(t);
            err = s.length() > 700 ? s.substring(0, 700) : s;
            return null;
        }
    }
}
