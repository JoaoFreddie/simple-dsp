package com.example.dsp

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.os.Process
import rikka.shizuku.Shizuku

/** "Shizuku" source: a privileged helper captures ALL device audio (even apps that block capture)
 *  and mutes the original, so only the processed signal is heard. */
object ShizukuBridge {
    private var svc: ICaptureService? = null
    private var appCtx: Context? = null
    @Volatile private var running = false

    private fun args(ctx: Context) =
        Shizuku.UserServiceArgs(ComponentName(ctx.packageName, CaptureService::class.java.name))
            .daemon(false).processNameSuffix("capture").debuggable(false).version(1)

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val s = ICaptureService.Stub.asInterface(binder)
            svc = s
            val ctx = appCtx ?: return
            val dev = pickOutputDevice(ctx)
            if (!NativeDsp.start(48000, dev)) { DspState.note.value = "Audio engine failed to start"; return }
            val pfd: ParcelFileDescriptor? = try { s.start(48000) } catch (e: Throwable) { null }
            if (pfd == null) {
                val why = try { s.lastError() } catch (e: Throwable) { "" }
                DspState.note.value = "Capture failed: $why"
                NativeDsp.stop()
                return
            }
            running = true
            DspState.capturing.value = true
            DspState.note.value = "Shizuku capture running (output device $dev)"
            Thread {
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
                val input = ParcelFileDescriptor.AutoCloseInputStream(pfd)
                val bytes = ByteArray(1920)
                val floats = FloatArray(960)
                try {
                    while (running) {
                        var off = 0
                        while (off < bytes.size) {
                            val r = input.read(bytes, off, bytes.size - off)
                            if (r < 0) { running = false; break }
                            off += r
                        }
                        if (!running) break
                        for (i in 0 until 960) {
                            val lo = bytes[2 * i].toInt() and 0xFF
                            val hi = bytes[2 * i + 1].toInt()
                            floats[i] = ((hi shl 8) or lo).toShort() / 32768f
                        }
                        NativeDsp.push(floats, 960)
                    }
                } catch (e: Exception) { }
                running = false
                DspState.capturing.value = false
                try { input.close() } catch (e: Exception) { }
            }.start()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null
            running = false
            DspState.capturing.value = false
            DspState.note.value = "Shizuku service disconnected"
        }
    }

    fun bind(ctx: Context) {
        appCtx = ctx.applicationContext
        DspState.note.value = "Connecting to Shizuku…"
        try { Shizuku.bindUserService(args(appCtx!!), conn) }
        catch (e: Throwable) { DspState.note.value = "Bind failed: ${e.message}" }
    }

    fun stop() {
        running = false
        try { svc?.stop() } catch (e: Throwable) { }
        NativeDsp.stop()
        val ctx = appCtx
        if (ctx != null) { try { Shizuku.unbindUserService(args(ctx), conn, true) } catch (e: Throwable) { } }
        svc = null
        DspState.capturing.value = false
        DspState.note.value = ""
    }
}
