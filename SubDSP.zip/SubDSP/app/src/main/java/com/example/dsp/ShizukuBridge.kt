package com.example.dsp

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.os.Process
import rikka.shizuku.Shizuku

/** "Shizuku" source: a privileged helper captures ALL device audio (even apps that block capture)
 *  and mutes the original, so only the processed signal is heard. */
object ShizukuBridge {
    private var svc: ICaptureService? = null
    private var appCtx: Context? = null
    @Volatile private var running = false
    @Volatile private var generation = 0
    private var bound = false

    private fun args(ctx: Context) =
        Shizuku.UserServiceArgs(ComponentName(ctx.packageName, CaptureService::class.java.name))
            .daemon(false).processNameSuffix("capture").debuggable(false).version(2)

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder == null || !binder.pingBinder()) { DspState.note.value = "Shizuku service returned no binder"; return }
            val s = ICaptureService.Stub.asInterface(binder)
            svc = s
            val ctx = appCtx ?: return
            val gen = ++generation
            // Everything below blocks (audio engine, privileged AudioRecord): never on the main thread.
            Thread {
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
                val dev = pickOutputDevice(ctx)
                if (!NativeDsp.start(48000, dev, 30)) {
                    DspState.note.value = "Audio engine failed to start (output device $dev)"; return@Thread
                }
                val pfd: ParcelFileDescriptor? = try { s.start(48000) } catch (e: Throwable) { DspState.note.value = "Helper call failed: ${e.message}"; null }
                if (pfd == null) {
                    val why = try { s.lastError() } catch (e: Throwable) { "" }
                    if (DspState.note.value.isEmpty() || DspState.note.value.startsWith("Connecting")) DspState.note.value = "Capture failed:\n$why"
                    NativeDsp.stop()
                    return@Thread
                }
                running = true
                DspState.capturing.value = true
                DspState.note.value = "Shizuku capture running (output device $dev). If you still hear the original, your phone's audio HAL does not mute it."
                val input = ParcelFileDescriptor.AutoCloseInputStream(pfd)
                val bytes = ByteArray(1920)
                val floats = FloatArray(960)
                try {
                    while (running && gen == generation) {
                        var off = 0
                        while (off < bytes.size) {
                            val r = input.read(bytes, off, bytes.size - off)
                            if (r < 0) { running = false; break }
                            off += r
                        }
                        if (!running) break
                        for (i in 0 until 960) {
                            val lo = bytes[2 * i].toInt() and 0xFF
                            val hi = bytes[2 * i + 1].toInt()
                            floats[i] = ((hi shl 8) or lo).toShort() / 32768f
                        }
                        NativeDsp.push(floats, 960)
                    }
                } catch (e: Exception) { }
                if (gen == generation) {
                    running = false
                    DspState.capturing.value = false
                    val why = try { svc?.lastError() ?: "" } catch (e: Throwable) { "" }
                    if (why.isNotEmpty()) DspState.note.value = "Capture ended: $why"
                }
                try { input.close() } catch (e: Exception) { }
            }.start()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null
            running = false
            DspState.capturing.value = false
            DspState.note.value = "Shizuku service disconnected"
        }
    }

    fun bind(ctx: Context) {
        appCtx = ctx.applicationContext
        if (bound) stop()
        DspState.note.value = "Connecting to Shizuku…"
        try {
            Shizuku.bindUserService(args(appCtx!!), conn)
            bound = true
        } catch (e: Throwable) { DspState.note.value = "Bind failed: ${e.message}" }
    }

    fun stop() {
        generation++
        running = false
        try { svc?.stop() } catch (e: Throwable) { }
        NativeDsp.stop()
        val ctx = appCtx
        if (ctx != null && bound) { try { Shizuku.unbindUserService(args(ctx), conn, true) } catch (e: Throwable) { } }
        bound = false
        svc = null
        DspState.capturing.value = false
        DspState.note.value = ""
    }
}
