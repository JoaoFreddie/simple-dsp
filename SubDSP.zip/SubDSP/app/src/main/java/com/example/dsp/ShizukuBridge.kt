package com.example.dsp

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.Process
import rikka.shizuku.Shizuku

/**
 * "Shizuku" source: a privileged helper captures ALL device audio (even apps that block capture) and mutes the
 * original, so only the processed signal is heard.
 *
 * The helper is started the way scrcpy starts its server: Shizuku runs `app_process ... CaptureMain` as a shell
 * command and we read PCM from its stdout and its error text from stderr. If that is unavailable we fall back to
 * Shizuku's "user service" mechanism. Every step reports to the Status card.
 *
 * It also finds the audio sessions of players that never announce them (via `dumpsys audio`) so the system EQ can
 * attach to them in Effects / Capture mode.
 */
object ShizukuBridge {
    private var svc: ICaptureService? = null
    private var appCtx: Context? = null
    private var proc: java.lang.Process? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var generation = 0
    @Volatile private var step = ""
    private var bound = false

    private fun say(s: String) { step = s; DspState.note.value = s }

    // ---------------------------------------------------------------- helper process (primary path)

    private fun newProcess(cmd: Array<String>): java.lang.Process {
        // Shizuku 13 keeps newProcess private; it still works and is what scrcpy-style helpers need.
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        try { return m.invoke(null, cmd, null, null) as java.lang.Process }
        catch (e: java.lang.reflect.InvocationTargetException) { throw e.targetException ?: e }
    }

    fun bind(ctx: Context) {
        appCtx = ctx.applicationContext
        stop()
        val gen = ++generation
        say("0/3 Launching capture helper through Shizuku…")
        val apk = appCtx!!.applicationInfo.sourceDir
        val line = "CLASSPATH='$apk' exec app_process /system/bin --nice-name=subdsp_capture com.example.dsp.CaptureMain 48000"
        val p = try { newProcess(arrayOf("sh", "-c", line)) }
        catch (e: Throwable) {
            say("Shell launch unavailable (${e.javaClass.simpleName}: ${e.message}). Trying Shizuku user service…")
            bindUserService(appCtx!!, gen)
            return
        }
        proc = p
        main.postDelayed({
            if (gen == generation && !running)
                DspState.note.value = "Still waiting after 12 s. Last: $step\nTry: stop Shizuku, start it again, Connect."
        }, 12000)
        Thread { runProcess(p, gen, appCtx!!) }.also { it.name = "sub-shizuku"; it.start() }
    }

    private fun runProcess(p: java.lang.Process, gen: Int, ctx: Context) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val err = StringBuilder()
        val errThread = Thread {
            try {
                p.errorStream.bufferedReader().forEachLine { l ->
                    synchronized(err) { if (err.length < 2500) err.append(l).append('\n') }
                    if (gen == generation && !running) DspState.note.value = "Helper: $l"
                }
            } catch (e: Exception) { }
        }.also { it.isDaemon = true; it.start() }
        fun errText(): String { try { errThread.join(500) } catch (e: Exception) { }; return synchronized(err) { err.toString() } }

        val input = p.inputStream
        val bytes = ByteArray(1920)
        val floats = FloatArray(960)
        fun readFull(): Boolean {
            var off = 0
            while (off < bytes.size) {
                val r = input.read(bytes, off, bytes.size - off)
                if (r < 0) return false
                off += r
            }
            return true
        }
        try {
            if (!readFull()) {            // helper died before capturing: show why
                if (gen == generation) say("Helper exited before capturing.\n" + errText().ifBlank { "(no message: is Shizuku allowed to run shell commands?)" })
                return
            }
            if (gen != generation) return
            say("2/3 Capture is live. Starting audio engine…")
            val dev = pickOutputDevice(ctx)
            if (!NativeDsp.start(48000, dev, 30)) {
                say("Audio engine failed to start (output device $dev)")
                p.destroy(); return
            }
            running = true
            DspState.capturing.value = true
            say("Running via Shizuku (output device $dev). If you still hear the original, this phone's audio system does not mute it.")
            while (running && gen == generation) {
                for (i in 0 until 960) {
                    val lo = bytes[2 * i].toInt() and 0xFF
                    val hi = bytes[2 * i + 1].toInt()
                    floats[i] = ((hi shl 8) or lo).toShort() / 32768f
                }
                NativeDsp.push(floats, 960)
                if (!readFull()) break
            }
        } catch (e: Exception) { }
        if (gen == generation) {
            running = false
            DspState.capturing.value = false
            DspState.note.value = "Capture ended.\n" + errText()
        }
    }

    // ---------------------------------------------------------------- user-service fallback

    private fun helperVersion(ctx: Context): Int = try {
        ((ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime / 1000L) and 0x3FFFFFFF).toInt()
    } catch (e: Throwable) { 3 }

    private fun args(ctx: Context) =
        Shizuku.UserServiceArgs(ComponentName(ctx.packageName, CaptureService::class.java.name))
            .daemon(false).processNameSuffix("capture").debuggable(false).version(helperVersion(ctx))

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder == null || !binder.pingBinder()) { say("Shizuku gave back a dead helper binder"); return }
            val s = ICaptureService.Stub.asInterface(binder)
            svc = s
            val ctx = appCtx ?: return
            val gen = ++generation
            say("1/3 User-service helper connected. Starting capture…")
            Thread {
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
                val pfd: ParcelFileDescriptor? = try { s.start(48000) } catch (e: Throwable) { say("Helper call failed: ${e.message}"); null }
                if (pfd == null) {
                    val why = try { s.lastError() } catch (e: Throwable) { "" }
                    say("Capture refused by Android:\n$why")
                    return@Thread
                }
                val input = ParcelFileDescriptor.AutoCloseInputStream(pfd)
                val fake = object : java.lang.Process() {   // reuse the same pump as the shell path
                    override fun getOutputStream(): java.io.OutputStream = object : java.io.OutputStream() { override fun write(b: Int) {} }
                    override fun getInputStream() = input
                    override fun getErrorStream() = java.io.ByteArrayInputStream(ByteArray(0))
                    override fun waitFor() = 0
                    override fun exitValue() = 0
                    override fun destroy() { try { s.stop() } catch (e: Throwable) { } }
                }
                runProcess(fake, gen, ctx)
            }.start()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null
            running = false
            DspState.capturing.value = false
            DspState.note.value = "Shizuku helper process died (last step: $step)"
        }
    }

    private fun bindUserService(ctx: Context, gen: Int) {
        try {
            Shizuku.bindUserService(args(ctx), conn)
            bound = true
        } catch (e: Throwable) { say("Bind failed: ${e.javaClass.simpleName} ${e.message}"); return }
        main.postDelayed({
            if (gen == generation && svc == null)
                DspState.note.value = "Neither the shell launch nor Shizuku's user service could start the helper.\nSend me this text and the one above it."
        }, 8000)
    }

    fun stop() {
        generation++
        running = false
        try { proc?.destroy() } catch (e: Throwable) { }
        proc = null
        try { svc?.stop() } catch (e: Throwable) { }
        NativeDsp.stop()
        val ctx = appCtx
        if (ctx != null && bound) { try { Shizuku.unbindUserService(args(ctx), conn, true) } catch (e: Throwable) { } }
        bound = false
        svc = null
        DspState.capturing.value = false
        DspState.note.value = ""
    }

    // ---------------------------------------------------------------- audio session finder

    private var scanThread: Thread? = null
    private val scanned = HashSet<Int>()
    private var lastScanInfo = ""

    /** Every 3 s (Effects / Capture mode, Shizuku allowed): ask the system which audio sessions are playing and
     *  attach the EQ to them, for players that do not announce their session themselves. */
    fun startScan(ctx: Context) {
        if (scanThread != null) return
        if (appCtx == null) appCtx = ctx.applicationContext
        scanThread = Thread {
            while (true) {
                try { Thread.sleep(3000) } catch (e: InterruptedException) { return@Thread }
                try { scanOnce() } catch (e: Throwable) { info("scan error: ${e.javaClass.simpleName} ${e.message}") }
            }
        }.also { it.isDaemon = true; it.name = "sub-scan"; it.start() }
    }

    private fun info(s: String) { if (s != lastScanInfo) { lastScanInfo = s; SessionFx.note(s) } }

    private fun scanOnce() {
        if (DspState.mode.value == 2) return
        val ok = try { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }
        if (!ok) return
        val p = newProcess(arrayOf("dumpsys", "audio"))
        val text = p.inputStream.bufferedReader().use { it.readText() }
        try { p.destroy() } catch (e: Throwable) { }
        val uidRe = Regex("""u/pid:(\d+)/\d+""")
        val sessRe = Regex("""session(?:Id)?\s*[:=]\s*(\d+)""", RegexOption.IGNORE_CASE)
        val lines = text.lineSequence().filter { it.contains("AudioPlaybackConfiguration") }.toList()
        val ids = HashSet<Int>()
        var sample = ""
        for (l in lines) {
            val uid = uidRe.find(l)?.groupValues?.get(1)?.toIntOrNull()
            val sid = sessRe.find(l)?.groupValues?.get(1)?.toIntOrNull()
            if (uid == null || sid == null) { if (sample.isEmpty()) sample = l.trim().take(220); continue }
            if (uid == Process.myUid() || sid <= 0) continue
            ids.add(sid)
        }
        for (sid in ids) if (!SessionFx.has(sid)) SessionFx.attach(sid, "found via Shizuku")
        for (sid in scanned.toList()) if (sid !in ids) { SessionFx.release(sid); scanned.remove(sid) }
        scanned.addAll(ids)
        info(
            if (lines.isEmpty()) "scan: no player entries in dumpsys (${text.length} chars)"
            else if (ids.isEmpty() && sample.isNotEmpty()) "scan: ${lines.size} players but could not read session. Sample: $sample"
            else "scan: ${lines.size} player(s), sessions ${ids.sorted()}"
        )
    }
}
