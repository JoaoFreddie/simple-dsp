package com.example.dsp

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.Process
import rikka.shizuku.Shizuku

/** "Shizuku" source: a privileged helper captures ALL device audio (even apps that block capture)
 *  and mutes the original, so only the processed signal is heard.
 *  Every step reports to the Status card so a failure shows exactly where it stopped. */
object ShizukuBridge {
    private var svc: ICaptureService? = null
    private var appCtx: Context? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var generation = 0
    @Volatile private var step = ""
    private var bound = false

    private fun say(s: String) { step = s; DspState.note.value = s }

    /** Changes with every install, so Shizuku never reuses an old helper process left over from a previous build. */
    private fun helperVersion(ctx: Context): Int = try {
        ((ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime / 1000L) and 0x3FFFFFFF).toInt()
    } catch (e: Throwable) { 3 }

    private fun args(ctx: Context) =
        Shizuku.UserServiceArgs(ComponentName(ctx.packageName, CaptureService::class.java.name))
            .daemon(false).processNameSuffix("capture").debuggable(false).version(helperVersion(ctx))

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder == null || !binder.pingBinder()) { say("Shizuku gave back a dead helper binder"); return }
            val s = ICaptureService.Stub.asInterface(binder)
            svc = s
            val ctx = appCtx ?: return
            val gen = ++generation
            say("1/4 Helper process connected. Starting capture…")
            // watchdog: if a step blocks, say which one
            main.postDelayed({
                if (gen == generation && !running) DspState.note.value =
                    "Stuck at: $step\n(no answer for 12 s). Try: stop Shizuku and start it again, then Connect."
            }, 12000)
            Thread {
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
                val pfd: ParcelFileDescriptor? = try { s.start(48000) } catch (e: Throwable) { say("Helper call failed: ${e.message}"); null }
                if (pfd == null) {
                    val why = try { s.lastError() } catch (e: Throwable) { "" }
                    if (!step.startsWith("Helper call failed")) say("Capture refused by Android:\n$why")
                    return@Thread
                }
                say("2/4 Capture started. Starting audio engine…")
                val dev = pickOutputDevice(ctx)
                if (!NativeDsp.start(48000, dev, 30)) {
                    say("Audio engine failed to start (output device $dev)")
                    try { s.stop() } catch (e: Throwable) { }
                    return@Thread
                }
                running = true
                DspState.capturing.value = true
                say("Running via Shizuku (output device $dev). If you still hear the original, this phone's audio system does not mute it.")
                val input = ParcelFileDescriptor.AutoCloseInputStream(pfd)
                val bytes = ByteArray(1920)
                val floats = FloatArray(960)
                try {
                    while (running && gen == generation) {
                        var off = 0
                        while (off < bytes.size) {
                            val r = input.read(bytes, off, bytes.size - off)
                            if (r < 0) { running = false; break }
                            off += r
                        }
                        if (!running) break
                        for (i in 0 until 960) {
                            val lo = bytes[2 * i].toInt() and 0xFF
                            val hi = bytes[2 * i + 1].toInt()
                            floats[i] = ((hi shl 8) or lo).toShort() / 32768f
                        }
                        NativeDsp.push(floats, 960)
                    }
                } catch (e: Exception) { }
                if (gen == generation) {
                    running = false
                    DspState.capturing.value = false
                    val why = try { svc?.lastError() ?: "" } catch (e: Throwable) { "" }
                    DspState.note.value = "Capture ended. $why"
                }
                try { input.close() } catch (e: Exception) { }
            }.start()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null
            running = false
            DspState.capturing.value = false
            DspState.note.value = "Shizuku helper process died (last step: $step)"
        }
    }

    fun bind(ctx: Context) {
        appCtx = ctx.applicationContext
        if (bound) stop()
        val gen = ++generation
        say("0/4 Asking Shizuku to start the helper…")
        try {
            Shizuku.bindUserService(args(appCtx!!), conn)
            bound = true
        } catch (e: Throwable) { say("Bind failed: ${e.javaClass.simpleName} ${e.message}"); return }
        main.postDelayed({
            if (gen == generation && svc == null) {
                val v = try { Shizuku.getVersion() } catch (e: Throwable) { -1 }
                val u = try { Shizuku.getUid() } catch (e: Throwable) { -1 }
                DspState.note.value = "Shizuku never started the helper process (8 s).\n" +
                    "Shizuku API v$v, server uid $u.\nTry: stop Shizuku, start it again, then Connect. If it repeats, send me this text."
            }
        }, 8000)
    }

    fun stop() {
        generation++
        running = false
        try { svc?.stop() } catch (e: Throwable) { }
        NativeDsp.stop()
        val ctx = appCtx
        if (ctx != null && bound) { try { Shizuku.unbindUserService(args(ctx), conn, true) } catch (e: Throwable) { } }
        bound = false
        svc = null
        DspState.capturing.value = false
        DspState.note.value = ""
    }
}
