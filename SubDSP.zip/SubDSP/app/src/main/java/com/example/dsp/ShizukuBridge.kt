package com.example.dsp

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.Process
import rikka.shizuku.Shizuku

/**
 * "Shizuku" source: a privileged helper captures ALL device audio (even apps that block capture) and mutes the
 * original, so only the processed signal is heard.
 *
 * The helper is started the way scrcpy starts its server: Shizuku runs `app_process ... CaptureMain` as a shell
 * command and we read PCM from its stdout and its error text from stderr. If that is unavailable we fall back to
 * Shizuku's "user service" mechanism. Every step reports to the Status card.
 *
 * It also finds the audio sessions of players that never announce them (via `dumpsys audio`) so the system EQ can
 * attach to them in Effects / Capture mode.
 */
object ShizukuBridge {
    private var svc: ICaptureService? = null
    private var appCtx: Context? = null
    private var proc: java.lang.Process? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var generation = 0
    @Volatile private var step = ""
    private var bound = false
    @Volatile private var chosenDev = 0
    @Volatile private var diagText = ""
    @Volatile private var volText = ""
    private var prevVol = -1
    private var volChanged = false

    private fun say(s: String) { step = s; DspState.note.value = s }

    // ---------------------------------------------------------------- helper process (primary path)

    private fun newProcess(cmd: Array<String>): java.lang.Process {
        // Shizuku 13 keeps newProcess private; it still works and is what scrcpy-style helpers need.
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        try { return m.invoke(null, cmd, null, null) as java.lang.Process }
        catch (e: java.lang.reflect.InvocationTargetException) { throw e.targetException ?: e }
    }

    /** An old helper that never exited keeps the single capture slot, and the new one then hears silence. */
    private fun killHelpers() {
        try {
            val k = newProcess(arrayOf("sh", "-c",
                "pkill -f 'com.example.dsp.[C]aptureMain'; pkill -f 'com.example.dsp:[c]apture'; true"))
            try { k.inputStream.readBytes() } catch (e: Throwable) { }
            k.waitFor()
            Thread.sleep(300)
        } catch (e: Throwable) { }
    }


    /** What the playing app's stream looks like to Android (type, flags, device): explains why capture may not see it. */
    private fun playerDiag(): String = try {
        val p = newProcess(arrayOf("dumpsys", "audio"))
        val text = p.inputStream.bufferedReader().use { it.readText() }
        try { p.destroy() } catch (e: Throwable) { }
        val pm = appCtx?.packageManager
        val out = ArrayList<String>()
        for (l in text.lineSequence()) {
            if (!l.contains("AudioPlaybackConfiguration") || !l.contains("state:started")) continue
            val uid = Regex("""u/pid:(\d+)""").find(l)?.groupValues?.get(1)?.toIntOrNull()
            if (uid == Process.myUid()) continue
            val pkg = (if (uid != null) try { pm?.getPackagesForUid(uid)?.firstOrNull() } catch (e: Throwable) { null } else null) ?: "?"
            val type = Regex("""type:(\S+)""").find(l)?.groupValues?.get(1) ?: "?"
            val flags = Regex("""flags=(0x[0-9a-fA-F]+)""").find(l)?.groupValues?.get(1) ?: "?"
            val dev = Regex("""deviceIds:\[([^\]]*)\]""").find(l)?.groupValues?.get(1) ?: "?"
            out.add("${pkg.substringAfterLast('.')}  type=${type.substringAfterLast('.')}  flags=$flags  device=[$dev]")
        }
        if (out.isEmpty()) "Android lists no playing app stream" else out.joinToString("\n")
    } catch (e: Throwable) { "diag failed: ${e.message}" }


    /** Android keeps a separate music volume per output device. While capture runs the volume keys change the
     *  capture device's volume, not the real speaker's. This shows each device's own index. */
    private fun volDiag(): String = try {
        val p = newProcess(arrayOf("dumpsys", "audio"))
        val text = p.inputStream.bufferedReader().use { it.readText() }
        try { p.destroy() } catch (e: Throwable) { }
        val lines = text.lineSequence().toList()
        val i = lines.indexOfFirst { it.trim().startsWith("- STREAM_MUSIC") }
        var max = ""
        var cur = ""
        if (i >= 0) for (k in i + 1 until minOf(i + 14, lines.size)) {
            val t = lines[k].trim()
            if (t.startsWith("Max:")) max = t.removePrefix("Max:").trim()
            if (t.startsWith("Current:")) cur = t.removePrefix("Current:").trim()
        }
        val pairs = Regex("""\(([^)]+)\)\s*:\s*(\d+)""").findAll(cur).map { "${it.groupValues[1]} ${it.groupValues[2]}" }.toList()
        if (pairs.isEmpty()) "unknown" else pairs.joinToString(", ") + (if (max.isNotEmpty()) " (max $max)" else "")
    } catch (e: Throwable) { "unknown" }

    private fun setDeviceVolumeMax(c: Context) {
        try {
            val am = c.getSystemService(AudioManager::class.java)
            val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (!volChanged) prevVol = cur
            if (cur < mx) am.setStreamVolume(AudioManager.STREAM_MUSIC, mx, 0)
            volChanged = true
        } catch (e: Throwable) { }
    }

    private fun restoreDeviceVolume() {
        val c = appCtx ?: return
        if (!volChanged) return
        volChanged = false
        val p = prevVol
        main.postDelayed({
            try {
                val am = c.getSystemService(AudioManager::class.java)
                if (p >= 0) am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
            } catch (e: Throwable) { }
        }, 900)
    }

    fun bind(ctx: Context) {
        appCtx = ctx.applicationContext
        stopInternal()
        val gen = ++generation
        // Choose the output while the system still reports the real route.
        chosenDev = pickOutputDevice(appCtx!!, (appCtx as? SubApp)?.params?.outPref ?: 0)
        say("0/3 Opening the audio output on ${describeDevice(appCtx!!, chosenDev)}…")
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val c = appCtx!!
            killHelpers()
            if (gen != generation) return@Thread
            // Raise the real output device's volume now, while it is still the active device. Once capture runs the
            // volume keys only reach the capture device, so loudness can no longer be changed from the keys.
            if ((c as? SubApp)?.params?.volPref == 0) setDeviceVolumeMax(c)
            // The output stream is opened BEFORE capture starts. Opened afterwards, Android may route it into the
            // capture instead of the speaker (the app then hears itself and nothing is played).
            if (!NativeDsp.start(48000, chosenDev, 40)) {
                say("Could not put the audio output on ${describeDevice(c, chosenDev)} (id $chosenDev).\nTry Output = Speaker, or reconnect and tap Connect again.")
                return@Thread
            }
            if (gen != generation) return@Thread
            say("1/3 Output is ready. Launching the capture helper through Shizuku…")
            val apk = c.applicationInfo.sourceDir
            val line = "CLASSPATH='$apk' exec app_process /system/bin --nice-name=subdsp_capture com.example.dsp.CaptureMain 48000"
            val p = try { newProcess(arrayOf("sh", "-c", line)) }
            catch (e: Throwable) {
                say("Shell launch unavailable (${e.javaClass.simpleName}: ${e.message}). Trying Shizuku user service…")
                main.post { bindUserService(c, gen) }
                return@Thread
            }
            proc = p
            main.postDelayed({
                if (gen == generation && !running)
                    DspState.note.value = "Still waiting after 12 s. Last: $step\nTry: stop Shizuku, start it again, Connect."
            }, 12000)
            runProcess(p, gen, c)
        }.also { it.name = "sub-shizuku"; it.start() }
    }

    private fun runProcess(p: java.lang.Process, gen: Int, ctx: Context) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val err = StringBuilder()
        val errThread = Thread {
            try {
                p.errorStream.bufferedReader().forEachLine { l ->
                    synchronized(err) { if (err.length < 2500) err.append(l).append('\n') }
                    if (gen == generation && !running) DspState.note.value = "Helper: $l"
                }
            } catch (e: Exception) { }
        }.also { it.isDaemon = true; it.start() }
        fun errText(): String { try { errThread.join(500) } catch (e: Exception) { }; return synchronized(err) { err.toString() } }

        val input = p.inputStream
        val bytes = ByteArray(1920)
        val floats = FloatArray(960)
        fun readFull(): Boolean {
            var off = 0
            while (off < bytes.size) {
                val r = input.read(bytes, off, bytes.size - off)
                if (r < 0) return false
                off += r
            }
            return true
        }
        try {
            if (!readFull()) {            // helper died before capturing: show why
                if (gen == generation) say("Helper exited before capturing.\n" + errText().ifBlank { "(no message: is Shizuku allowed to run shell commands?)" })
                return
            }
            if (gen != generation) return
            say("2/3 Capture is live.")
            val dev = chosenDev
            running = true
            DspState.capturing.value = true
            say("Running via Shizuku. Output: ${describeDevice(ctx, dev)}. Play something to see the capture level.")
            var pk = 0f; var blocks = 0; var silentSecs = 0; var misroute = 0; var restarts = 0; var volBlocks = 0
            fun db(x: Float) = if (x < 0.00003f) "silent" else "%.0f".format(20.0 * Math.log10(x.toDouble()))
            while (running && gen == generation) {
                for (i in 0 until 960) {
                    val lo = bytes[2 * i].toInt() and 0xFF
                    val hi = bytes[2 * i + 1].toInt()
                    val v = ((hi shl 8) or lo).toShort() / 32768f
                    floats[i] = v
                    if (v > pk) pk = v else if (-v > pk) pk = -v
                }
                NativeDsp.push(floats, 960)
                if (++blocks >= 100) {                       // about once a second
                    val silent = pk < 0.0003f
                    silentSecs = if (silent) silentSecs + 1 else 0
                    val playing = DspState.now.value?.playing == true
                    val lvl = if (silent) "silent" else "%.0f dBFS".format(20.0 * Math.log10(pk.toDouble()))
                    if (!silent) diagText = ""
                    if (silent && playing && silentSecs == 6) Thread { diagText = playerDiag() }.start()
                    val hint = when {
                        !silent -> ""
                        !playing -> "\nNothing is playing. Press play in your music app."
                        silentSecs < 4 -> ""
                        else -> "\nPlayer says it is playing but nothing arrives. Pause and play once." +
                            (if (diagText.isNotBlank()) "\nAndroid sees:\n$diagText" else "")
                    }
                    val sa = FloatArray(20); try { NativeDsp.status(sa) } catch (e: Throwable) { }
                    val routed = sa[12].toInt()
                    if (routed != dev) misroute++ else misroute = 0
                    if (misroute >= 2) {      // Android moved our stream (into the capture): open it again on the right device
                        misroute = 0; restarts++
                        NativeDsp.start(48000, dev, 40)
                    }
                    val vol = try { val am = ctx.getSystemService(AudioManager::class.java)
                        "${am.getStreamVolume(AudioManager.STREAM_MUSIC)}/${am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)}" } catch (e: Throwable) { "?" }
                    val boost = "%.0f".format(20.0 * Math.log10(sa[18].toDouble().coerceAtLeast(1e-3)))
                    if (volBlocks == 0 || volBlocks == 20 || (volBlocks > 20 && volBlocks % 120 == 0)) Thread { volText = volDiag() }.start()
                    volBlocks++
                    val eng = "stream on device $routed (want $dev) ${if (routed == dev) "OK" else "MOVED"}${if (restarts > 0) ", re-opened ${restarts}x" else ""}\n" +
                        "loudness: in ${db(sa[16])} -> out ${db(sa[17])} dBFS RMS, auto boost $boost dB\n" +
                        "volume per output: ${volText.ifBlank { "checking…" }}"
                    DspState.note.value = "Running via Shizuku. Output: ${describeDevice(ctx, dev)}\nCapture peak: $lvl\nEngine: $eng$hint"
                    pk = 0f; blocks = 0
                }
                if (!readFull()) break
            }
        } catch (e: Exception) { }
        if (gen == generation) {
            running = false
            DspState.capturing.value = false
            DspState.note.value = "Capture ended.\n" + errText()
        }
    }

    // ---------------------------------------------------------------- user-service fallback

    private fun helperVersion(ctx: Context): Int = try {
        ((ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime / 1000L) and 0x3FFFFFFF).toInt()
    } catch (e: Throwable) { 3 }

    private fun args(ctx: Context) =
        Shizuku.UserServiceArgs(ComponentName(ctx.packageName, CaptureService::class.java.name))
            .daemon(false).processNameSuffix("capture").debuggable(false).version(helperVersion(ctx))

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder == null || !binder.pingBinder()) { say("Shizuku gave back a dead helper binder"); return }
            val s = ICaptureService.Stub.asInterface(binder)
            svc = s
            val ctx = appCtx ?: return
            val gen = ++generation
            say("1/3 User-service helper connected. Starting capture…")
            Thread {
                Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
                val pfd: ParcelFileDescriptor? = try { s.start(48000) } catch (e: Throwable) { say("Helper call failed: ${e.message}"); null }
                if (pfd == null) {
                    val why = try { s.lastError() } catch (e: Throwable) { "" }
                    say("Capture refused by Android:\n$why")
                    return@Thread
                }
                val input = ParcelFileDescriptor.AutoCloseInputStream(pfd)
                val fake = object : java.lang.Process() {   // reuse the same pump as the shell path
                    override fun getOutputStream(): java.io.OutputStream = object : java.io.OutputStream() { override fun write(b: Int) {} }
                    override fun getInputStream() = input
                    override fun getErrorStream() = java.io.ByteArrayInputStream(ByteArray(0))
                    override fun waitFor() = 0
                    override fun exitValue() = 0
                    override fun destroy() { try { s.stop() } catch (e: Throwable) { } }
                }
                runProcess(fake, gen, ctx)
            }.start()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null
            running = false
            DspState.capturing.value = false
            DspState.note.value = "Shizuku helper process died (last step: $step)"
        }
    }

    private fun bindUserService(ctx: Context, gen: Int) {
        try {
            Shizuku.bindUserService(args(ctx), conn)
            bound = true
        } catch (e: Throwable) { say("Bind failed: ${e.javaClass.simpleName} ${e.message}"); return }
        main.postDelayed({
            if (gen == generation && svc == null)
                DspState.note.value = "Neither the shell launch nor Shizuku's user service could start the helper.\nSend me this text and the one above it."
        }, 8000)
    }

    fun stop() {
        stopInternal()
        restoreDeviceVolume()
    }

    private fun stopInternal() {
        generation++
        running = false
        try { proc?.destroy() } catch (e: Throwable) { }
        proc = null
        try { svc?.stop() } catch (e: Throwable) { }
        NativeDsp.stop()
        val ctx = appCtx
        if (ctx != null && bound) { try { Shizuku.unbindUserService(args(ctx), conn, true) } catch (e: Throwable) { } }
        bound = false
        svc = null
        DspState.capturing.value = false
        DspState.note.value = ""
    }

    // ---------------------------------------------------------------- audio session finder

    private var scanThread: Thread? = null
    private val scanned = HashSet<Int>()
    private var lastScanInfo = ""

    /** Every 3 s (Effects / Capture mode, Shizuku allowed): ask the system which audio sessions are playing and
     *  attach the EQ to them, for players that do not announce their session themselves. */
    fun startScan(ctx: Context) {
        if (scanThread != null) return
        if (appCtx == null) appCtx = ctx.applicationContext
        scanThread = Thread {
            while (true) {
                try { Thread.sleep(6000) } catch (e: InterruptedException) { return@Thread }
                try { scanOnce() } catch (e: Throwable) { info("scan error: ${e.javaClass.simpleName} ${e.message}") }
            }
        }.also { it.isDaemon = true; it.name = "sub-scan"; it.start() }
    }

    private fun info(s: String) { if (s != lastScanInfo) { lastScanInfo = s; SessionFx.note(s) } }

    private fun scanOnce() {
        if (DspState.mode.value == 2) return
        val ok = try { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }
        if (!ok) return
        val p = newProcess(arrayOf("dumpsys", "audio"))
        val text = p.inputStream.bufferedReader().use { it.readText() }
        try { p.destroy() } catch (e: Throwable) { }
        val uidRe = Regex("""u/pid:(\d+)/\d+""")
        val sessRe = Regex("""session(?:Id)?\s*[:=]\s*(\d+)""", RegexOption.IGNORE_CASE)
        val stateRe = Regex("""state:(\w+)""")
        val lines = text.lineSequence().filter { it.contains("AudioPlaybackConfiguration") }.toList()
        val ids = HashSet<Int>()
        val names = ArrayList<String>()
        var sample = ""
        val pm = appCtx?.packageManager
        for (l in lines) {
            val uid = uidRe.find(l)?.groupValues?.get(1)?.toIntOrNull()
            val sid = sessRe.find(l)?.groupValues?.get(1)?.toIntOrNull()
            if (uid == null || sid == null) { if (sample.isEmpty()) sample = l.trim().take(220); continue }
            if (uid == Process.myUid() || sid <= 0) continue
            val started = stateRe.find(l)?.groupValues?.get(1)?.equals("started", true) ?: true
            if (!started) continue                      // only players that are playing right now
            ids.add(sid)
            val pkg = try { pm?.getPackagesForUid(uid)?.firstOrNull() } catch (e: Throwable) { null } ?: "uid$uid"
            names.add("${pkg.substringAfterLast('.')}:$sid")
        }
        for (sid in ids) if (!SessionFx.has(sid)) SessionFx.attach(sid, "found via Shizuku")
        for (sid in scanned.toList()) if (sid !in ids) { SessionFx.release(sid); scanned.remove(sid) }
        scanned.addAll(ids)
        info(
            if (lines.isEmpty()) "scan: no player entries in dumpsys (${text.length} chars)"
            else if (ids.isEmpty() && sample.isNotEmpty()) "scan: could not read session. Sample: $sample"
            else if (ids.isEmpty()) "scan: nothing is playing right now"
            else "scan: playing now -> ${names.joinToString(", ")}"
        )
    }
}
