package com.example.dsp

import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaMetadata
import android.media.audiofx.AudioEffect
import android.media.audiofx.DynamicsProcessing
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import android.os.Process
import android.service.notification.NotificationListenerService
import kotlinx.coroutines.flow.MutableStateFlow

object NativeDsp {
    init { System.loadLibrary("dsp") }
    external fun start(sampleRate: Int, deviceId: Int, targetMs: Int): Boolean
    external fun stop()
    external fun push(buf: FloatArray, n: Int)
    external fun setBand(i: Int, type: Int, f: Float, gDb: Float, q: Float, bypass: Boolean)
    external fun setSub(sweep: Float, wide: Float, smooth: Float, sens: Float, voice: Int, gen: Int,
                        auto: Boolean, pfm: Float, gainDb: Float, drive: Float)
    external fun setMaster(inDb: Float, outDb: Float, ceilDb: Float, enabled: Boolean)
    external fun setEq(eq: Boolean, lim: Boolean)
    external fun beep()
    external fun setEnhance(punch: Float, vocal: Float, loudDb: Float)
    external fun setSubOnly(subOnly: Boolean)
    external fun status(out: FloatArray)
    external fun spectrum(out: FloatArray, fLo: Float, fHi: Float)
}

data class NowPlaying(
    val app: String, val title: String, val artist: String, val art: Bitmap?,
    val playing: Boolean, val pos: Long, val dur: Long, val stamp: Long
) {
    fun positionAt(nowElapsed: Long): Long {
        val p = if (playing) pos + (nowElapsed - stamp) else pos
        return if (dur > 0) p.coerceIn(0L, dur) else p.coerceAtLeast(0L)
    }
}

object DspState {
    val hooked = MutableStateFlow<String?>(null)
    val capturing = MutableStateFlow(false)
    val now = MutableStateFlow<NowPlaying?>(null)
    val mode = MutableStateFlow(0)          // 0 = Effects, 1 = Capture, 2 = Shizuku
    val note = MutableStateFlow("")
    val sRunning = MutableStateFlow(false)
    val sPerm = MutableStateFlow(false)
    val fxInfo = MutableStateFlow("No player has announced an audio session yet")
    @Volatile var controller: MediaController? = null
}

/**
 * Picks the output our own stream should use, so it is not swallowed by the capture routing.
 * Must be called BEFORE capture starts: afterwards the system reports the capture route instead.
 * pref: 0 = auto (where media is playing right now), 1 = phone speaker.
 */
fun pickOutputDevice(ctx: Context, pref: Int = 0): Int {
    val am = ctx.getSystemService(AudioManager::class.java)
    val outs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
    val speaker = outs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
    if (pref == 1 && speaker != null) return speaker.id
    if (android.os.Build.VERSION.SDK_INT >= 33) {
        try {
            val attr = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            val d = am.getAudioDevicesForAttributes(attr)
                .firstOrNull { it.isSink && it.type != AudioDeviceInfo.TYPE_REMOTE_SUBMIX }
            if (d != null) return d.id
        } catch (e: Throwable) { }
    }
    @Suppress("DEPRECATION") val btActive = am.isBluetoothA2dpOn
    val order = intArrayOf(
        AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE,
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_BLE_HEADSET, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
    )
    for (t in order) {
        // a Bluetooth device that is merely connected (watch, band, idle earbuds) is not where music plays
        if (!btActive && (t == AudioDeviceInfo.TYPE_BLE_HEADSET || t == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP)) continue
        val d = outs.firstOrNull { it.type == t }
        if (d != null) return d.id
    }
    return speaker?.id ?: 0
}

fun describeDevice(ctx: Context, id: Int): String {
    val am = ctx.getSystemService(AudioManager::class.java)
    val d = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { it.id == id } ?: return "default route"
    val kind = when (d.type) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "phone speaker"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth"
        AudioDeviceInfo.TYPE_BLE_HEADSET -> "Bluetooth LE"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET -> "wired headphones"
        AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE -> "USB audio"
        else -> "type ${d.type}"
    }
    return "$kind ${d.productName}"
}

class MediaListener : NotificationListenerService() {
    private lateinit var msm: MediaSessionManager
    private lateinit var cn: ComponentName
    private val cbs = HashMap<MediaSession.Token, MediaController.Callback>()
    private val listener = MediaSessionManager.OnActiveSessionsChangedListener { refresh(it) }

    override fun onListenerConnected() {
        msm = getSystemService(MediaSessionManager::class.java)
        cn = ComponentName(this, MediaListener::class.java)
        msm.addOnActiveSessionsChangedListener(listener, cn)
        refresh(msm.getActiveSessions(cn))
    }

    private fun refresh(list: List<MediaController>?) {
        list?.forEach { c ->
            if (c.sessionToken !in cbs) {
                val cb = object : MediaController.Callback() {
                    override fun onPlaybackStateChanged(state: PlaybackState?) = refresh(msm.getActiveSessions(cn))
                    override fun onMetadataChanged(metadata: MediaMetadata?) = refresh(msm.getActiveSessions(cn))
                }
                c.registerCallback(cb); cbs[c.sessionToken] = cb
            }
        }
        val pick = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        DspState.controller = pick
        if (pick == null) { DspState.hooked.value = null; DspState.now.value = null; return }
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pick.packageName, 0)).toString()
        } catch (e: Exception) { pick.packageName }
        val md = pick.metadata
        val st = pick.playbackState
        val playing = st?.state == PlaybackState.STATE_PLAYING
        DspState.hooked.value = if (playing) label else null
        DspState.now.value = NowPlaying(
            label,
            md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "",
            md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "",
            md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART),
            playing, st?.position ?: 0L, md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L,
            st?.lastPositionUpdateTime ?: 0L
        )
    }

    override fun onListenerDisconnected() {
        if (::msm.isInitialized) msm.removeOnActiveSessionsChangedListener(listener)
    }
}

class SessionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
        val pkg = i.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME) ?: "?"
        // the process may have been started just for this broadcast: make sure saved EQ settings are loaded
        (c.applicationContext as? SubApp)?.ensure()
        when (i.action) {
            AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> SessionFx.attach(id, pkg)
            AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> SessionFx.release(id)
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        // keeps the process alive so players can reach SessionReceiver (background apps do not get that broadcast)
        try { c.startForegroundService(Intent(c, FxService::class.java)) } catch (e: Exception) { }
    }
}

class SubApp : Application() {
    lateinit var params: Params
    override fun onCreate() {
        super.onCreate()
        ensure()
    }
    @Synchronized fun ensure() {
        if (::params.isInitialized) return
        params = Params(this)
        DspState.mode.value = params.savedMode
        SessionFx.ctx = this
        params.pushSession()
        params.pushMaster()
        params.pushEnh()
        ShizukuBridge.startScan(this)
    }
}

/**
 * "Effects" source: Android system effects (DynamicsProcessing) attached to the player's own audio session.
 * Works only with players that announce their session (Spotify does).
 */
object SessionFx {
    private val active = HashMap<Int, DynamicsProcessing>()
    /** upper edge of each of the 32 system bands, 24.8 Hz ... 20 kHz */
    val cutoffs = FloatArray(32) { (20.0 * Math.pow(1000.0, (it + 1) / 32.0)).toFloat() }
    /** geometric centre of each band: the EQ curve is sampled here */
    val centres = FloatArray(32) { j ->
        val lo = if (j == 0) 16.0 else cutoffs[j - 1].toDouble()
        Math.sqrt(lo * cutoffs[j]).toFloat()
    }
    private val gains = FloatArray(32)
    private var preamp = 0f
    private var on = true
    var ctx: Context? = null
    private val log = ArrayList<String>()

    fun has(id: Int) = synchronized(this) { active.containsKey(id) }

    fun note(s: String) {
        log.add(s); while (log.size > 4) log.removeAt(0)
        DspState.fxInfo.value = "Attached to ${active.size} session(s)\n" + log.joinToString("\n")
    }

    @Synchronized fun attach(session: Int, pkg: String) {
        if (session < 0) { note("$pkg announced session $session (ignored)"); return }
        active.remove(session)?.let { try { it.release() } catch (e: Exception) { } }
        try {
            val cfg = DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION, 2,
                true, 32, false, 0, false, 0, true).build()
            val dp = DynamicsProcessing(0, session, cfg)
            for (ch in 0..1) {
                for (b in 0 until 32)
                    dp.setPreEqBandByChannelIndex(ch, b, DynamicsProcessing.EqBand(true, cutoffs[b], gains[b]))
                dp.setLimiterByChannelIndex(ch, DynamicsProcessing.Limiter(true, true, 0, 1f, 60f, 10f, -2f, 0f))
            }
            try { dp.setInputGainAllChannelsTo(preamp) } catch (e: Exception) { }
            dp.enabled = on
            active[session] = dp
            note("OK: $pkg session $session")
        } catch (e: Throwable) {
            note("FAILED on $pkg session $session: ${e.javaClass.simpleName} ${e.message}")
        }
    }

    /** Tries the global output mix (session 0): works on some phones with no help from the player at all. */
    @Synchronized fun ensureGlobal(want: Boolean) {
        if (want && 0 !in active) attach(0, "global mix") else if (!want && 0 in active) release(0)
    }

    @Synchronized fun release(session: Int) {
        active.remove(session)?.let { try { it.release() } catch (e: Exception) { } ; note("closed session $session") }
    }

    @Synchronized fun setGains(g: FloatArray) {
        for (j in 0 until 32) {
            if (Math.abs(g[j] - gains[j]) > 0.05f) {
                gains[j] = g[j]
                val it = active.values.iterator()
                while (it.hasNext()) {
                    val dp = it.next()
                    try { for (ch in 0..1) dp.setPreEqBandByChannelIndex(ch, j, DynamicsProcessing.EqBand(true, cutoffs[j], g[j])) }
                    catch (e: Exception) { }
                }
            }
        }
    }

    @Synchronized fun setPreamp(db: Float) {
        if (Math.abs(db - preamp) < 0.05f) return
        preamp = db
        active.values.forEach { dp -> try { dp.setInputGainAllChannelsTo(db) } catch (e: Exception) { } }
    }

    @Synchronized fun enable(e: Boolean) {
        on = e
        active.values.forEach { dp -> try { dp.enabled = e } catch (x: Exception) { } }
    }
}

class FxService : Service() {
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ch = NotificationChannel("fx", "Effects", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = Notification.Builder(this, "fx").setContentTitle("Subharmonic is running")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(2, n)
        return START_STICKY
    }
    override fun onBind(i: Intent?): IBinder? = null
}

/** "Capture" source: MediaProjection playback capture (apps like Spotify block this). */
class DspService : Service() {
    @Volatile private var running = false
    private var rec: AudioRecord? = null
    private var proj: MediaProjection? = null
    private var th: Thread? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        val ch = NotificationChannel("dsp", "DSP", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = Notification.Builder(this, "dsp").setContentTitle("Subharmonic capture active")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val data = i?.getParcelableExtra<Intent>("data")
        if (data != null && !running) {
            try { startCapture(i.getIntExtra("code", 0), data) }
            catch (e: Throwable) { DspState.note.value = "Capture failed: ${e.message}"; stopSelf() }
        }
        return START_NOT_STICKY
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun startCapture(code: Int, data: Intent) {
        val sr = 48000
        val p = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        proj = p
        // Android 14+ wants a callback registered before the projection is used
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, android.os.Handler(android.os.Looper.getMainLooper()))
        val cfg = AudioPlaybackCaptureConfiguration.Builder(p)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).excludeUid(Process.myUid()).build()
        val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
            .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
        val r = AudioRecord.Builder().setAudioPlaybackCaptureConfig(cfg).setAudioFormat(fmt)
            .setBufferSizeInBytes(maxOf(AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_STEREO,
                AudioFormat.ENCODING_PCM_FLOAT), sr / 25 * 8)).build()
        rec = r
        if (!NativeDsp.start(sr, 0, 25)) { DspState.note.value = "Audio engine failed to start"; stopSelf(); return }
        r.startRecording(); running = true; DspState.capturing.value = true
        DspState.note.value = "Capture running. Apps that block capture (Spotify) stay silent here: use Shizuku mode for them."
        th = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val buf = FloatArray(480 * 2)
            while (running) {
                val n = r.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING)
                if (n > 0) NativeDsp.push(buf, n and 1.inv()) else if (n < 0) break
            }
        }.also { it.start() }
    }

    override fun onDestroy() {
        running = false; DspState.capturing.value = false
        try { th?.join(300) } catch (e: Exception) { }
        try { rec?.stop() } catch (e: Exception) { }
        try { rec?.release() } catch (e: Exception) { }
        try { proj?.stop() } catch (e: Exception) { }
        NativeDsp.stop()
    }
    override fun onBind(i: Intent?): IBinder? = null
}
