package com.example.dsp

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.*
import android.media.audiofx.AudioEffect
import android.media.audiofx.DynamicsProcessing
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.IBinder
import android.os.Process
import android.service.notification.NotificationListenerService
import kotlinx.coroutines.flow.MutableStateFlow

object NativeDsp {
    init { System.loadLibrary("dsp") }
    external fun start(sampleRate: Int): Boolean
    external fun stop()
    external fun push(buf: FloatArray, n: Int)
    external fun setBand(i: Int, type: Int, f: Float, gDb: Float, q: Float, bypass: Boolean)
    external fun setEpicenter(drive: Float, freq: Float, width: Float, levelDb: Float, mix: Float)
    external fun setMaster(inDb: Float, outDb: Float, ceilDb: Float, enabled: Boolean)
    external fun spectrum(out: FloatArray)
}

object DspState {
    val hooked = MutableStateFlow<String?>(null)
    val capturing = MutableStateFlow(false)
}

class MediaListener : NotificationListenerService() {
    private lateinit var msm: MediaSessionManager
    private lateinit var cn: ComponentName
    private val cbs = HashMap<MediaSession.Token, MediaController.Callback>()
    private val listener = MediaSessionManager.OnActiveSessionsChangedListener { refresh(it) }

    override fun onListenerConnected() {
        msm = getSystemService(MediaSessionManager::class.java)
        cn = ComponentName(this, MediaListener::class.java)
        msm.addOnActiveSessionsChangedListener(listener, cn)
        refresh(msm.getActiveSessions(cn))
    }

    private fun refresh(list: List<MediaController>?) {
        list?.forEach { c ->
            if (c.sessionToken !in cbs) {
                val cb = object : MediaController.Callback() {
                    override fun onPlaybackStateChanged(state: PlaybackState?) = refresh(msm.getActiveSessions(cn))
                }
                c.registerCallback(cb); cbs[c.sessionToken] = cb
            }
        }
        val playing = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        DspState.hooked.value = playing?.packageName?.let {
            try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(it, 0)).toString() }
            catch (e: Exception) { it }
        }
    }

    override fun onListenerDisconnected() {
        if (::msm.isInitialized) msm.removeOnActiveSessionsChangedListener(listener)
    }
}

class SessionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
        when (i.action) {
            AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> SessionFx.attach(id)
            AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> SessionFx.release(id)
        }
    }
}

object SessionFx {
    private val active = HashMap<Int, DynamicsProcessing>()
    val freqs = FloatArray(32) { 20f * Math.pow(1000.0, it / 31.0).toFloat() }
    @Synchronized fun attach(session: Int) {
        if (session <= 0 || session in active) return
        try {
            val cfg = DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION, 2,
                true, 32, false, 0, false, 0, true).build()
            val dp = DynamicsProcessing(0, session, cfg)
            for (ch in 0..1) for (b in 0 until 32)
                dp.setPreEqBandByChannelIndex(ch, b, DynamicsProcessing.EqBand(true, freqs[b], 0f))
            dp.enabled = true
            active[session] = dp
        } catch (e: Exception) { /* player may reject the effect */ }
    }
    @Synchronized fun release(session: Int) { active.remove(session)?.release() }
}

class DspService : Service() {
    @Volatile private var running = false
    private var rec: AudioRecord? = null
    private var proj: MediaProjection? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        val ch = NotificationChannel("dsp", "DSP", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = Notification.Builder(this, "dsp").setContentTitle("SubDSP active")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val data = i?.getParcelableExtra<Intent>("data")
        if (data != null && !running) startCapture(i.getIntExtra("code", 0), data)
        return START_STICKY
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun startCapture(code: Int, data: Intent) {
        val sr = 48000
        proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        val cfg = AudioPlaybackCaptureConfiguration.Builder(proj!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME).build()
        val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
            .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
        rec = AudioRecord.Builder().setAudioPlaybackCaptureConfig(cfg).setAudioFormat(fmt)
            .setBufferSizeInBytes(sr / 10 * 2 * 4).build()
        if (!NativeDsp.start(sr)) { stopSelf(); return }
        rec!!.startRecording(); running = true; DspState.capturing.value = true
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val buf = FloatArray(480 * 2)
            while (running) {
                val n = rec!!.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING)
                if (n > 0) NativeDsp.push(buf, n)
            }
        }.start()
    }

    override fun onDestroy() {
        running = false; DspState.capturing.value = false
        rec?.stop(); rec?.release(); proj?.stop(); NativeDsp.stop()
    }
    override fun onBind(i: Intent?): IBinder? = null
}
