package com.example.dsp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaMetadata
import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import android.os.Process
import android.service.notification.NotificationListenerService
import kotlinx.coroutines.flow.MutableStateFlow

object NativeDsp {
    init { System.loadLibrary("dsp") }
    external fun start(sampleRate: Int, deviceId: Int): Boolean
    external fun stop()
    external fun push(buf: FloatArray, n: Int)
    external fun setBand(i: Int, type: Int, f: Float, gDb: Float, q: Float, bypass: Boolean)
    external fun setSub(sweep: Float, wide: Float, smooth: Float, sens: Float, voice: Int, gen: Int,
                        auto: Boolean, pfm: Float, gainDb: Float, drive: Float)
    external fun setMaster(inDb: Float, outDb: Float, ceilDb: Float, enabled: Boolean)
    external fun status(out: FloatArray)
    external fun spectrum(out: FloatArray, fLo: Float, fHi: Float)
}

data class NowPlaying(
    val app: String, val title: String, val artist: String, val art: Bitmap?,
    val playing: Boolean, val pos: Long, val dur: Long, val stamp: Long
) {
    fun positionAt(nowElapsed: Long): Long {
        val p = if (playing) pos + (nowElapsed - stamp) else pos
        return if (dur > 0) p.coerceIn(0L, dur) else p.coerceAtLeast(0L)
    }
}

object DspState {
    val hooked = MutableStateFlow<String?>(null)
    val capturing = MutableStateFlow(false)
    val now = MutableStateFlow<NowPlaying?>(null)
    val mode = MutableStateFlow(0)          // 0 = Effects, 1 = Capture, 2 = Shizuku
    val note = MutableStateFlow("")
    @Volatile var controller: MediaController? = null
}

/** Picks the physical output so our own stream is not swallowed by the capture routing. */
fun pickOutputDevice(ctx: Context): Int {
    val am = ctx.getSystemService(AudioManager::class.java)
    val outs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
    val order = intArrayOf(
        AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE,
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET,
        AudioDeviceInfo.TYPE_BLE_HEADSET, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
    )
    for (t in order) {
        val d = outs.firstOrNull { it.type == t }
        if (d != null) return d.id
    }
    return 0
}

class MediaListener : NotificationListenerService() {
    private lateinit var msm: MediaSessionManager
    private lateinit var cn: ComponentName
    private val cbs = HashMap<MediaSession.Token, MediaController.Callback>()
    private val listener = MediaSessionManager.OnActiveSessionsChangedListener { refresh(it) }

    override fun onListenerConnected() {
        msm = getSystemService(MediaSessionManager::class.java)
        cn = ComponentName(this, MediaListener::class.java)
        msm.addOnActiveSessionsChangedListener(listener, cn)
        refresh(msm.getActiveSessions(cn))
    }

    private fun refresh(list: List<MediaController>?) {
        list?.forEach { c ->
            if (c.sessionToken !in cbs) {
                val cb = object : MediaController.Callback() {
                    override fun onPlaybackStateChanged(state: PlaybackState?) = refresh(msm.getActiveSessions(cn))
                    override fun onMetadataChanged(metadata: MediaMetadata?) = refresh(msm.getActiveSessions(cn))
                }
                c.registerCallback(cb); cbs[c.sessionToken] = cb
            }
        }
        val pick = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list?.firstOrNull()
        DspState.controller = pick
        if (pick == null) { DspState.hooked.value = null; DspState.now.value = null; return }
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pick.packageName, 0)).toString()
        } catch (e: Exception) { pick.packageName }
        val md = pick.metadata
        val st = pick.playbackState
        val playing = st?.state == PlaybackState.STATE_PLAYING
        DspState.hooked.value = if (playing) label else null
        DspState.now.value = NowPlaying(
            label,
            md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "",
            md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: "",
            md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART),
            playing, st?.position ?: 0L, md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L,
            st?.lastPositionUpdateTime ?: 0L
        )
    }

    override fun onListenerDisconnected() {
        if (::msm.isInitialized) msm.removeOnActiveSessionsChangedListener(listener)
    }
}

class SessionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
        when (i.action) {
            AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> SessionFx.attach(id)
            AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> SessionFx.release(id)
        }
    }
}

/** "Effects" source: Android system effects attached to the player's own audio session (Spotify supports this). */
object SessionFx {
    private class Fx(val dp: DynamicsProcessing, val bb: BassBoost?)
    private val active = HashMap<Int, Fx>()
    val freqs = FloatArray(32) { 20f * Math.pow(1000.0, it / 31.0).toFloat() }
    private val gains = FloatArray(32)
    private var bass = 0f
    private var on = true

    @Synchronized fun attach(session: Int) {
        if (session <= 0 || session in active) return
        try {
            val cfg = DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION, 2,
                true, 32, false, 0, false, 0, true).build()
            val dp = DynamicsProcessing(0, session, cfg)
            for (ch in 0..1) {
                for (b in 0 until 32)
                    dp.setPreEqBandByChannelIndex(ch, b, DynamicsProcessing.EqBand(true, freqs[b], gains[b]))
                dp.setLimiterByChannelIndex(ch, DynamicsProcessing.Limiter(true, true, 0, 1f, 60f, 10f, -2f, 0f))
            }
            dp.enabled = on
            val bb = try {
                BassBoost(0, session).also { it.setStrength((bass * 1000).toInt().toShort()); it.enabled = on }
            } catch (e: Exception) { null }
            active[session] = Fx(dp, bb)
        } catch (e: Exception) { }
    }

    @Synchronized fun release(session: Int) {
        active.remove(session)?.let { it.dp.release(); it.bb?.release() }
    }

    @Synchronized fun setGain(i: Int, g: Float) {
        gains[i] = g
        active.values.forEach { fx ->
            try { for (ch in 0..1) fx.dp.setPreEqBandByChannelIndex(ch, i, DynamicsProcessing.EqBand(true, freqs[i], g)) }
            catch (e: Exception) { }
        }
    }

    @Synchronized fun setBass(v: Float) {
        bass = v
        active.values.forEach { fx -> try { fx.bb?.setStrength((v * 1000).toInt().toShort()) } catch (e: Exception) { } }
    }

    @Synchronized fun enable(e: Boolean) {
        on = e
        active.values.forEach { fx -> try { fx.dp.enabled = e; fx.bb?.enabled = e } catch (x: Exception) { } }
    }
}

class FxService : Service() {
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ch = NotificationChannel("fx", "Effects", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = Notification.Builder(this, "fx").setContentTitle("Subharmonic is running")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(2, n)
        return START_STICKY
    }
    override fun onBind(i: Intent?): IBinder? = null
}

/** "Capture" source: MediaProjection playback capture (apps like Spotify block this). */
class DspService : Service() {
    @Volatile private var running = false
    private var rec: AudioRecord? = null
    private var proj: MediaProjection? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        val ch = NotificationChannel("dsp", "DSP", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = Notification.Builder(this, "dsp").setContentTitle("Subharmonic capture active")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val data = i?.getParcelableExtra<Intent>("data")
        if (data != null && !running) startCapture(i.getIntExtra("code", 0), data)
        return START_NOT_STICKY
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun startCapture(code: Int, data: Intent) {
        val sr = 48000
        proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        val cfg = AudioPlaybackCaptureConfiguration.Builder(proj!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME).excludeUid(Process.myUid()).build()
        val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
            .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
        rec = AudioRecord.Builder().setAudioPlaybackCaptureConfig(cfg).setAudioFormat(fmt)
            .setBufferSizeInBytes(maxOf(AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_STEREO,
                AudioFormat.ENCODING_PCM_FLOAT), sr / 25 * 8)).build()
        if (!NativeDsp.start(sr, 0)) { stopSelf(); return }
        rec!!.startRecording(); running = true; DspState.capturing.value = true
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val buf = FloatArray(480 * 2)
            while (running) {
                val n = rec!!.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING)
                if (n > 0) NativeDsp.push(buf, n)
            }
        }.start()
    }

    override fun onDestroy() {
        running = false; DspState.capturing.value = false
        rec?.stop(); rec?.release(); proj?.stop(); NativeDsp.stop()
    }
    override fun onBind(i: Intent?): IBinder? = null
}
