package com.example.dsp

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.pow

class BandState(t: Int, f: Float, g: Float, q0: Float) {
    var type by mutableIntStateOf(t)
    var freq by mutableFloatStateOf(f)
    var gain by mutableFloatStateOf(g)
    var q by mutableFloatStateOf(q0)
    var byp by mutableStateOf(false)
}

class Params(ctx: Context) {
    private val sp = ctx.getSharedPreferences("subdsp", Context.MODE_PRIVATE)

    var sweep by mutableFloatStateOf(sp.getFloat("sweep", 45f))
    var wide by mutableFloatStateOf(sp.getFloat("wide", 0.7f))
    var smooth by mutableFloatStateOf(sp.getFloat("smooth", 1.2f))
    var sens by mutableFloatStateOf(sp.getFloat("sens", 0.73f))
    var gainDb by mutableFloatStateOf(sp.getFloat("gainDb", 6f))
    var drive by mutableFloatStateOf(sp.getFloat("drive", 0.3f))
    var pfm by mutableFloatStateOf(sp.getFloat("pfm", 21f))
    var master by mutableFloatStateOf(sp.getFloat("master", 0f))
    var voice by mutableIntStateOf(sp.getInt("voice", 0))
    var gen by mutableIntStateOf(sp.getInt("gen", 0))
    var auto by mutableStateOf(sp.getBoolean("auto", false))
    var original by mutableStateOf(false)

    val bands: List<BandState> = List(32) { i -> BandState(0, 20f * 1000f.pow(i / 31f), 0f, 4.3f) }

    init {
        try {
            val s = sp.getString("eq", null)
            if (s != null) {
                s.split(";").forEachIndexed { i, row ->
                    val v = row.split(",")
                    if (i < 32 && v.size >= 5) {
                        val b = bands[i]
                        b.type = v[0].toInt(); b.freq = v[1].toFloat(); b.gain = v[2].toFloat()
                        b.q = v[3].toFloat(); b.byp = v[4] == "1"
                    }
                }
            }
        } catch (e: Exception) { }
    }

    fun pushSub() {
        NativeDsp.setSub(sweep, wide, smooth, sens, voice, gen, auto, pfm, gainDb, drive)
        SessionFx.setBass((gainDb / 12f).coerceIn(0f, 1f))
        save()
    }

    fun pushMaster() {
        NativeDsp.setMaster(0f, master, -1f, !original)
        SessionFx.enable(!original && DspState.mode.value == 0)
    }

    fun applyBand(i: Int) {
        val b = bands[i]
        NativeDsp.setBand(i, b.type, b.freq, b.gain, b.q, b.byp)
        SessionFx.setGain(i, if (b.byp) 0f else b.gain)
        save()
    }

    fun pushAll() {
        pushSub(); pushMaster()
        for (i in 0 until 32) applyBand(i)
    }

    fun resetEq() {
        for (i in 0 until 32) {
            val b = bands[i]
            b.type = 0; b.freq = 20f * 1000f.pow(i / 31f); b.gain = 0f; b.q = 4.3f; b.byp = false
            applyBand(i)
        }
    }

    fun resetSub() {
        sweep = 45f; wide = 0.7f; smooth = 1.2f; sens = 0.73f; gainDb = 6f; drive = 0.3f
        pfm = 21f; master = 0f; voice = 0; gen = 0; auto = false
        pushSub(); pushMaster()
    }

    fun save() {
        val e = sp.edit()
        e.putFloat("sweep", sweep).putFloat("wide", wide).putFloat("smooth", smooth).putFloat("sens", sens)
        e.putFloat("gainDb", gainDb).putFloat("drive", drive).putFloat("pfm", pfm).putFloat("master", master)
        e.putInt("voice", voice).putInt("gen", gen).putBoolean("auto", auto)
        e.putString("eq", bands.joinToString(";") { "${it.type},${it.freq},${it.gain},${it.q},${if (it.byp) 1 else 0}" })
        e.apply()
    }
}
