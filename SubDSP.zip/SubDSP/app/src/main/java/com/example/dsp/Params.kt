package com.example.dsp

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class BandState(t: Int, f: Float, g: Float, q0: Float) {
    var type by mutableIntStateOf(t)
    var freq by mutableFloatStateOf(f)
    var gain by mutableFloatStateOf(g)
    var q by mutableFloatStateOf(q0)
    var byp by mutableStateOf(false)
}

class CustomPreset(val name: String, val gains: FloatArray)

class Params(ctx: Context) {
    private val sp = ctx.getSharedPreferences("subdsp", Context.MODE_PRIVATE)

    // ---- sub-harmonic ----
    var sweep by mutableFloatStateOf(sp.getFloat("sweep", 45f))
    var wide by mutableFloatStateOf(sp.getFloat("wide", 0.7f))
    var smooth by mutableFloatStateOf(sp.getFloat("smooth", 1.2f))
    var sens by mutableFloatStateOf(sp.getFloat("sens", 0.73f))
    var gainDb by mutableFloatStateOf(sp.getFloat("gainDb", 6f))
    var drive by mutableFloatStateOf(sp.getFloat("drive", 0.3f))
    var pfm by mutableFloatStateOf(sp.getFloat("pfm", 21f))
    var master by mutableFloatStateOf(sp.getFloat("master", 0f))
    var outPref by mutableIntStateOf(sp.getInt("outPref", 0))
    var punch by mutableFloatStateOf(sp.getFloat("punch", 0.4f))
    var vocal by mutableFloatStateOf(sp.getFloat("vocal", 0.3f))
    var loud by mutableFloatStateOf(sp.getFloat("loud", 4f))
    var voice by mutableIntStateOf(sp.getInt("voice", 0))
    var gen by mutableIntStateOf(sp.getInt("gen", 0))
    var auto by mutableStateOf(sp.getBoolean("auto", false))
    var original by mutableStateOf(false)
    val savedMode: Int get() = sp.getInt("mode", 0).coerceIn(0, 2)
    fun saveMode(m: Int) { sp.edit().putInt("mode", m).apply() }

    // ---- equalizer ----
    var bandCount by mutableIntStateOf(sp.getInt("bandCount", 10).coerceIn(5, 32))
    var preamp by mutableFloatStateOf(sp.getFloat("preamp", 0f))
    var bass by mutableFloatStateOf(sp.getFloat("bass", 0f))
    var treble by mutableFloatStateOf(sp.getFloat("treble", 0f))
    var eqOn by mutableStateOf(sp.getBoolean("eqOn", true))
    var limOn by mutableStateOf(sp.getBoolean("limOn", true))
    var presetName by mutableStateOf(sp.getString("preset", "Flat") ?: "Flat")
    val custom = mutableStateListOf<CustomPreset>()
    val bands: List<BandState> = List(32) { i ->
        val n = sp.getInt("bandCount", 10).coerceIn(5, 32)
        BandState(0, bandFreq(n, i), 0f, autoQ(n))
    }

    init {
        try {
            // Older builds could compound the band gains up to +24 dB on every band; start from flat once.
            if (sp.getInt("enhVer", 0) < 1) { master = 0f; preamp = 0f; sp.edit().putInt("enhVer", 1).apply() }
            var s = sp.getString("eq", null)
            if (sp.getInt("eqVer", 0) < 2) { s = null; sp.edit().remove("eq").putInt("eqVer", 2).putString("preset", "Flat").apply(); presetName = "Flat" }
            if (s != null) {
                s.split(";").forEachIndexed { i, row ->
                    val v = row.split(",")
                    if (i < 32 && v.size >= 5) {
                        val b = bands[i]
                        b.type = v[0].toInt(); b.freq = v[1].toFloat(); b.gain = v[2].toFloat()
                        b.q = v[3].toFloat(); b.byp = v[4] == "1"
                        if (!b.gain.isFinite() || Math.abs(b.gain) > 24f) b.gain = 0f
                    }
                }
            }
            sp.getString("custom", "")?.split(";")?.forEach { row ->
                val parts = row.split("|")
                if (parts.size == 2) {
                    val g = parts[1].split(",").map { it.toFloat() }.toFloatArray()
                    if (g.size == 10) custom.add(CustomPreset(parts[0], g))
                }
            }
        } catch (e: Exception) { }
    }

    // ---------- sub-harmonic ----------
    fun pushSub() {
        NativeDsp.setSub(sweep, wide, smooth, sens, voice, gen, auto, pfm, gainDb, drive)
        pushSession()
        save()
    }

    fun pushMaster() {
        val mode = DspState.mode.value
        NativeDsp.setSubOnly(mode == 1)                 // Capture: engine adds only the sub on top of the original
        NativeDsp.setMaster(if (eqOn) preamp else 0f, master, -1f, !original)
        SessionFx.ensureGlobal(mode != 2 && !original)
        SessionFx.enable(!original && mode != 2)        // system EQ on the original (muted + replaced in Shizuku mode)
    }

    fun resetSub() {
        sweep = 45f; wide = 0.7f; smooth = 1.2f; sens = 0.73f; gainDb = 6f; drive = 0.3f
        pfm = 21f; master = 0f; voice = 0; gen = 0; auto = false
        pushSub(); pushMaster()
    }

    // ---------- equalizer ----------
    fun stagesAll(): List<DoubleArray> =
        if (eqOn) bands.take(bandCount).flatMap { stagesOf(it) } + toneStages(this) else emptyList()

    private fun bandsOnlyStages(): List<DoubleArray> = bands.take(bandCount).flatMap { stagesOf(it) }

    private fun applyBandNative(i: Int) {
        val b = bands[i]
        val active = i < bandCount
        NativeDsp.setBand(i, b.type, b.freq, if (active) b.gain else 0f, b.q, b.byp || !active)
    }

    fun pushTone() {
        NativeDsp.setBand(32, 1, 90f, bass * 12f, 0.7f, false)
        NativeDsp.setBand(33, 2, 8000f, treble * 12f, 0.7f, false)
    }

    /**
     * Mirrors the whole EQ curve onto the 32 system-effect bands (used by the "Effects" source).
     * Each system band covers a frequency range, so the curve is sampled at the band's centre.
     * SUB GAIN acts there as a gentle low shelf, because the real sub synth cannot run inside the system effect chain.
     */
    fun pushSession() {
        SessionFx.setPreamp(if (eqOn) preamp else 0f)
        val st = ArrayList(stagesAll())
        val lift = gainDb.coerceIn(0f, 12f) * 0.5f
        if (lift > 0.05f) st.add(rbjK(1, 80.0, lift.toDouble(), 0.7))
        val g = FloatArray(32) { j -> respDb(st, SessionFx.centres[j].toDouble()).toFloat().coerceIn(-24f, 24f) }
        SessionFx.setGains(g)
    }

    fun pushEq() {
        NativeDsp.setEq(eqOn, limOn)
        for (i in 0 until 32) applyBandNative(i)
        pushTone()
        pushSession()
        save()
    }

    fun pushEnh() { NativeDsp.setEnhance(punch, vocal, loud); save() }

    fun pushAll() { pushSub(); pushMaster(); pushEq(); pushEnh() }

    /** A band was edited by the user. */
    fun edit(i: Int) {
        presetName = ""
        applyBandNative(i)
        pushSession()
        save()
    }

    fun editTone() {
        presetName = ""
        pushTone(); pushSession(); save()
    }

    fun resetEq() {
        for (i in 0 until 32) {
            val b = bands[i]
            b.type = 0; b.freq = bandFreq(bandCount, i); b.gain = 0f; b.q = autoQ(bandCount); b.byp = false
        }
        pushEq()
        presetName = "Flat"
    }

    /** Re-lays the bands out for n bands and keeps the current sound (least-squares fit, so it never drifts). */
    fun changeBandCount(n0: Int) {
        val n = n0.coerceIn(5, 32)
        if (n == bandCount) return
        val before = bandsOnlyStages()
        val fit = fitGains(n) { f -> respDb(before, f) }
        bandCount = n
        for (i in 0 until 32) {
            val b = bands[i]
            b.type = 0; b.freq = bandFreq(n, i); b.q = autoQ(n); b.byp = false
            b.gain = if (i < n) fit[i] else 0f
        }
        pushEq()
    }

    fun applyPreset(name: String, g: FloatArray) {
        val fit = fitGains(bandCount) { f -> interpPreset(g, f.toFloat()).toDouble() }
        for (i in 0 until bandCount) {
            val b = bands[i]
            b.type = 0; b.freq = bandFreq(bandCount, i); b.q = autoQ(bandCount); b.byp = false
            b.gain = fit[i]
        }
        pushEq()
        presetName = name
        save()
    }

    fun saveCustom() {
        val st = bandsOnlyStages()
        val g = FloatArray(10) { respDb(st, 31.25 * Math.pow(2.0, it.toDouble())).toFloat().coerceIn(-24f, 24f) }
        var k = custom.size + 1
        while (custom.any { it.name == "Custom $k" }) k++
        val name = "Custom $k"
        custom.add(CustomPreset(name, g))
        presetName = name
        save()
    }

    fun deleteCustom(name: String) {
        custom.removeAll { it.name == name }
        presetName = ""
        save()
    }

    fun save() {
        val e = sp.edit()
        e.putFloat("sweep", sweep).putFloat("wide", wide).putFloat("smooth", smooth).putFloat("sens", sens)
        e.putInt("outPref", outPref).putFloat("punch", punch).putFloat("vocal", vocal).putFloat("loud", loud)
        e.putFloat("gainDb", gainDb).putFloat("drive", drive).putFloat("pfm", pfm).putFloat("master", master)
        e.putInt("voice", voice).putInt("gen", gen).putBoolean("auto", auto)
        e.putInt("bandCount", bandCount).putFloat("preamp", preamp).putFloat("bass", bass).putFloat("treble", treble)
        e.putBoolean("eqOn", eqOn).putBoolean("limOn", limOn).putString("preset", presetName)
        e.putString("eq", bands.joinToString(";") { "${it.type},${it.freq},${it.gain},${it.q},${if (it.byp) 1 else 0}" })
        e.putString("custom", custom.joinToString(";") { it.name + "|" + it.gains.joinToString(",") })
        e.apply()
    }
}
