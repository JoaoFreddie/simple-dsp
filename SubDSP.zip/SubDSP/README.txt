SubDSP - open this folder in Android Studio (Koala or newer), let Gradle sync,
install NDK + CMake 3.22.1 when prompted, plug in a phone (USB debugging) and press Run.

SOURCES (Source tab)
  Effects  - system EQ on the player's own session. Only for players that announce a session (Spotify does).
             The Source tab shows which sessions were attached, or why it failed.
  Capture  - synthesized sub on top of the original (MediaProjection). Apps that block capture stay silent.
  Shizuku  - EVERYTHING (EQ + sub) for ANY app incl. Spotify. Start Shizuku, tap Allow, tap Connect.

After updating: clear the app's data or just open it once - the EQ resets to flat one time (old builds could
leave every band at +24 dB).
