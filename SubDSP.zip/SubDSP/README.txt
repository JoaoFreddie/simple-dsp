SubDSP - open this folder in Android Studio (Koala or newer), let Gradle sync,
install NDK + CMake 3.22.1 when prompted, plug in a phone (USB debugging) and press Run.
In the app: Listener -> enable "SubDSP", then Start capture -> allow.
